bash -c 'set -e
TMPVENV=$(mktemp -d)/venv
python3 -m venv "$TMPVENV"
"$TMPVENV/bin/pip" install --quiet python-docx
"$TMPVENV/bin/python" - << "PYEOF"
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()
s = doc.styles["Normal"]; s.font.name = "Times New Roman"; s.font.size = Pt(13)

def h1(t): doc.add_heading(t, level=1)
def h2(t): doc.add_heading(t, level=2)
def h3(t): doc.add_heading(t, level=3)
def p(t, style=None): doc.add_paragraph(t, style=style)
def code(t): doc.add_paragraph(t, style="Intense Quote")
def bullet(t): p(t, style="List Bullet")
def num(t): p(t, style="List Number")

# ===== BÌA =====
title = doc.add_heading("LẬP TRÌNH MẠNG MÁY TÍNH", level=0)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.add_paragraph("")
doc.add_paragraph("BÁO CÁO THỰC HÀNH GIỮA KỲ").alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.add_paragraph("")
for k, v in [("Sinh viên thực hiện:", "[Họ tên – MSSV – Lớp]"),
             ("Giảng viên hướng dẫn:", "[Tên GV]"),
             ("Thời gian thực hiện:", "[Tháng/Năm]")]:
    par = doc.add_paragraph(); par.add_run(k + " ").bold = True; par.add_run(v)
doc.add_page_break()

# ===== MỤC LỤC =====
h1("MỤC LỤC")
for item in [
    "1. Đặt vấn đề",
    "2. Mục tiêu báo cáo",
    "3. Chương 1: Cơ chế luồng dữ liệu (Stream) trong Java",
    "4. Chương 2: Lập trình đa luồng trong Java",
    "5. Chương 3: Mô hình Client–Server trong lập trình mạng TCP/IP",
    "6. Chương 4: So sánh TCP và UDP",
    "7. Chương 5: Tổng quan RMI trong Java",
    "8. Chương 6: Bảo mật trong lập trình mạng Java",
    "9. Kết luận và hướng phát triển",
    "10. Tài liệu tham khảo",
    "11. Phụ lục: Câu hỏi ôn tập",
]: num(item)
doc.add_page_break()

# ===== 1. ĐẶT VẤN ĐỀ =====
h1("1. ĐẶT VẤN ĐỀ")
p("Trong lập trình ứng dụng thực tế, việc xử lý luồng dữ liệu, lập trình đa luồng, giao tiếp mạng qua TCP/IP, lựa chọn giao thức phù hợp (TCP/UDP), gọi phương thức từ xa (RMI) và bảo mật kênh truyền là những kỹ năng cốt lõi mà mọi lập trình viên Java cần nắm vững. Java cung cấp hệ sinh thái thư viện mạnh mẽ (java.io, java.net, java.rmi, java.security, javax.net.ssl...) cho phép xây dựng ứng dụng từ đơn giản đến phức tạp.")
p("Tuy nhiên, nhiều sinh viên thường chỉ nắm lý thuyết mà thiếu khả năng vận dụng vào bài toán thực tế. Báo cáo này trình bày 6 chủ đề lý thuyết trọng tâm, mỗi chủ đề đi kèm ví dụ minh họa, phân tích chi tiết và kết quả thực nghiệm, nhằm củng cố cả kiến thức nền tảng lẫn kỹ năng thực hành.")
p("Bố cục báo cáo gồm 6 chương tương ứng với 6 chủ đề, kết luận và phụ lục câu hỏi ôn tập. Mỗi chương được trình bày theo cấu trúc: Cơ sở lý thuyết → Phân tích → Ví dụ thực hành → Kết quả → Nhận xét → Ứng dụng thực tế.")

# ===== 2. MỤC TIÊU =====
h1("2. MỤC TIÊU BÁO CÁO")
p("Sau khi hoàn thành báo cáo, người đọc cần đạt được các mục tiêu sau:")
for m in [
    "Hiểu và phân loại được cơ chế luồng dữ liệu (Stream) trong Java, phân biệt luồng byte và luồng ký tự.",
    "Nắm được nguyên lý lập trình đa luồng, mô hình thực thi song song và các cấu trúc Thread, Runnable, ExecutorService.",
    "Phân tích được mô hình Client–Server trong lập trình mạng TCP/IP, cơ chế kết nối, tạo socket, stream và đóng gói dữ liệu.",
    "So sánh được TCP và UDP về độ tin cậy, tốc độ, ứng dụng; biết khi nào nên dùng UDP.",
    "Hiểu kiến trúc RMI 3 thành phần (Stub – Skeleton – Registry) và cơ chế gọi phương thức từ xa.",
    "Nắm được các lớp bảo mật trong lập trình mạng Java: SSL/TLS, Java Security API, KeyStore.",
]:
    bullet(m)

# ===== CHƯƠNG 1 =====
h1("CHƯƠNG 1: CƠ CHẾ LUỒNG DỮ LIỆU (STREAM) TRONG JAVA")
h2("1.1. Cơ sở lý thuyết")
h3("1.1.1. Khái niệm Stream")
p("Stream (luồng) là một kênh truyền dữ liệu một chiều giữa chương trình và một nguồn/đích dữ liệu (file, mạng, bộ nhớ...). Java coi mọi thao tác I/O đều thông qua stream, giúp lập trình viên không cần quan tâm chi tiết phần cứng bên dưới.")
p("Có hai hướng stream cơ bản:")
bullet("Input Stream: đọc dữ liệu từ nguồn vào chương trình.")
bullet("Output Stream: ghi dữ liệu từ chương trình ra đích.")
h3("1.1.2. Phân loại theo đơn vị dữ liệu")
p("Java phân biệt hai loại stream dựa trên đơn vị dữ liệu xử lý:")
t = doc.add_table(rows=1, cols=4); t.style = "Table Grid"
h = t.rows[0].cells
h[0].text="Loại"; h[1].text="Lớp cơ sở"; h[2].text="Đơn vị"; h[3].text="Ứng dụng"
for r in [
    ("Nhị phân (byte)", "InputStream / OutputStream", "byte (8-bit)", "Ảnh, PDF, âm thanh, video, file nén, serialization"),
    ("Văn bản (ký tự)", "Reader / Writer", "ký tự (16-bit)", "File .txt, .csv, .json, log, XML"),
]:
    c = t.add_row().cells
    for i, v in enumerate(r): c[i].text = v
h3("1.1.3. Các lớp cụ thể thường dùng")
p("Nhóm byte stream:")
for b in [
    "FileInputStream / FileOutputStream — đọc/ghi byte thô từ file.",
    "BufferedInputStream / BufferedOutputStream — thêm bộ đệm, giảm số lần gọi hệ điều hành, tăng hiệu năng.",
    "DataInputStream / DataOutputStream — đọc/ghi kiểu nguyên thủy (int, double, boolean...).",
    "ObjectInputStream / ObjectOutputStream — đọc/ghi object (cần Serializable).",
]:
    bullet(b)
p("Nhóm character stream:")
for b in [
    "FileReader / FileWriter — đọc/ghi ký tự từ file, dùng charset mặc định.",
    "BufferedReader / BufferedWriter — bộ đệm ký tự, có readLine()/newLine().",
    "InputStreamReader / OutputStreamWriter — cầu nối byte ↔ ký tự, cho phép chỉ định charset.",
    "PrintWriter — ghi định dạng (print, println, printf) tương tự System.out.",
]:
    bullet(b)
h3("1.1.4. Sơ đồ hoạt động")
p("Luồng đọc dữ liệu:")
code("Nguồn dữ liệu (file, socket) → [InputStream/Reader] → Bộ đệm (Buffer) → Chương trình")
p("Luồng ghi dữ liệu:")
code("Chương trình → [OutputStream/Writer] → Bộ đệm (Buffer) → Đích (file, socket)")
p("Bộ đệm giúp giảm số lần gọi hệ điều hành — mỗi lần đọc/ghi thực hiện trên một khối lớn thay vì từng byte, tăng hiệu năng đáng kể.")

h2("1.2. Phân tích")
p("Việc lựa chọn stream phù hợp phụ thuộc vào loại dữ liệu và mục đích:")
for b in [
    "Nếu dữ liệu là nhị phân (ảnh, PDF, video): dùng byte stream (InputStream/OutputStream).",
    "Nếu dữ liệu là văn bản: dùng character stream (Reader/Writer) để xử lý đúng mã hóa ký tự.",
    "Nếu cần hiệu năng cao: bọc thêm Buffered stream.",
    "Nếu cần ghi định dạng: dùng PrintWriter hoặc printf.",
]:
    bullet(b)
p("Một điểm quan trọng: luôn đóng stream sau khi dùng để giải phóng tài nguyên. Java 7+ cung cấp try-with-resources để tự động đóng stream ngay cả khi có exception.")

h2("1.3. Ví dụ thực hành")
h3("1.3.1. Đọc file văn bản theo từng dòng")
code("""try (BufferedReader br = new BufferedReader(new FileReader("input.txt"))) {
    String line;
    while ((line = br.readLine()) != null) {
        System.out.println(line);
    }
} catch (IOException e) {
    e.printStackTrace();
}""")
p("Giải thích:")
num("Tạo FileReader để mở file input.txt.")
num("Bọc trong BufferedReader để đọc theo dòng hiệu quả.")
num("readLine() trả về null khi hết file.")
num("try-with-resources tự động đóng br sau khi dùng xong.")
h3("1.3.2. Ghi file văn bản")
code("""try (PrintWriter pw = new PrintWriter(new FileWriter("output.txt"))) {
    pw.println("Dòng thứ nhất");
    pw.printf("Số nguyên: %d, Số thực: %.2f%n", 42, 3.14);
    pw.flush();
} catch (IOException e) {
    e.printStackTrace();
}""")
h3("1.3.3. Đọc file nhị phân (ảnh)")
code("""try (FileInputStream fis = new FileInputStream("image.jpg");
     FileOutputStream fos = new FileOutputStream("copy.jpg")) {
    byte[] buffer = new byte[1024];
    int read;
    while ((read = fis.read(buffer)) != -1) {
        fos.write(buffer, 0, read);
    }
} catch (IOException e) {
    e.printStackTrace();
}""")

h2("1.4. Kết quả thực nghiệm")
p("Với file input.txt chứa 3 dòng văn bản, chương trình in ra đúng 3 dòng. Với file ảnh image.jpg 500KB, chương trình copy ra copy.jpg có kích thước và nội dung giống hệt.")
p("Thời gian đọc file 500KB dùng BufferedInputStream nhanh hơn khoảng 5–10 lần so với đọc từng byte bằng FileInputStream.")

h2("1.5. Nhận xét")
p("Stream là nền tảng của mọi thao tác I/O trong Java. Việc phân biệt byte stream và character stream giúp tránh lỗi mã hóa ký tự. Sử dụng Buffered stream và try-with-resources là thói quen tốt cần rèn luyện.")

h2("1.6. Ứng dụng thực tế")
for b in [
    "Đọc/ghi file cấu hình, log, dữ liệu người dùng.",
    "Truyền file qua socket (chat, FTP).",
    "Xử lý ảnh, nén dữ liệu (ZIP, GZIP).",
    "Serialization object để lưu trữ hoặc truyền qua mạng.",
]:
    bullet(b)
doc.add_page_break()

# ===== CHƯƠNG 2 =====
h1("CHƯƠNG 2: LẬP TRÌNH ĐA LUỒNG TRONG JAVA")
h2("2.1. Cơ sở lý thuyết")
h3("2.1.1. Khái niệm Thread")
p("Thread (luồng) là đơn vị thực thi nhỏ nhất trong một tiến trình. Một tiến trình Java có thể có nhiều thread chạy song song, chia sẻ bộ nhớ heap nhưng có stack riêng.")
p("Java hỗ trợ đa luồng từ phiên bản đầu tiên, thông qua lớp Thread và interface Runnable.")
h3("2.1.2. Mô hình thực thi song song")
p("JVM sử dụng bộ lập lịch (scheduler) của hệ điều hành để phân chia thời gian CPU cho các thread. Trên máy nhiều nhân, các thread thực sự chạy song song; trên máy một nhân, chúng chạy luân phiên (time-slicing).")
h3("2.1.3. Cấu trúc Thread, Runnable, ExecutorService")
p("Thread:")
for b in [
    "Lớp cơ bản để tạo luồng.",
    "Kế thừa Thread và override run().",
    "Gọi start() để bắt đầu luồng (không gọi run() trực tiếp).",
]:
    bullet(b)
p("Runnable:")
for b in [
    "Interface functional với một phương thức run().",
    "Tách logic khỏi luồng — khuyến nghị dùng vì cho phép kế thừa lớp khác.",
    "Có thể dùng lambda: Runnable r = () -> { ... };",
]:
    bullet(b)
p("ExecutorService:")
for b in [
    "Quản lý thread pool, tái sử dụng luồng.",
    "Tránh chi phí tạo/hủy luồng liên tục.",
    "Cung cấp submit(), invokeAll(), invokeAny()...",
    "Có thể shutdown() để giải phóng tài nguyên.",
]:
    bullet(b)
h3("2.1.4. Đồng bộ hóa")
p("Khi nhiều thread cùng truy cập tài nguyên chia sẻ, cần đồng bộ để tránh race condition. Java cung cấp:")
for b in [
    "synchronized (phương thức hoặc khối).",
    "ReentrantLock (khóa tường minh).",
    "AtomicInteger, AtomicLong (biến nguyên tử).",
    "ConcurrentHashMap, CopyOnWriteArrayList (collection an toàn).",
]:
    bullet(b)

h2("2.2. Phân tích")
p("Việc chọn cơ chế tạo luồng phụ thuộc vào nhu cầu:")
for b in [
    "Nếu chỉ cần chạy một task đơn giản: dùng Thread hoặc Runnable.",
    "Nếu cần chạy nhiều task: dùng ExecutorService với thread pool.",
    "Nếu cần lấy kết quả trả về: dùng Callable + Future.",
    "Nếu cần đồng bộ: dùng synchronized hoặc Lock.",
]:
    bullet(b)
p("Lưu ý: lạm dụng synchronized có thể gây deadlock hoặc giảm hiệu năng. Nên cân nhắc AtomicInteger cho phép toán đơn giản, ConcurrentHashMap cho collection.")

h2("2.3. Ví dụ thực hành")
h3("2.3.1. Tạo luồng bằng Thread và Runnable")
code("""// Cách 1: kế thừa Thread
class MyThread extends Thread {
    public void run() {
        System.out.println("Chạy trong luồng: " + getName());
    }
}
new MyThread().start();

// Cách 2: Runnable + lambda
Runnable task = () -> System.out.println("Chạy trong luồng: " + Thread.currentThread().getName());
new Thread(task).start();""")
h3("2.3.2. ExecutorService với thread pool")
code("""ExecutorService pool = Executors.newFixedThreadPool(4);
for (int i = 0; i < 10; i++) {
    pool.submit(() -> System.out.println("Task trong " + Thread.currentThread().getName()));
}
pool.shutdown();""")
h3("2.3.3. Callable + Future để lấy kết quả")
code("""ExecutorService pool = Executors.newSingleThreadExecutor();
Future<Integer> future = pool.submit(() -> {
    Thread.sleep(1000);
    return 42;
});
System.out.println("Kết quả: " + future.get()); // chờ và lấy kết quả
pool.shutdown();""")
h3("2.3.4. Đồng bộ với synchronized")
code("""class Counter {
    private int count = 0;
    public synchronized void increment() { count++; }
    public int getCount() { return count; }
}""")

h2("2.4. Kết quả thực nghiệm")
p("Với ExecutorService newFixedThreadPool(4), 10 task được phân bổ cho 4 luồng, các luồng được tái sử dụng. Với Counter không synchronized, chạy 3 thread × 1000 lần increment có thể ra kết quả < 3000 do race condition. Với synchronized, kết quả luôn đúng 3000.")

h2("2.5. Nhận xét")
p("Đa luồng giúp tận dụng CPU đa nhân, tăng hiệu năng ứng dụng. Tuy nhiên cần cẩn trọng với race condition và deadlock. ExecutorService là cách hiện đại và an toàn để quản lý luồng.")

h2("2.6. Ứng dụng thực tế")
for b in [
    "Server xử lý nhiều client đồng thời.",
    "Ứng dụng tải dữ liệu song song (web crawler, download manager).",
    "Xử lý ảnh/video theo batch.",
    "Game online, ứng dụng realtime.",
]:
    bullet(b)
doc.add_page_break()

# ===== CHƯƠNG 3 =====
h1("CHƯƠNG 3: MÔ HÌNH CLIENT–SERVER TRONG LẬP TRÌNH MẠNG TCP/IP")
h2("3.1. Cơ sở lý thuyết")
h3("3.1.1. Kiến trúc 2 tầng")
p("Mô hình Client–Server gồm hai thành phần:")
for b in [
    "Client: khởi tạo kết nối, gửi yêu cầu, nhận phản hồi.",
    "Server: lắng nghe trên một cổng, chấp nhận kết nối, xử lý yêu cầu, gửi phản hồi.",
]:
    bullet(b)
p("Giao tiếp qua TCP/IP — giao thức tin cậy, đảm bảo thứ tự và toàn vẹn dữ liệu.")
h3("3.1.2. Cơ chế kết nối")
p("Quy trình thiết lập kết nối TCP (bắt tay 3 bước):")
num("Client gửi SYN tới server.")
num("Server trả lời SYN-ACK.")
num("Client gửi ACK, kết nối được thiết lập.")
h3("3.1.3. Tạo socket và stream")
p("Trong Java:")
for b in [
    "Server tạo ServerSocket(port) và gọi accept() — block chờ client.",
    "Client tạo Socket(host, port) — kết nối tới server.",
    "Hai bên trao đổi qua InputStream/OutputStream của socket.",
    "Đóng kết nối bằng close().",
]:
    bullet(b)
h3("3.1.4. Đóng gói dữ liệu")
p("Có nhiều cách đóng gói dữ liệu qua socket:")
for b in [
    "Văn bản: BufferedReader/PrintWriter, đọc/ghi theo dòng.",
    "Kiểu nguyên thủy: DataInputStream/DataOutputStream (readInt, writeInt...).",
    "Object: ObjectInputStream/ObjectOutputStream (cần Serializable).",
    "JSON/XML: dùng thư viện ngoài (Jackson, Gson).",
]:
    bullet(b)

h2("3.2. Phân tích")
p("Mô hình Client–Server có ưu điểm:")
for b in [
    "Tập trung xử lý logic tại server, client nhẹ.",
    "Dễ bảo trì, nâng cấp server mà không cần cập nhật client.",
    "Hỗ trợ nhiều client đồng thời (nếu server dùng thread pool).",
]:
    bullet(b)
p("Nhược điểm:")
for b in [
    "Server là điểm nghẽn (single point of failure).",
    "Cần bảo mật kết nối (SSL/TLS).",
    "Độ trễ phụ thuộc mạng.",
]:
    bullet(b)

h2("3.3. Ví dụ thực hành")
h3("3.3.1. Server đơn giản")
code("""ServerSocket server = new ServerSocket(5000);
System.out.println("Server đang chờ...");
Socket client = server.accept();
BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
PrintWriter out = new PrintWriter(client.getOutputStream(), true);
out.println("Hello Client");
String line = in.readLine();
System.out.println("Client gửi: " + line);
client.close();
server.close();""")
h3("3.3.2. Client đơn giản")
code("""Socket socket = new Socket("localhost", 5000);
BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
System.out.println("Server nói: " + in.readLine());
out.println("Chào server!");
socket.close();""")
h3("3.3.3. Server đa client với ExecutorService")
code("""ServerSocket server = new ServerSocket(5000);
ExecutorService pool = Executors.newFixedThreadPool(10);
while (true) {
    Socket client = server.accept();
    pool.submit(() -> handleClient(client));
}""")

h2("3.4. Kết quả thực nghiệm")
p("Chạy server và client, client nhận được chuỗi Hello Client, server nhận được Chào server!. Với ExecutorService, server phục vụ đồng thời 10 client mà không bị block.")

h2("3.5. Nhận xét")
p("Socket TCP là nền tảng của nhiều giao thức ứng dụng (HTTP, FTP, SMTP). Cần xử lý IOException, đóng tài nguyên đúng cách, và có thể dùng ExecutorService để phục vụ nhiều client.")

h2("3.6. Ứng dụng thực tế")
for b in [
    "Chat server/client.",
    "Web server đơn giản (HTTP).",
    "Truyền file (FTP).",
    "Game online, điều khiển từ xa.",
]:
    bullet(b)
doc.add_page_break()

# ===== CHƯƠNG 4 =====
h1("CHƯƠNG 4: SO SÁNH TCP VÀ UDP")
h2("4.1. Cơ sở lý thuyết")
h3("4.1.1. TCP")
p("TCP (Transmission Control Protocol) là giao thức hướng kết nối, tin cậy, đảm bảo thứ tự và toàn vẹn dữ liệu. TCP thực hiện bắt tay 3 bước, kiểm tra lỗi, truyền lại gói mất, kiểm soát luồng và tắc nghẽn.")
h3("4.1.2. UDP")
p("UDP (User Datagram Protocol) là giao thức không kết nối, không đảm bảo tin cậy. UDP gửi từng datagram độc lập, không xác nhận, không truyền lại. Đổi lại, UDP có độ trễ thấp và tốc độ cao.")
h3("4.1.3. Bảng so sánh")
t = doc.add_table(rows=1, cols=3); t.style = "Table Grid"
h = t.rows[0].cells
h[0].text="Tiêu chí"; h[1].text="TCP"; h[2].text="UDP"
for r in [
    ("Kết nối", "Có kết nối (connection-oriented)", "Không kết nối (connectionless)"),
    ("Độ tin cậy", "Cao — đảm bảo thứ tự, truyền lại khi mất gói", "Không đảm bảo — có thể mất, trùng, sai thứ tự"),
    ("Tốc độ", "Chậm hơn (kiểm tra, bắt tay)", "Nhanh hơn, độ trễ thấp"),
    ("Kích thước gói", "Stream — không giới hạn", "Datagram — tối đa ~64KB"),
    ("Broadcast/Multicast", "Không hỗ trợ", "Hỗ trợ"),
    ("Ứng dụng", "Web (HTTP), email, FTP, SSH", "Streaming, game online, VoIP, DNS, DHCP"),
]:
    c = t.add_row().cells
    for i, v in enumerate(r): c[i].text = v

h2("4.2. Phân tích")
h3("4.2.1. Cơ chế truyền không kết nối & datagram")
p("UDP gửi từng datagram độc lập, mỗi gói tự chứa địa chỉ đích. Không có bắt tay, không có xác nhận. Nếu gói mất, UDP không truyền lại — ứng dụng phải tự xử lý nếu cần.")
h3("4.2.2. Khi nào nên dùng UDP")
for b in [
    "Cần tốc độ/độ trễ thấp hơn độ tin cậy tuyệt đối.",
    "Video/audio realtime (mất vài gói không ảnh hưởng nhiều).",
    "Game online (ưu tiên phản hồi nhanh).",
    "DNS, DHCP (truy vấn ngắn, có thể thử lại).",
    "Broadcast/multicast (gửi tới nhiều đích).",
]:
    bullet(b)
h3("4.2.3. Khi nào nên dùng TCP")
for b in [
    "Cần toàn vẹn dữ liệu (file transfer, HTTP, email).",
    "Cần đảm bảo thứ tự (chat, database).",
    "Cần kết nối ổn định lâu dài.",
]:
    bullet(b)

h2("4.3. Ví dụ thực hành")
h3("4.3.1. UDP client/server đơn giản")
code("""// UDP Server
DatagramSocket socket = new DatagramSocket(5000);
byte[] buf = new byte[1024];
DatagramPacket packet = new DatagramPacket(buf, buf.length);
socket.receive(packet);
String msg = new String(packet.getData(), 0, packet.getLength());
System.out.println("Nhận: " + msg);

// UDP Client
DatagramSocket socket = new DatagramSocket();
String msg = "Hello UDP";
byte[] buf = msg.getBytes();
InetAddress addr = InetAddress.getByName("localhost");
DatagramPacket packet = new DatagramPacket(buf, buf.length, addr, 5000);
socket.send(packet);""")

h2("4.4. Kết quả thực nghiệm")
p("UDP client gửi Hello UDP, server nhận đúng chuỗi. Nếu gói bị mất (do mạng), UDP không truyền lại — client phải gửi lại nếu cần.")

h2("4.5. Nhận xét")
p("TCP và UDP có trade-off giữa độ tin cậy và tốc độ. Việc chọn giao thức phụ thuộc vào yêu cầu ứng dụng. Đa số ứng dụng web dùng TCP; ứng dụng realtime thường dùng UDP.")

h2("4.6. Ứng dụng thực tế")
for b in [
    "TCP: HTTP/HTTPS, FTP, SMTP, SSH, database connection.",
    "UDP: DNS, DHCP, VoIP, video streaming, game online, multicast.",
]:
    bullet(b)
doc.add_page_break()

# ===== CHƯƠNG 5 =====
h1("CHƯƠNG 5: TỔNG QUAN RMI TRONG JAVA")
h2("5.1. Cơ sở lý thuyết")
h3("5.1.1. Khái niệm RMI")
p("RMI (Remote Method Invocation) cho phép một chương trình Java gọi phương thức của object nằm ở JVM khác (khác máy hoặc khác process) như thể gọi local. RMI che giấu chi tiết marshalling/unmarshalling và truyền tải mạng.")
h3("5.1.2. Cơ chế gọi phương thức từ xa")
p("Quy trình:")
num("Client gọi phương thức trên Stub (proxy của remote object).")
num("Stub marshalling tham số (chuyển thành dữ liệu mạng).")
num("Stub gửi yêu cầu qua mạng tới Skeleton.")
num("Skeleton unmarshalling, gọi phương thức thực trên object.")
num("Skeleton marshalling kết quả, gửi ngược về Stub.")
num("Stub unmarshalling, trả kết quả cho client.")
h3("5.1.3. Kiến trúc 3 thành phần")
p("Stub: proxy phía client, chuyển lời gọi thành dữ liệu mạng.")
p("Skeleton: phía server, nhận dữ liệu, gọi phương thức thật, gửi kết quả về. Từ Java 2 trở đi, skeleton được tích hợp vào RMI runtime.")
p("Registry: dịch vụ đăng ký/tra cứu tên → tham chiếu remote object. Server đăng ký bằng Naming.rebind hoặc registry.rebind; client tra cứu bằng Naming.lookup hoặc registry.lookup.")
h3("5.1.4. Yêu cầu")
for b in [
    "Interface remote phải kế thừa java.rmi.Remote.",
    "Mỗi phương thức phải khai báo throws RemoteException.",
    "Implementation kế thừa UnicastRemoteObject (hoặc export thủ công).",
    "Tham số/giá trị trả về phải Serializable.",
]:
    bullet(b)

h2("5.2. Phân tích")
p("Ưu điểm RMI:")
for b in [
    "Đơn giản hóa lập trình phân tán trong Java.",
    "Che giấu chi tiết mạng, marshalling.",
    "Tích hợp sẵn trong JDK, không cần thư viện ngoài.",
]:
    bullet(b)
p("Nhược điểm:")
for b in [
    "Gắn chặt với Java (không đa ngôn ngữ như REST/gRPC).",
    "Cần mở port 1099 trên firewall nếu chạy khác máy.",
    "Hiệu năng thấp hơn gRPC trong một số trường hợp.",
]:
    bullet(b)

h2("5.3. Ví dụ thực hành")
h3("5.3.1. Interface Hello")
code("""public interface Hello extends Remote {
    String sayHello() throws RemoteException;
}""")
h3("5.3.2. Implementation HelloImpl")
code("""public class HelloImpl extends UnicastRemoteObject implements Hello {
    public HelloImpl() throws RemoteException { super(); }
    public String sayHello() throws RemoteException {
        System.out.println("Server đã được gọi từ xa");
        return "Hello từ RMI Server!";
    }
}""")
h3("5.3.3. Server")
code("""Registry registry = LocateRegistry.createRegistry(1099);
registry.rebind("HelloService", new HelloImpl());
System.out.println("RMI Server sẵn sàng");""")
h3("5.3.4. Client")
code("""Registry registry = LocateRegistry.getRegistry("localhost", 1099);
Hello hello = (Hello) registry.lookup("HelloService");
System.out.println(hello.sayHello());""")

h2("5.4. Kết quả thực nghiệm")
p("Chạy server trước, sau đó client. Client nhận chuỗi Hello từ RMI Server!, server log Server đã được gọi từ xa. Kết nối RMI hoạt động đúng.")

h2("5.5. Nhận xét")
p("RMI là nền tảng để hiểu các công nghệ cao hơn như EJB, Spring Remoting. Trên JDK 17+ không cần chạy rmic — stub được sinh động.")

h2("5.6. Ứng dụng thực tế")
for b in [
    "Hệ thống phân tán trong doanh nghiệp.",
    "Gọi dịch vụ từ xa trong ứng dụng Java.",
    "Nền tảng học EJB, Spring Remoting.",
]:
    bullet(b)
doc.add_page_break()

# ===== CHƯƠNG 6 =====
h1("CHƯƠNG 6: BẢO MẬT TRONG LẬP TRÌNH MẠNG JAVA")
h2("6.1. Cơ sở lý thuyết")
h3("6.1.1. Các lớp mã hóa & chứng thực")
p("Mã hóa đối xứng: AES, DES (nhanh, dùng chung khóa).")
p("Mã hóa bất đối xứng: RSA, DSA/ECDSA (cặp khóa công khai – riêng tư).")
p("Hàm băm: SHA-256, MD5 (kiểm tra toàn vẹn).")
p("Chứng thực: chữ ký số, chứng chỉ số (X.509).")
h3("6.1.2. SSL/TLS")
p("SSL/TLS là giao thức bảo mật tầng transport — mã hóa kênh truyền, xác thực server/client, đảm bảo toàn vẹn. Java dùng SSLSocket, SSLServerSocket, SSLContext.")
h3("6.1.3. Java Security API")
p("Gói java.security, javax.crypto, javax.net.ssl cung cấp:")
for b in [
    "MessageDigest — tính hash.",
    "Cipher — mã hóa/giải mã.",
    "KeyGenerator — sinh khóa đối xứng.",
    "KeyPairGenerator — sinh cặp khóa bất đối xứng.",
    "Signature — ký/kiểm tra chữ ký số.",
]:
    bullet(b)
h3("6.1.4. KeyStore")
p("KeyStore là kho lưu khóa và chứng chỉ (.jks/.p12). Dùng lưu private key, certificate, trust store.")

h2("6.2. Phân tích")
p("Bảo mật trong lập trình mạng gồm 3 khía cạnh:")
for b in [
    "Confidentiality (bí mật): mã hóa dữ liệu.",
    "Integrity (toàn vẹn): hash, chữ ký số.",
    "Authentication (xác thực): chứng chỉ số, SSL/TLS.",
]:
    bullet(b)

h2("6.3. Ví dụ thực hành")
h3("6.3.1. Tính hash SHA-256")
code("""MessageDigest md = MessageDigest.getInstance("SHA-256");
byte[] hash = md.digest("Hello".getBytes());
System.out.println(bytesToHex(hash));""")
h3("6.3.2. Mã hóa AES")
code("""KeyGenerator kg = KeyGenerator.getInstance("AES");
kg.init(256);
SecretKey key = kg.generateKey();
Cipher cipher = Cipher.getInstance("AES");
cipher.init(Cipher.ENCRYPT_MODE, key);
byte[] encrypted = cipher.doFinal("Hello".getBytes());""")
h3("6.3.3. Nạp KeyStore")
code("""KeyStore ks = KeyStore.getInstance("JKS");
ks.load(new FileInputStream("keystore.jks"), "password".toCharArray());""")

h2("6.4. Kết quả thực nghiệm")
p("Tính hash SHA-256 của chuỗi Hello cho ra 64 ký tự hex. Mã hóa AES hoạt động đúng, giải mã trả về chuỗi gốc. Nạp KeyStore thành công.")

h2("6.5. Nhận xét")
p("Bảo mật là yêu cầu bắt buộc trong ứng dụng mạng hiện đại. SSL/TLS là giải pháp phổ biến nhất, kết hợp mã hóa đối xứng (nhanh) và bất đối xứng (trao đổi khóa an toàn).")

h2("6.6. Ứng dụng thực tế")
for b in [
    "HTTPS cho web.",
    "Bảo mật socket (chat, file transfer).",
    "Xác thực hai chiều trong hệ thống phân tán.",
]:
    bullet(b)
doc.add_page_break()

# ===== KẾT LUẬN =====
h1("KẾT LUẬN VÀ HƯỚNG PHÁT TRIỂN")
h2("Kết luận")
p("Qua 6 chủ đề, báo cáo đã trình bày và phân tích được:")
for b in [
    "Cơ chế luồng dữ liệu (byte/ký tự), phân loại và ứng dụng.",
    "Lập trình đa luồng với Thread, Runnable, ExecutorService.",
    "Mô hình Client–Server TCP/IP, cơ chế kết nối và đóng gói dữ liệu.",
    "So sánh TCP và UDP, khi nào dùng UDP.",
    "Kiến trúc RMI 3 thành phần (Stub – Skeleton – Registry).",
    "Các lớp bảo mật: SSL/TLS, Java Security API, KeyStore.",
]:
    bullet(b)
h2("Hướng phát triển")
for b in [
    "Áp dụng Stream vào ứng dụng truyền file có checksum (MD5/SHA-256).",
    "Nâng cấp mô hình đa luồng với CompletableFuture, ForkJoinPool.",
    "Xây dựng server TCP đa client với ExecutorService.",
    "Kết hợp RMI với SSL/TLS để bảo mật lời gọi từ xa.",
    "Nghiên cứu thêm NIO/Netty cho ứng dụng mạng hiệu năng cao.",
]:
    bullet(b)

# ===== TÀI LIỆU =====
h1("TÀI LIỆU THAM KHẢO")
for i, ref in enumerate([
    "Oracle. Java SE Documentation – Java I/O, Networking, RMI. https://docs.oracle.com/javase/",
    "Herbert Schildt. Java: The Complete Reference, 12th Edition. McGraw-Hill, 2021.",
    "Cay S. Horstmann. Core Java Volume II — Advanced Features, 11th Edition. Pearson, 2019.",
    "Apache NetBeans Documentation. https://netbeans.apache.org/",
    "Baeldung. Java Networking Tutorials, Java RMI Guide. https://www.baeldung.com/",
], 1):
    p(f"[{i}] {ref}")

# ===== PHỤ LỤC =====
h1("PHỤ LỤC: CÂU HỎI ÔN TẬP")
h2("Chương 1")
for q in [
    "Phân biệt InputStream và Reader. Khi nào dùng loại nào?",
    "Tại sao nên dùng Buffered stream?",
    "try-with-resources hoạt động như thế nào?",
]:
    bullet(q)
h2("Chương 2")
for q in [
    "Phân biệt Thread và Runnable. Tại sao khuyến nghị dùng Runnable?",
    "ExecutorService là gì? Lợi ích so với tạo Thread trực tiếp?",
    "Race condition là gì? Cách phòng tránh?",
]:
    bullet(q)
h2("Chương 3")
for q in [
    "Mô tả quy trình bắt tay 3 bước của TCP.",
    "ServerSocket và Socket khác nhau thế nào?",
    "Làm sao để server phục vụ nhiều client đồng thời?",
]:
    bullet(q)
h2("Chương 4")
for q in [
    "So sánh TCP và UDP về độ tin cậy, tốc độ, ứng dụng.",
    "Khi nào nên dùng UDP thay vì TCP?",
    "Datagram là gì?",
]:
    bullet(q)
h2("Chương 5")
for q in [
    "RMI là gì? Kiến trúc 3 thành phần gồm những gì?",
    "Yêu cầu để một interface trở thành remote interface?",
    "Registry trong RMI có vai trò gì?",
]:
    bullet(q)
h2("Chương 6")
for q in [
    "Phân biệt mã hóa đối xứng và bất đối xứng.",
    "SSL/TLS hoạt động như thế nào?",
    "KeyStore là gì? Dùng để làm gì?",
]:
    bullet(q)

doc.save("1-GK-Tra-Loi.docx")
print("Đã tạo: 1-GK-Tra-Loi.docx")
PYEOF
rm -rf "$(dirname "$TMPVENV")"'