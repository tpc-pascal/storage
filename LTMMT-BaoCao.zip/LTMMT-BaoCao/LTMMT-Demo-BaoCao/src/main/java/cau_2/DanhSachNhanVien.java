package cau_2;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.*;

/**
 * ỨNG DỤNG QUẢN LÝ NHÂN VIÊN (CSV)
 * - Thêm / sửa / xóa / tìm kiếm nhân viên
 * - Đọc/ghi CSV chuẩn (xử lý dấu phẩy, ngoặc kép, UTF-8 BOM)
 * - Thống kê lương, sắp xếp, xuất báo cáo
 *
 * @author tpc-pascal
 */
public class DanhSachNhanVien {

    private static final Scanner sc = new Scanner(System.in);
    private static final String CSV_FILE = "employee.csv";
    private static final String HEADER = "ID,HoTen,PhongBan,Luong";
    private static final DecimalFormat MONEY = new DecimalFormat("#,###");

    // Danh sách nhân viên trong bộ nhớ
    private static final List<NhanVien> ds = new ArrayList<>();

    public static void main(String[] args) {
        // Nạp dữ liệu có sẵn (nếu file tồn tại)
        loadFromCSV();

        while (true) {
            printMenu();
            int choice = readInt("Chọn chức năng: ");
            switch (choice) {
                case 1 -> themNhanVien();
                case 2 -> hienThiDanhSach();
                case 3 -> suaNhanVien();
                case 4 -> xoaNhanVien();
                case 5 -> timKiem();
                case 6 -> thongKe();
                case 7 -> sapXep();
                case 8 -> luuCSV();
                case 9 -> xuatBaoCao();
                case 0 -> { System.out.println("Tạm biệt!"); return; }
                default -> System.out.println("Lựa chọn không hợp lệ!");
            }
            System.out.println();
        }
    }

    // ================= MENU =================
    private static void printMenu() {
        System.out.println("========== QUẢN LÝ NHÂN VIÊN ==========");
        System.out.println("1. Thêm nhân viên");
        System.out.println("2. Hiển thị danh sách");
        System.out.println("3. Sửa nhân viên");
        System.out.println("4. Xóa nhân viên");
        System.out.println("5. Tìm kiếm");
        System.out.println("6. Thống kê lương");
        System.out.println("7. Sắp xếp");
        System.out.println("8. Lưu ra CSV");
        System.out.println("9. Xuất báo cáo TXT");
        System.out.println("0. Thoát");
        System.out.println("=======================================");
        System.out.println("Số nhân viên hiện tại: " + ds.size());
    }

    // ================= 1. THÊM =================
    private static void themNhanVien() {
        System.out.println("--- THÊM NHÂN VIÊN ---");
        String id;
        while (true) {
            id = readString("ID: ");
            if (id.isEmpty()) { System.out.println("⚠ ID không được rỗng."); continue; }
            if (findById(id) != null) { System.out.println("⚠ ID đã tồn tại."); continue; }
            break;
        }
        String ten = readString("Họ tên: ");
        String phong = readString("Phòng ban: ");
        double luong = readDouble("Lương: ");

        ds.add(new NhanVien(id, ten, phong, luong));
        System.out.println("✅ Đã thêm: " + id);
    }

    // ================= 2. HIỂN THỊ =================
    private static void hienThiDanhSach() {
        if (ds.isEmpty()) { System.out.println("(Danh sách rỗng)"); return; }
        System.out.println("--- DANH SÁCH NHÂN VIÊN ---");
        System.out.printf("%-8s %-25s %-15s %15s%n", "ID", "Họ tên", "Phòng ban", "Lương");
        System.out.println("-".repeat(70));
        for (NhanVien nv : ds) {
            System.out.printf("%-8s %-25s %-15s %15s%n",
                    nv.id, nv.ten, nv.phong, MONEY.format(nv.luong));
        }
        System.out.println("-".repeat(70));
    }

    // ================= 3. SỬA =================
    private static void suaNhanVien() {
        String id = readString("ID cần sửa: ");
        NhanVien nv = findById(id);
        if (nv == null) { System.out.println("❌ Không tìm thấy."); return; }

        System.out.println("(Enter để giữ nguyên giá trị cũ)");
        String ten = readStringOrNull("Họ tên [" + nv.ten + "]: ");
        String phong = readStringOrNull("Phòng ban [" + nv.phong + "]: ");
        String luongStr = readStringOrNull("Lương [" + MONEY.format(nv.luong) + "]: ");

        if (ten != null) nv.ten = ten;
        if (phong != null) nv.phong = phong;
        if (luongStr != null) {
            try { nv.luong = Double.parseDouble(luongStr); }
            catch (NumberFormatException e) { System.out.println("⚠ Lương không hợp lệ, giữ nguyên."); }
        }
        System.out.println("✅ Đã cập nhật.");
    }

    // ================= 4. XÓA =================
    private static void xoaNhanVien() {
        String id = readString("ID cần xóa: ");
        NhanVien nv = findById(id);
        if (nv == null) { System.out.println("❌ Không tìm thấy."); return; }
        String confirm = readString("Xác nhận xóa '" + nv.ten + "'? (y/N): ");
        if (confirm.equalsIgnoreCase("y")) {
            ds.remove(nv);
            System.out.println("✅ Đã xóa.");
        } else {
            System.out.println("Đã hủy.");
        }
    }

    // ================= 5. TÌM KIẾM =================
    private static void timKiem() {
        System.out.println("1. Tìm theo ID");
        System.out.println("2. Tìm theo tên (chứa)");
        System.out.println("3. Tìm theo phòng ban");
        int c = readInt("Chọn: ");
        List<NhanVien> kq = new ArrayList<>();

        switch (c) {
            case 1 -> {
                String id = readString("ID: ");
                NhanVien nv = findById(id);
                if (nv != null) kq.add(nv);
            }
            case 2 -> {
                String kw = readString("Từ khóa tên: ").toLowerCase();
                for (NhanVien nv : ds) if (nv.ten.toLowerCase().contains(kw)) kq.add(nv);
            }
            case 3 -> {
                String kw = readString("Phòng ban: ").toLowerCase();
                for (NhanVien nv : ds) if (nv.phong.toLowerCase().contains(kw)) kq.add(nv);
            }
            default -> { System.out.println("Lựa chọn không hợp lệ."); return; }
        }

        if (kq.isEmpty()) System.out.println("(Không có kết quả)");
        else {
            System.out.println("--- KẾT QUẢ (" + kq.size() + ") ---");
            for (NhanVien nv : kq) System.out.println(nv);
        }
    }

    // ================= 6. THỐNG KÊ =================
    private static void thongKe() {
        if (ds.isEmpty()) { System.out.println("(Danh sách rỗng)"); return; }

        double tong = 0, max = Double.MIN_VALUE, min = Double.MAX_VALUE;
        Map<String, Double> theoPhong = new TreeMap<>();
        Map<String, Integer> demPhong = new TreeMap<>();

        for (NhanVien nv : ds) {
            tong += nv.luong;
            max = Math.max(max, nv.luong);
            min = Math.min(min, nv.luong);
            theoPhong.merge(nv.phong, nv.luong, Double::sum);
            demPhong.merge(nv.phong, 1, Integer::sum);
        }

        System.out.println("--- THỐNG KÊ ---");
        System.out.println("Tổng nhân viên : " + ds.size());
        System.out.println("Tổng lương     : " + MONEY.format(tong));
        System.out.println("Lương TB       : " + MONEY.format(tong / ds.size()));
        System.out.println("Lương cao nhất : " + MONEY.format(max));
        System.out.println("Lương thấp nhất: " + MONEY.format(min));
        System.out.println("\nTheo phòng ban:");
        for (String p : theoPhong.keySet()) {
            System.out.printf("  %-15s %2d người, tổng %s%n",
                    p, demPhong.get(p), MONEY.format(theoPhong.get(p)));
        }
    }

    // ================= 7. SẮP XẾP =================
    private static void sapXep() {
        System.out.println("1. Theo ID tăng dần");
        System.out.println("2. Theo tên A-Z");
        System.out.println("3. Theo lương giảm dần");
        int c = readInt("Chọn: ");
        switch (c) {
            case 1 -> ds.sort(Comparator.comparing(nv -> nv.id));
            case 2 -> ds.sort(Comparator.comparing(nv -> nv.ten));
            case 3 -> ds.sort(Comparator.comparingDouble((NhanVien nv) -> nv.luong).reversed());
            default -> { System.out.println("Lựa chọn không hợp lệ."); return; }
        }
        System.out.println("✅ Đã sắp xếp.");
        hienThiDanhSach();
    }

    // ================= 8. LƯU CSV =================
    private static void luuCSV() {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(CSV_FILE), StandardCharsets.UTF_8)) {
            w.write(0xFEFF); // BOM cho Excel
            try (PrintWriter pw = new PrintWriter(w)) {
                pw.println(HEADER);
                for (NhanVien nv : ds) {
                    pw.printf("%s,%s,%s,%s%n",
                            csvEscape(nv.id), csvEscape(nv.ten),
                            csvEscape(nv.phong), nv.luong);
                }
            }
            System.out.println("✅ Đã lưu " + ds.size() + " nhân viên vào " + CSV_FILE);
        } catch (IOException e) {
            System.out.println("❌ Lỗi ghi file: " + e.getMessage());
        }
    }

    // ================= 9. XUẤT BÁO CÁO =================
    private static void xuatBaoCao() {
        String fname = "baocao_nhanvien.txt";
        try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(fname), StandardCharsets.UTF_8))) {
            pw.println("BÁO CÁO DANH SÁCH NHÂN VIÊN");
            pw.println("Ngày xuất: " + new Date());
            pw.println("=".repeat(70));
            double tong = 0;
            for (NhanVien nv : ds) {
                pw.println(nv);
                tong += nv.luong;
            }
            pw.println("=".repeat(70));
            pw.println("Tổng nhân viên: " + ds.size());
            pw.println("Tổng lương    : " + MONEY.format(tong));
            System.out.println("✅ Đã xuất báo cáo: " + fname);
        } catch (IOException e) {
            System.out.println("❌ Lỗi ghi file: " + e.getMessage());
        }
    }

    // ================= NẠP CSV =================
    private static void loadFromCSV() {
        File f = new File(CSV_FILE);
        if (!f.exists()) return;

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) { first = false; if (line.startsWith("\uFEFF")) line = line.substring(1); }
                if (line.equalsIgnoreCase(HEADER)) continue;
                if (line.isBlank()) continue;

                List<String> fields = parseCSVLine(line);
                if (fields.size() < 4) continue;
                try {
                    ds.add(new NhanVien(fields.get(0), fields.get(1),
                            fields.get(2), Double.parseDouble(fields.get(3))));
                } catch (NumberFormatException ignored) {}
            }
            System.out.println("Đã nạp " + ds.size() + " nhân viên từ " + CSV_FILE);
        } catch (IOException e) {
            System.out.println("⚠ Không đọc được " + CSV_FILE + ": " + e.getMessage());
        }
    }

    // ================= CSV HELPERS =================
    /** Bọc trường trong ngoặc kép nếu chứa dấu phẩy / ngoặc kép / xuống dòng */
    private static String csvEscape(String s) {
        if (s == null) return "";
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }

    /** Parse 1 dòng CSV có hỗ trợ ngoặc kép */
    private static List<String> parseCSVLine(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') {
                        cur.append('"'); i++;
                    } else inQuotes = false;
                } else cur.append(c);
            } else {
                if (c == '"') inQuotes = true;
                else if (c == ',') { result.add(cur.toString()); cur.setLength(0); }
                else cur.append(c);
            }
        }
        result.add(cur.toString());
        return result;
    }

    // ================= TIỆN ÍCH NHẬP =================
    private static String readString(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = sc.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("⚠ Không được để rỗng.");
        }
    }

    private static String readStringOrNull(String prompt) {
        System.out.print(prompt);
        String s = sc.nextLine().trim();
        return s.isEmpty() ? null : s;
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try { return Integer.parseInt(sc.nextLine().trim()); }
            catch (NumberFormatException e) { System.out.println("⚠ Vui lòng nhập số nguyên."); }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try { return Double.parseDouble(sc.nextLine().trim()); }
            catch (NumberFormatException e) { System.out.println("⚠ Vui lòng nhập số."); }
        }
    }

    private static NhanVien findById(String id) {
        for (NhanVien nv : ds) if (nv.id.equalsIgnoreCase(id)) return nv;
        return null;
    }

    // ================= MODEL =================
    static class NhanVien {
        String id, ten, phong;
        double luong;

        NhanVien(String id, String ten, String phong, double luong) {
            this.id = id; this.ten = ten; this.phong = phong; this.luong = luong;
        }

        @Override
        public String toString() {
            return String.format("%-8s %-25s %-15s %15s",
                    id, ten, phong, MONEY.format(luong));
        }
    }
}