package cau_2;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.*;
import java.util.List;

/**
 * ỨNG DỤNG GUI — QUẢN LÝ NHÂN VIÊN (Giao diện hiện đại)
 *
 * @author tpc-pascal
 */
public class DanhSachNhanVien extends JFrame {

    // ===== BẢNG MÀU =====
    private static final Color PRIMARY   = new Color(0x2563EB);
    private static final Color SUCCESS   = new Color(0x16A34A);
    private static final Color DANGER    = new Color(0xDC2626);
    private static final Color WARNING   = new Color(0xD97706);
    private static final Color BG        = new Color(0xF8FAFC);
    private static final Color CARD_BG   = Color.WHITE;
    private static final Color TEXT_MUTED= new Color(0x64748B);
    private static final Color BORDER_C  = new Color(0xE2E8F0);
    private static final Color HEADER_BG = new Color(0x1E293B);

    // ===== FONT =====
    private static final Font FONT_TITLE  = new Font("Segoe UI", Font.BOLD, 18);
    private static final Font FONT_SUB    = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font FONT_LABEL  = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_INPUT  = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 13);
    private static final Font FONT_TABLE  = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_THEAD  = new Font("Segoe UI", Font.BOLD, 13);

    // ===== DỮ LIỆU =====
    private static final String CSV = "employee.csv";
    private static final String HEADER = "ID,HoTen,PhongBan,Luong";
    private static final DecimalFormat MONEY = new DecimalFormat("#,###");

    private DefaultTableModel model = null;
    private JTable table;
    private final List<NhanVien> ds = new ArrayList<>();

    private final JTextField txtId    = new JTextField(10);
    private final JTextField txtTen   = new JTextField(20);
    private final JTextField txtPhong = new JTextField(15);
    private final JTextField txtLuong = new JTextField(12);

    private final JLabel lblStatus = new JLabel(" Sẵn sàng");
    private final JLabel lblCount  = new JLabel("0 nhân viên");

    public DanhSachNhanVien() {
        super("Quản lý nhân viên");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 720);
        setMinimumSize(new Dimension(900, 640));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(BG);
        setContentPane(root);

        // ===== HEADER =====
        root.add(buildHeader(), BorderLayout.NORTH);

        // ===== BODY =====
        JPanel body = new JPanel(new BorderLayout(16, 0));
        body.setBackground(BG);
        body.setBorder(new EmptyBorder(16, 16, 16, 16));

        body.add(buildTableCard(), BorderLayout.CENTER);
        body.add(buildFormCard(), BorderLayout.EAST);
        root.add(body, BorderLayout.CENTER);

        // ===== STATUS BAR =====
        root.add(buildStatusBar(), BorderLayout.SOUTH);

        loadCSV();
        refresh();
    }

    // ============================================================
    // HEADER
    // ============================================================
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(PRIMARY);
        header.setBorder(new EmptyBorder(14, 20, 14, 20));

        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setOpaque(false);

        JLabel title = new JLabel("👥  QUẢN LÝ NHÂN VIÊN");
        title.setFont(FONT_TITLE);
        title.setForeground(Color.WHITE);

        JLabel sub = new JLabel("Thêm · Sửa · Xóa · Thống kê · CSV");
        sub.setFont(FONT_SUB);
        sub.setForeground(new Color(0xDBEAFE));

        left.add(title);
        left.add(Box.createVerticalStrut(2));
        left.add(sub);

        lblCount.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblCount.setForeground(Color.WHITE);
        lblCount.setBorder(new EmptyBorder(8, 16, 8, 16));
        lblCount.setOpaque(true);
        lblCount.setBackground(new Color(0x1D4ED8));
        lblCount.setHorizontalAlignment(SwingConstants.CENTER);

        header.add(left, BorderLayout.WEST);
        header.add(lblCount, BorderLayout.EAST);
        return header;
    }

    // ============================================================
    // CARD BẢNG
    // ============================================================
    private JPanel buildTableCard() {
        JPanel card = makeCard("Danh sách nhân viên", "Click vào dòng để xem/sửa");

        model = new DefaultTableModel(new String[]{"ID", "Họ tên", "Phòng ban", "Lương"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setFont(FONT_TABLE);
        table.setRowHeight(32);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setSelectionBackground(new Color(0xDBEAFE));
        table.setSelectionForeground(new Color(0x1E293B));
        table.setFillsViewportHeight(true);

        // Header bảng
        JTableHeader th = table.getTableHeader();
        th.setFont(FONT_THEAD);
        th.setBackground(new Color(0xF1F5F9));
        th.setForeground(new Color(0x334155));
        th.setPreferredSize(new Dimension(0, 38));
        th.setBorder(new MatteBorder(0, 0, 1, 0, BORDER_C));
        th.setReorderingAllowed(false);

        // Căn phải cột Lương
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        table.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);

        // Sự kiện chọn dòng
        table.getSelectionModel().addListSelectionListener(e -> {
            int r = table.getSelectedRow();
            if (r >= 0) {
                txtId.setText((String) model.getValueAt(r, 0));
                txtTen.setText((String) model.getValueAt(r, 1));
                txtPhong.setText((String) model.getValueAt(r, 2));
                txtLuong.setText(String.valueOf(model.getValueAt(r, 3)).replace(",", ""));
                txtId.setEditable(false);
                status("Đang chọn: " + model.getValueAt(r, 0), PRIMARY);
            }
        });

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(BORDER_C, 1, true));
        sp.getViewport().setBackground(Color.WHITE);

        card.add(sp, BorderLayout.CENTER);
        return card;
    }

    // ============================================================
    // CARD FORM + NÚT
    // ============================================================
    private JPanel buildFormCard() {
        JPanel card = makeCard("Thông tin nhân viên", "Nhập và bấm Thêm/Sửa");
        card.setPreferredSize(new Dimension(340, 0));

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);

        content.add(fieldBlock("ID", txtId));
        content.add(Box.createVerticalStrut(10));
        content.add(fieldBlock("Họ tên", txtTen));
        content.add(Box.createVerticalStrut(10));
        content.add(fieldBlock("Phòng ban", txtPhong));
        content.add(Box.createVerticalStrut(10));
        content.add(fieldBlock("Lương", txtLuong));

        content.add(Box.createVerticalStrut(20));

        // Grid nút 2 cột
        JPanel grid = new JPanel(new GridLayout(4, 2, 8, 8));
        grid.setOpaque(false);
        grid.add(btn("➕ Thêm",       SUCCESS, e -> them()));
        grid.add(btn("✏ Sửa",        PRIMARY, e -> sua()));
        grid.add(btn("🗑 Xóa",        DANGER,  e -> xoa()));
        grid.add(btn("🔄 Làm mới",   WARNING, e -> lamMoi()));
        grid.add(btn("💾 Lưu CSV",   new Color(0x7C3AED), e -> luuCSV()));
        grid.add(btn("📂 Nạp CSV",   new Color(0x0891B2), e -> { ds.clear(); loadCSV(); refresh(); }));
        grid.add(btn("📊 Thống kê",  new Color(0xDB2777), e -> thongKe()));
        grid.add(btn("📄 Báo cáo",   new Color(0x475569), e -> baoCao()));

        content.add(grid);
        card.add(content, BorderLayout.CENTER);
        return card;
    }

    private JPanel fieldBlock(String label, JTextField field) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setOpaque(false);

        JLabel lbl = new JLabel(label);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(new Color(0x334155));

        field.setFont(FONT_INPUT);
        field.setPreferredSize(new Dimension(0, 34));
        field.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER_C, 1, true),
                new EmptyBorder(4, 10, 4, 10)));

        p.add(lbl, BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    // ============================================================
    // STATUS BAR
    // ============================================================
    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(new Color(0xF1F5F9));
        bar.setBorder(new MatteBorder(1, 0, 0, 0, BORDER_C));

        lblStatus.setFont(FONT_SUB);
        lblStatus.setForeground(TEXT_MUTED);
        lblStatus.setBorder(new EmptyBorder(8, 16, 8, 16));

        JLabel lblHint = new JLabel("Java Swing · CSV UTF-8");
        lblHint.setFont(FONT_SUB);
        lblHint.setForeground(TEXT_MUTED);
        lblHint.setBorder(new EmptyBorder(8, 16, 8, 16));

        bar.add(lblStatus, BorderLayout.WEST);
        bar.add(lblHint, BorderLayout.EAST);
        return bar;
    }

    // ============================================================
    // HELPER: CARD
    // ============================================================
    private JPanel makeCard(String title, String subtitle) {
        JPanel card = new JPanel(new BorderLayout(0, 12)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 15));
                g2.fillRoundRect(2, 3, getWidth() - 4, getHeight() - 4, 16, 16);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
                g2.setColor(BORDER_C);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(16, 18, 16, 18));

        JPanel head = new JPanel();
        head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
        head.setOpaque(false);

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTitle.setForeground(new Color(0x1E293B));

        JLabel lblSub = new JLabel(subtitle);
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblSub.setForeground(TEXT_MUTED);

        head.add(lblTitle);
        head.add(lblSub);

        card.add(head, BorderLayout.NORTH);
        return card;
    }

    // ============================================================
    // HELPER: BUTTON
    // ============================================================
    private JButton btn(String text, Color bg, ActionListener l) {
        JButton b = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color c = getModel().isRollover() ? bg.darker() : bg;
                if (getModel().isPressed()) c = bg.darker().darker();
                g2.setColor(c);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        b.setFont(FONT_BUTTON);
        b.setForeground(Color.WHITE);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(0, 34));
        b.addActionListener(l);
        return b;
    }

    // ============================================================
    // LOGIC (giữ nguyên)
    // ============================================================
    private void them() {
        try {
            String id = txtId.getText().trim();
            if (id.isEmpty()) { status("⚠ ID không được rỗng", WARNING); return; }
            if (find(id) != null) { status("⚠ ID đã tồn tại", WARNING); return; }
            String ten = txtTen.getText().trim();
            String phong = txtPhong.getText().trim();
            double luong = Double.parseDouble(txtLuong.getText().trim());
            ds.add(new NhanVien(id, ten, phong, luong));
            refresh(); lamMoi();
            status("✅ Đã thêm " + id, SUCCESS);
        } catch (NumberFormatException ex) { status("⚠ Lương phải là số", DANGER); }
    }

    private void sua() {
        int r = table.getSelectedRow();
        if (r < 0) { status("⚠ Chọn 1 dòng để sửa", WARNING); return; }
        try {
            String id = (String) model.getValueAt(r, 0);
            NhanVien nv = find(id);
            if (nv == null) return;
            nv.ten = txtTen.getText().trim();
            nv.phong = txtPhong.getText().trim();
            nv.luong = Double.parseDouble(txtLuong.getText().trim());
            refresh(); lamMoi();
            status("✅ Đã cập nhật " + id, SUCCESS);
        } catch (NumberFormatException ex) { status("⚠ Lương phải là số", DANGER); }
    }

    private void xoa() {
        int r = table.getSelectedRow();
        if (r < 0) { status("⚠ Chọn 1 dòng để xóa", WARNING); return; }
        String id = (String) model.getValueAt(r, 0);
        if (JOptionPane.showConfirmDialog(this, "Xóa nhân viên " + id + "?",
                "Xác nhận", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            ds.removeIf(nv -> nv.id.equals(id));
            refresh(); lamMoi();
            status("✅ Đã xóa " + id, SUCCESS);
        }
    }

    private void lamMoi() {
        txtId.setText(""); txtTen.setText(""); txtPhong.setText(""); txtLuong.setText("");
        txtId.setEditable(true);
        table.clearSelection();
    }

    private void thongKe() {
        if (ds.isEmpty()) { status("Danh sách rỗng", WARNING); return; }
        double tong = 0, max = Double.MIN_VALUE, min = Double.MAX_VALUE;
        Map<String, Integer> demPhong = new TreeMap<>();
        for (NhanVien nv : ds) {
            tong += nv.luong;
            max = Math.max(max, nv.luong);
            min = Math.min(min, nv.luong);
            demPhong.merge(nv.phong, 1, Integer::sum);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Tổng nhân viên : ").append(ds.size()).append("\n");
        sb.append("Tổng lương     : ").append(MONEY.format(tong)).append("\n");
        sb.append("Lương TB       : ").append(MONEY.format(tong / ds.size())).append("\n");
        sb.append("Lương cao nhất : ").append(MONEY.format(max)).append("\n");
        sb.append("Lương thấp nhất: ").append(MONEY.format(min)).append("\n\n");
        sb.append("Theo phòng ban:\n");
        demPhong.forEach((p, c) -> sb.append("  • ").append(p).append(": ").append(c).append(" người\n"));
        JOptionPane.showMessageDialog(this, sb.toString(), "Thống kê", JOptionPane.INFORMATION_MESSAGE);
    }

    private void baoCao() {
        try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream("baocao_nhanvien.txt"), StandardCharsets.UTF_8))) {
            pw.println("BÁO CÁO DANH SÁCH NHÂN VIÊN");
            pw.println("Ngày xuất: " + new Date());
            pw.println("=".repeat(60));
            double tong = 0;
            for (NhanVien nv : ds) {
                pw.printf("%-8s %-25s %-15s %s%n", nv.id, nv.ten, nv.phong, MONEY.format(nv.luong));
                tong += nv.luong;
            }
            pw.println("=".repeat(60));
            pw.println("Tổng: " + ds.size() + " nhân viên, lương " + MONEY.format(tong));
            status("✅ Đã xuất baocao_nhanvien.txt", SUCCESS);
        } catch (IOException ex) { status("⚠ " + ex.getMessage(), DANGER); }
    }

    private void luuCSV() {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(CSV), StandardCharsets.UTF_8)) {
            w.write(0xFEFF);
            try (PrintWriter pw = new PrintWriter(w)) {
                pw.println(HEADER);
                for (NhanVien nv : ds) {
                    pw.printf("%s,%s,%s,%s%n",
                            escape(nv.id), escape(nv.ten), escape(nv.phong), nv.luong);
                }
            }
            status("✅ Đã lưu " + ds.size() + " nhân viên vào " + CSV, SUCCESS);
        } catch (IOException ex) { status("⚠ " + ex.getMessage(), DANGER); }
    }

    private void loadCSV() {
        File f = new File(CSV);
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line; boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) { first = false; if (line.startsWith("\uFEFF")) line = line.substring(1); }
                if (line.equalsIgnoreCase(HEADER) || line.isBlank()) continue;
                List<String> fld = parse(line);
                if (fld.size() < 4) continue;
                try { ds.add(new NhanVien(fld.get(0), fld.get(1), fld.get(2), Double.parseDouble(fld.get(3)))); }
                catch (NumberFormatException ignored) {}
            }
            status("Đã nạp " + ds.size() + " nhân viên", PRIMARY);
        } catch (IOException ex) { status("⚠ " + ex.getMessage(), DANGER); }
    }

    private void refresh() {
        model.setRowCount(0);
        for (NhanVien nv : ds) model.addRow(new Object[]{nv.id, nv.ten, nv.phong, MONEY.format(nv.luong)});
        lblCount.setText(ds.size() + " nhân viên");
    }

    private NhanVien find(String id) {
        for (NhanVien nv : ds) if (nv.id.equalsIgnoreCase(id)) return nv;
        return null;
    }

    private void status(String s, Color c) {
        lblStatus.setText("  " + s);
        lblStatus.setForeground(c);
    }

    // ----- tiện ích -----
    static String escape(String s) {
        if (s == null) return "";
        if (s.contains(",") || s.contains("\"") || s.contains("\n"))
            return "\"" + s.replace("\"", "\"\"") + "\"";
        return s;
    }
    static List<String> parse(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (q) {
                if (c == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') { cur.append('"'); i++; }
                    else q = false;
                } else cur.append(c);
            } else {
                if (c == '"') q = true;
                else if (c == ',') { out.add(cur.toString()); cur.setLength(0); }
                else cur.append(c);
            }
        }
        out.add(cur.toString());
        return out;
    }

    static class NhanVien {
        String id, ten, phong; double luong;
        NhanVien(String id, String ten, String phong, double luong) {
            this.id = id; this.ten = ten; this.phong = phong; this.luong = luong;
        }
    }

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
            UIManager.put("control", BG);
            UIManager.put("nimbusBase", PRIMARY);
            UIManager.put("nimbusFocus", PRIMARY);
            UIManager.put("text", new Color(0x1E293B));
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> new DanhSachNhanVien().setVisible(true));
    }
}