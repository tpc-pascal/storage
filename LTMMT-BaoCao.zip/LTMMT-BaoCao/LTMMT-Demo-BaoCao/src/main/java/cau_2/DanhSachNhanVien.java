/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cau_2;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/**
 *
 * @author tpc-pascal
 */
public class DanhSachNhanVien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        String csvFile = "employee.csv";
        try (Scanner sc = new Scanner(System.in);
             Writer w = new OutputStreamWriter(new FileOutputStream(csvFile), StandardCharsets.UTF_8)) {
            w.write(0xFEFF);
            try (PrintWriter pw = new PrintWriter(w)) {
                pw.println("ID,HoTen,PhongBan,Luong");
                System.out.print("Nhap so nhan vien: ");
                int n = Integer.parseInt(sc.nextLine());
                for (int i = 0; i < n; i++) {
                    System.out.print("ID: "); String id = sc.nextLine();
                    System.out.print("Ho ten: "); String name = sc.nextLine();
                    System.out.print("Phong ban: "); String dept = sc.nextLine();
                    System.out.print("Luong: "); String salary = sc.nextLine();
                    pw.printf("%s,\"%s\",\"%s\",%s%n", id, name, dept, salary);
                }
                pw.flush();
            }
            System.out.println("Da ghi file " + csvFile + " (UTF-8 co BOM)");
        } catch (IOException e) {}
        System.out.println("--- Noi dung file CSV ---");
        try (Scanner fileSc = new Scanner(new File(csvFile), StandardCharsets.UTF_8)) {
            while (fileSc.hasNextLine()) System.out.println(fileSc.nextLine());
        } catch (FileNotFoundException e) {}
    }
}
