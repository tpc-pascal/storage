package cau_2;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.*;
import java.util.List;

/**
 * ỨNG DỤNG GUI — QUẢN LÝ NHÂN VIÊN
 * - CRUD nhân viên
 * - Lưu/Nạp CSV (UTF-8 có BOM, escape chuẩn)
 * - Thống kê lương, xuất báo cáo
 *
 * @author tpc-pascal
 */
public class DanhSachNhanVien extends JFrame {

    private static final String CSV = "employee.csv";
    private static final String HEADER = "ID,HoTen,PhongBan,Luong";
    private static final DecimalFormat MONEY = new DecimalFormat("#,###");

    private final DefaultTableModel model;
    private final JTable table;
    private final List<NhanVien> ds = new ArrayList<>();

    private final JTextField txtId = new JTextField(10);
    private final JTextField txtTen = new JTextField(20);
    private final JTextField txtPhong = new JTextField(15);
    private final JTextField txtLuong = new JTextField(12);
    private final JLabel lblStatus = new JLabel(" ");

    public DanhSachNhanVien() {
        super("QUẢN LÝ NHÂN VIÊN");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 650);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));
        ((JComponent) getContentPane()).setBorder(new EmptyBorder(10, 10, 10, 10));

        model = new DefaultTableModel(new String[]{"ID","Họ tên","Phòng ban","Lương"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setRowHeight(24);
        table.getTableHeader().setReorderingAllowed(false);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> {
            int r = table.getSelectedRow();
            if (r >= 0) {
                txtId.setText((String) model.getValueAt(r, 0));
                txtTen.setText((String) model.getValueAt(r, 1));
                txtPhong.setText((String) model.getValueAt(r, 2));
                txtLuong.setText(String.valueOf(model.getValueAt(r, 3)).replace(",", ""));
                txtId.setEditable(false);
            }
        });
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Thông tin nhân viên"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(3,3,3,3); g.anchor = GridBagConstraints.WEST;
        addRow(form, g, 0, "ID:", txtId);
        addRow(form, g, 1, "Họ tên:", txtTen);
        addRow(form, g, 2, "Phòng ban:", txtPhong);
        addRow(form, g, 3, "Lương:", txtLuong);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        buttons.add(btn("➕ Thêm", e -> them()));
        buttons.add(btn("✏ Sửa", e -> sua()));
        buttons.add(btn("🗑 Xóa", e -> xoa()));
        buttons.add(btn("🔄 Làm mới", e -> lamMoi()));
        buttons.add(btn("💾 Lưu CSV", e -> luuCSV()));
        buttons.add(btn("📂 Nạp CSV", e -> { ds.clear(); loadCSV(); refresh(); }));
        buttons.add(btn("📊 Thống kê", e -> thongKe()));
        buttons.add(btn("📄 Báo cáo", e -> baoCao()));

        JPanel top = new JPanel(new BorderLayout(5, 5));
        top.add(form, BorderLayout.NORTH);
        top.add(buttons, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);

        JPanel south = new JPanel(new BorderLayout());
        lblStatus.setBorder(new EmptyBorder(5, 5, 5, 5));
        south.add(lblStatus, BorderLayout.WEST);
        add(south, BorderLayout.SOUTH);

        loadCSV();
        refresh();
    }

    private void them() {
        try {
            String id = txtId.getText().trim();
            if (id.isEmpty()) { status("⚠ ID không được rỗng"); return; }
            if (find(id) != null) { status("⚠ ID đã tồn tại"); return; }
            String ten = txtTen.getText().trim();
            String phong = txtPhong.getText().trim();
            double luong = Double.parseDouble(txtLuong.getText().trim());
            ds.add(new NhanVien(id, ten, phong, luong));
            refresh(); lamMoi();
            status("✅ Đã thêm " + id);
        } catch (NumberFormatException ex) { status("⚠ Lương phải là số"); }
    }

    private void sua() {
        int r = table.getSelectedRow();
        if (r < 0) { status("⚠ Chọn 1 dòng để sửa"); return; }
        try {
            String id = (String) model.getValueAt(r, 0);
            NhanVien nv = find(id);
            if (nv == null) return;
            nv.ten = txtTen.getText().trim();
            nv.phong = txtPhong.getText().trim();
            nv.luong = Double.parseDouble(txtLuong.getText().trim());
            refresh(); lamMoi();
            status("✅ Đã cập nhật " + id);
        } catch (NumberFormatException ex) { status("⚠ Lương phải là số"); }
    }

    private void xoa() {
        int r = table.getSelectedRow();
        if (r < 0) { status("⚠ Chọn 1 dòng để xóa"); return; }
        String id = (String) model.getValueAt(r, 0);
        if (JOptionPane.showConfirmDialog(this, "Xóa nhân viên " + id + "?",
                "Xác nhận", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            ds.removeIf(nv -> nv.id.equals(id));
            refresh(); lamMoi();
            status("✅ Đã xóa " + id);
        }
    }

    private void lamMoi() {
        txtId.setText(""); txtTen.setText(""); txtPhong.setText(""); txtLuong.setText("");
        txtId.setEditable(true);
        table.clearSelection();
        status(" ");
    }

    private void thongKe() {
        if (ds.isEmpty()) { status("Danh sách rỗng"); return; }
        double tong = 0, max = Double.MIN_VALUE, min = Double.MAX_VALUE;
        Map<String, Integer> demPhong = new TreeMap<>();
        for (NhanVien nv : ds) {
            tong += nv.luong;
            max = Math.max(max, nv.luong);
            min = Math.min(min, nv.luong);
            demPhong.merge(nv.phong, 1, Integer::sum);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Tổng nhân viên : ").append(ds.size()).append("\n");
        sb.append("Tổng lương     : ").append(MONEY.format(tong)).append("\n");
        sb.append("Lương TB       : ").append(MONEY.format(tong / ds.size())).append("\n");
        sb.append("Lương cao nhất : ").append(MONEY.format(max)).append("\n");
        sb.append("Lương thấp nhất: ").append(MONEY.format(min)).append("\n\n");
        sb.append("Theo phòng ban:\n");
        demPhong.forEach((p, c) -> sb.append("  ").append(p).append(": ").append(c).append(" người\n"));
        JOptionPane.showMessageDialog(this, sb.toString(), "Thống kê", JOptionPane.INFORMATION_MESSAGE);
    }

    private void baoCao() {
        try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream("baocao_nhanvien.txt"), StandardCharsets.UTF_8))) {
            pw.println("BÁO CÁO DANH SÁCH NHÂN VIÊN");
            pw.println("Ngày xuất: " + new Date());
            pw.println("=".repeat(60));
            double tong = 0;
            for (NhanVien nv : ds) {
                pw.printf("%-8s %-25s %-15s %s%n", nv.id, nv.ten, nv.phong, MONEY.format(nv.luong));
                tong += nv.luong;
            }
            pw.println("=".repeat(60));
            pw.println("Tổng: " + ds.size() + " nhân viên, lương " + MONEY.format(tong));
            status("✅ Đã xuất baocao_nhanvien.txt");
        } catch (IOException ex) { status("⚠ " + ex.getMessage()); }
    }

    private void luuCSV() {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(CSV), StandardCharsets.UTF_8)) {
            w.write(0xFEFF);
            try (PrintWriter pw = new PrintWriter(w)) {
                pw.println(HEADER);
                for (NhanVien nv : ds) {
                    pw.printf("%s,%s,%s,%s%n",
                            escape(nv.id), escape(nv.ten), escape(nv.phong), nv.luong);
                }
            }
            status("✅ Đã lưu " + ds.size() + " nhân viên vào " + CSV);
        } catch (IOException ex) { status("⚠ " + ex.getMessage()); }
    }

    private void loadCSV() {
        File f = new File(CSV);
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line; boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) { first = false; if (line.startsWith("\uFEFF")) line = line.substring(1); }
                if (line.equalsIgnoreCase(HEADER) || line.isBlank()) continue;
                List<String> fld = parse(line);
                if (fld.size() < 4) continue;
                try { ds.add(new NhanVien(fld.get(0), fld.get(1), fld.get(2), Double.parseDouble(fld.get(3)))); }
                catch (NumberFormatException ignored) {}
            }
            status("Đã nạp " + ds.size() + " nhân viên");
        } catch (IOException ex) { status("⚠ " + ex.getMessage()); }
    }

    private void refresh() {
        model.setRowCount(0);
        for (NhanVien nv : ds) model.addRow(new Object[]{nv.id, nv.ten, nv.phong, MONEY.format(nv.luong)});
        status("Tổng: " + ds.size() + " nhân viên");
    }

    private NhanVien find(String id) {
        for (NhanVien nv : ds) if (nv.id.equalsIgnoreCase(id)) return nv;
        return null;
    }

    private void status(String s) { lblStatus.setText(s); }

    // ----- tiện ích -----
    static void addRow(JPanel p, GridBagConstraints g, int row, String label, JComponent field) {
        g.gridy = row; g.gridx = 0; g.weightx = 0; p.add(new JLabel(label), g);
        g.gridx = 1; g.weightx = 1; g.fill = GridBagConstraints.HORIZONTAL; p.add(field, g);
    }
    static JButton btn(String text, ActionListener l) { JButton b = new JButton(text); b.addActionListener(l); return b; }
    static String escape(String s) {
        if (s == null) return "";
        if (s.contains(",") || s.contains("\"") || s.contains("\n"))
            return "\"" + s.replace("\"", "\"\"") + "\"";
        return s;
    }
    static List<String> parse(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (q) {
                if (c == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') { cur.append('"'); i++; }
                    else q = false;
                } else cur.append(c);
            } else {
                if (c == '"') q = true;
                else if (c == ',') { out.add(cur.toString()); cur.setLength(0); }
                else cur.append(c);
            }
        }
        out.add(cur.toString());
        return out;
    }

    static class NhanVien {
        String id, ten, phong; double luong;
        NhanVien(String id, String ten, String phong, double luong) {
            this.id = id; this.ten = ten; this.phong = phong; this.luong = luong;
        }
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException ignored) {}
        SwingUtilities.invokeLater(() -> new DanhSachNhanVien().setVisible(true));
    }
}