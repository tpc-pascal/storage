/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cau_3;

/**
 *
 * @author tpc-pascal
 */
class TicketCounter {
    private int tickets = 100;
    public void sellUnsynchronized(String threadName) {
        if (tickets > 0) { try { Thread.sleep(1); } catch (InterruptedException e) {} tickets--; System.out.println(threadName + " ban ve, con: " + tickets); }
    }
    public synchronized void sellSynchronized(String threadName) {
        if (tickets > 0) { try { Thread.sleep(1); } catch (InterruptedException e) {} tickets--; System.out.println(threadName + " ban ve, con: " + tickets); }
    }
    public int getTickets() { return tickets; }
}

public class BanVe {

    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== KHONG SYNCHRONIZED ===");
        TicketCounter counter1 = new TicketCounter();
        runTest(counter1, false);
        System.out.println("So ve con lai (ky vong 0): " + counter1.getTickets());
        System.out.println("=> Neu khac 0 hoac am: SAI LECH do race condition (co the khong xay ra tuy toc do may)!\n");
        System.out.println("=== CO SYNCHRONIZED ===");
        TicketCounter counter2 = new TicketCounter();
        runTest(counter2, true);
        System.out.println("So ve con lai (ky vong 0): " + counter2.getTickets());
        System.out.println("=> Luon dung 0: dong bo hoat dong tot.");
    }
    private static void runTest(TicketCounter counter, boolean sync) throws InterruptedException {
        Runnable task = () -> {
            for (int i = 0; i < 100; i++) {
                if (sync) counter.sellSynchronized(Thread.currentThread().getName());
                else counter.sellUnsynchronized(Thread.currentThread().getName());
            }
        };
        Thread t1 = new Thread(task, "Thread-1");
        Thread t2 = new Thread(task, "Thread-2");
        Thread t3 = new Thread(task, "Thread-3");
        t1.start(); t2.start(); t3.start();
        t1.join(); t2.join(); t3.join();
    }
}
