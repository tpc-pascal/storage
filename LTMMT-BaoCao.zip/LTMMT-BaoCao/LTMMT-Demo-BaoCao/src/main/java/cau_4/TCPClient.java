/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cau_4;

import java.io.*;
import java.net.*;

/**
 *
 * @author tpc-pascal
 */
public class TCPClient {

    /**
     * @param args the command line arguments
     */
    private static final String HOST = "localhost";
    private static final int PORT = 5000;
    public static void main(String[] args) throws IOException {
        try (Socket socket = new Socket(HOST, PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.println("Da ket noi toi server. Nhap van ban (go exit de thoat):");
            String line;
            while ((line = keyboard.readLine()) != null) {
                out.println(line);
                if (line.equalsIgnoreCase("exit")) break;
            }
        }
    }
}
