/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cau_4;

import java.io.*;
import java.net.*;

/**
 *
 * @author tpc-pascal
 */
public class TCPServer {

    /**
     * @param args the command line arguments
     */
    private static final int PORT = 5000;
    public static void main(String[] args) throws IOException {
        try (ServerSocket server = new ServerSocket(PORT);
             PrintWriter log = new PrintWriter(new FileWriter("server_log.txt", true))) {
            System.out.println("Server dang cho ket noi o port " + PORT + "...");
            try (Socket client = server.accept();
                 BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))) {
                System.out.println("Client da ket noi: " + client.getInetAddress());
                String line;
                while ((line = in.readLine()) != null) {
                    if (line.equalsIgnoreCase("exit")) { System.out.println("Client yeu cau thoat."); break; }
                    System.out.println("Nhan: " + line);
                    log.println(line); log.flush();
                }
            }
            System.out.println("Da ghi log vao server_log.txt");
        }
    }
}
