/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cau_5;

import java.io.IOException;
import java.net.*;

/**
 *
 * @author tpc-pascal
 */
public class MulticastClient {

    /**
     * @param args the command line arguments
     */
    private static final String GROUP = "230.0.0.1";
    private static final int PORT = 4446;
    public static void main(String[] args) throws IOException {
        InetAddress group = InetAddress.getByName(GROUP);
        try (MulticastSocket socket = new MulticastSocket(PORT)) {
            socket.joinGroup(group);
            System.out.println("Client tham gia group " + GROUP + ", dang cho...");
            byte[] buf = new byte[1024];
            for (int i = 0; i < 5; i++) {
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);
                String msg = new String(packet.getData(), 0, packet.getLength());
                System.out.println("Nhan: " + msg);
            }
            socket.leaveGroup(group);
        }
    }
}
