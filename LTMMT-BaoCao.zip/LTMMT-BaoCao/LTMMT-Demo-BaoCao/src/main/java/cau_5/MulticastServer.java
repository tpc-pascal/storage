/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cau_5;

import java.io.IOException;
import java.net.*;

/**
 *
 * @author tpc-pascal
 */
public class MulticastServer {

    /**
     * @param args the command line arguments
     */
    private static final String GROUP = "230.0.0.1";
    private static final int PORT = 4446;
    public static void main(String[] args) throws IOException, InterruptedException {
        InetAddress group = InetAddress.getByName(GROUP);
        try (MulticastSocket socket = new MulticastSocket()) {
            socket.setTimeToLive(1);
            System.out.println("Server multicast phat toi " + GROUP + ":" + PORT);
            for (int i = 1; i <= 5; i++) {
                String msg = "Thong diep multicast #" + i + " luc " + System.currentTimeMillis();
                byte[] buf = msg.getBytes();
                DatagramPacket packet = new DatagramPacket(buf, buf.length, group, PORT);
                socket.send(packet);
                System.out.println("Da gui: " + msg);
                Thread.sleep(1000);
            }
        }
    }
}
