/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cau_6;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author tpc-pascal
 */
public interface Hello extends Remote {
    String sayHello() throws RemoteException;
}