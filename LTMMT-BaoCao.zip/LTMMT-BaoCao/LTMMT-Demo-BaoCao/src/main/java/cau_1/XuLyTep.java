/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cau_1;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author tpc-pascal
 */
public class XuLyTep {

    /**
     * @param args the command line arguments
     */
    private static final int CHUNK_SIZE = 100;
    
    public static List<File> split(File inputFile, String outputDir) throws IOException {
        List<File> parts = new ArrayList<>();
        File dir = new File(outputDir);
        if (!dir.exists()) dir.mkdirs();
        try (FileInputStream fis = new FileInputStream(inputFile)) {
            byte[] buffer = new byte[CHUNK_SIZE];
            int partIndex = 0, totalBytes = 0, read;
            while ((read = fis.read(buffer)) != -1) {
                File part = new File(dir, inputFile.getName() + ".part" + partIndex++);
                try (FileOutputStream fos = new FileOutputStream(part)) { fos.write(buffer, 0, read); }
                parts.add(part);
                totalBytes += read;
            }
            System.out.println("Da chia thanh " + parts.size() + " phan, tong " + totalBytes + " byte.");
        }
        return parts;
    }
    
    public static File merge(List<File> parts, File outputFile) throws IOException {
        int totalBytes = 0;
        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            for (File part : parts) {
                try (FileInputStream fis = new FileInputStream(part)) {
                    byte[] buf = new byte[CHUNK_SIZE];
                    int read;
                    while ((read = fis.read(buf)) != -1) { fos.write(buf, 0, read); totalBytes += read; }
                }
            }
        }
        System.out.println("Da ghep " + parts.size() + " phan, tong " + totalBytes + " byte xu ly.");
        return outputFile;
    }
    
    public static void main(String[] args) throws IOException {
        File input = new File("sample.jpg");
        if (!input.exists()) {
            try (FileOutputStream fos = new FileOutputStream(input)) {
                byte[] data = new byte[500];
                for (int i = 0; i < data.length; i++) data[i] = (byte)(i % 256);
                fos.write(data);
            }
            System.out.println("Da tao file mau sample.jpg (500 byte nhi phan).");
        }
        List<File> parts = split(input, "parts");
        File merged = merge(parts, new File("sample_merged.jpg"));
        System.out.println("Kich thuoc goc : " + input.length() + " byte");
        System.out.println("Kich thuoc ghep: " + merged.length() + " byte");
        System.out.println("Kich thuoc khop: " + (input.length() == merged.length()));
        boolean sameContent = true;
        try (FileInputStream f1 = new FileInputStream(input); FileInputStream f2 = new FileInputStream(merged)) {
            int b1, b2;
            while ((b1 = f1.read()) != -1 && (b2 = f2.read()) != -1) { if (b1 != b2) { sameContent = false; break; } }
            if (f1.read() != -1 || f2.read() != -1) sameContent = false;
        }
        System.out.println("Noi dung byte giong het: " + sameContent);
    }
}
