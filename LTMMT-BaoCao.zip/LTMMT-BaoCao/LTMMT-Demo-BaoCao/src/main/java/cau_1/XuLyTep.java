package cau_1;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.List;

/**
 * ỨNG DỤNG GUI — XỬ LÝ TỆP NHỊ PHÂN
 * - Chia tệp thành các phần
 * - Ghép các phần thành tệp hoàn chỉnh
 * - Kiểm tra toàn vẹn bằng MD5 + SHA-256
 *
 * @author tpc-pascal
 */
public class XuLyTep extends JFrame {

    private final JTextField txtInput = new JTextField(30);
    private final JTextField txtOutDir = new JTextField("parts", 15);
    private final JTextField txtChunk = new JTextField("100", 6);
    private final JTextField txtMergeDir = new JTextField("parts", 15);
    private final JTextField txtMergeOut = new JTextField("merged_output.bin", 15);
    private final JTextField txtCheckA = new JTextField(25);
    private final JTextField txtCheckB = new JTextField(25);
    private final JTextArea log = new JTextArea(10, 60);

    public XuLyTep() {
        super("XỬ LÝ TỆP NHỊ PHÂN");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(850, 650);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout(8, 8));
        ((JComponent) getContentPane()).setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));

        // --- Chia tệp ---
        JPanel p1 = titled("1. Chia tệp nhị phân");
        p1.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(3,3,3,3); g.anchor = GridBagConstraints.WEST;
        addRow(p1, g, 0, "Tệp nguồn:", txtInput, btn("Chọn...", e -> chonFile(txtInput)));
        addRow(p1, g, 1, "Thư mục parts:", txtOutDir, null);
        addRow(p1, g, 2, "Kích thước (byte):", txtChunk, null);
        JButton btnSplit = new JButton("✂ Chia tệp");
        btnSplit.addActionListener(e -> chiaTep());
        g.gridx = 1; g.gridy = 3; p1.add(btnSplit, g);

        // --- Ghép tệp ---
        JPanel p2 = titled("2. Ghép tệp");
        p2.setLayout(new GridBagLayout());
        addRow(p2, g, 0, "Thư mục parts:", txtMergeDir, null);
        addRow(p2, g, 1, "Tệp đầu ra:", txtMergeOut, btn("Chọn...", e -> chonFileSave(txtMergeOut)));
        JButton btnMerge = new JButton("🔗 Ghép tệp");
        btnMerge.addActionListener(e -> ghepTep());
        g.gridx = 1; g.gridy = 2; p2.add(btnMerge, g);

        // --- Kiểm tra toàn vẹn ---
        JPanel p3 = titled("3. Kiểm tra toàn vẹn (MD5 + SHA-256)");
        p3.setLayout(new GridBagLayout());
        addRow(p3, g, 0, "Tệp A:", txtCheckA, btn("Chọn...", e -> chonFile(txtCheckA)));
        addRow(p3, g, 1, "Tệp B:", txtCheckB, btn("Chọn...", e -> chonFile(txtCheckB)));
        JButton btnCheck = new JButton("🔍 Kiểm tra");
        btnCheck.addActionListener(e -> kiemTra());
        g.gridx = 1; g.gridy = 2; p3.add(btnCheck, g);

        main.add(p1); main.add(Box.createVerticalStrut(8));
        main.add(p2); main.add(Box.createVerticalStrut(8));
        main.add(p3);
        add(main, BorderLayout.NORTH);

        log.setEditable(false);
        log.setFont(new Font("Monospaced", Font.PLAIN, 12));
        add(new JScrollPane(log), BorderLayout.CENTER);

        JButton btnClear = new JButton("Xóa log");
        btnClear.addActionListener(e -> log.setText(""));
        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.add(btnClear);
        add(south, BorderLayout.SOUTH);
    }

    private void chiaTep() {
        try {
            File in = new File(txtInput.getText().trim());
            if (!in.isFile()) { log("LỖI: Tệp không tồn tại"); return; }
            int chunk = Integer.parseInt(txtChunk.getText().trim());
            if (chunk <= 0) { log("LỖI: chunk phải > 0"); return; }

            File dir = new File(txtOutDir.getText().trim());
            if (!dir.exists()) dir.mkdirs();

            long start = System.currentTimeMillis();
            List<File> parts = new ArrayList<>();
            long total = 0;
            try (FileInputStream fis = new FileInputStream(in)) {
                byte[] buf = new byte[chunk];
                int idx = 0, r;
                while ((r = fis.read(buf)) != -1) {
                    File p = new File(dir, in.getName() + ".part" + idx++);
                    try (FileOutputStream fos = new FileOutputStream(p)) { fos.write(buf, 0, r); }
                    parts.add(p); total += r;
                }
            }
            long ms = System.currentTimeMillis() - start;
            log("✅ Đã chia " + parts.size() + " phần, tổng " + total + " byte (" + ms + " ms)");
            log("🔐 MD5 tệp gốc: " + checksum(in, "MD5"));
        } catch (Exception ex) { log("LỖI: " + ex.getMessage()); }
    }

    private void ghepTep() {
        try {
            File dir = new File(txtMergeDir.getText().trim());
            File[] parts = dir.listFiles((d, n) -> n.contains(".part"));
            if (parts == null || parts.length == 0) { log("LỖI: không có file .part"); return; }
            Arrays.sort(parts, Comparator.comparingInt(f -> {
                String n = f.getName();
                try { return Integer.parseInt(n.substring(n.lastIndexOf(".part") + 5)); }
                catch (Exception e) { return Integer.MAX_VALUE; }
            }));

            File out = new File(txtMergeOut.getText().trim());
            long start = System.currentTimeMillis();
            long total = 0;
            try (FileOutputStream fos = new FileOutputStream(out)) {
                for (File p : parts) {
                    try (FileInputStream fis = new FileInputStream(p)) {
                        byte[] buf = new byte[8192]; int r;
                        while ((r = fis.read(buf)) != -1) { fos.write(buf, 0, r); total += r; }
                    }
                }
            }
            long ms = System.currentTimeMillis() - start;
            log("✅ Đã ghép " + parts.length + " phần, tổng " + total + " byte (" + ms + " ms)");
            log("🔐 MD5 tệp ghép: " + checksum(out, "MD5"));
        } catch (Exception ex) { log("LỖI: " + ex.getMessage()); }
    }

    private void kiemTra() {
        try {
            File a = new File(txtCheckA.getText().trim());
            File b = new File(txtCheckB.getText().trim());
            if (!a.isFile() || !b.isFile()) { log("LỖI: tệp không tồn tại"); return; }

            boolean size = a.length() == b.length();
            String md5a = checksum(a, "MD5"), md5b = checksum(b, "MD5");
            String shaa = checksum(a, "SHA-256"), shab = checksum(b, "SHA-256");
            boolean smd5 = md5a.equals(md5b), ssha = shaa.equals(shab);

            log("--- KIỂM TRA TOÀN VẸN ---");
            log("Kích thước : " + (size ? "OK" : "KHÁC") + " (" + a.length() + " vs " + b.length() + ")");
            log("MD5        : " + (smd5 ? "OK" : "KHÁC"));
            log("  A: " + md5a); log("  B: " + md5b);
            log("SHA-256    : " + (ssha ? "OK" : "KHÁC"));
            log(size && smd5 && ssha ? "🎉 HOÀN TOÀN GIỐNG NHAU" : "⚠ KHÁC NHAU");
        } catch (Exception ex) { log("LỖI: " + ex.getMessage()); }
    }

    private void log(String s) { log.append(s + "\n"); log.setCaretPosition(log.getDocument().getLength()); }

    // ----- tiện ích -----
    static JPanel titled(String title) {
        JPanel p = new JPanel();
        p.setBorder(BorderFactory.createTitledBorder(title));
        return p;
    }
    static void addRow(JPanel p, GridBagConstraints g, int row, String label, JComponent field, JButton btn) {
        g.gridy = row;
        g.gridx = 0; g.weightx = 0; p.add(new JLabel(label), g);
        g.gridx = 1; g.weightx = 1; g.fill = GridBagConstraints.HORIZONTAL; p.add(field, g);
        if (btn != null) { g.gridx = 2; g.weightx = 0; g.fill = GridBagConstraints.NONE; p.add(btn, g); }
    }
    static JButton btn(String text, ActionListener l) { JButton b = new JButton(text); b.addActionListener(l); return b; }
    static void chonFile(JTextField target) {
        JFileChooser fc = new JFileChooser();
        if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) target.setText(fc.getSelectedFile().getAbsolutePath());
    }
    static void chonFileSave(JTextField target) {
        JFileChooser fc = new JFileChooser();
        if (fc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) target.setText(fc.getSelectedFile().getAbsolutePath());
    }
    static String checksum(File f, String algo) {
        try (InputStream is = new FileInputStream(f)) {
            MessageDigest md = MessageDigest.getInstance(algo);
            byte[] buf = new byte[8192]; int r;
            while ((r = is.read(buf)) != -1) md.update(buf, 0, r);
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return "(lỗi: " + e.getMessage() + ")"; }
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException ignored) {}
        SwingUtilities.invokeLater(() -> new XuLyTep().setVisible(true));
    }
}