package cau_1;

import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

/**
 * ỨNG DỤNG CHIA TÁCH & GHÉP TỆP NHỊ PHÂN
 * - Chia tệp thành các phần có kích thước tùy chọn
 * - Ghép các phần lại thành tệp hoàn chỉnh
 * - Kiểm tra toàn vẹn bằng MD5/SHA-256
 * - Thống kê, xử lý lỗi, menu tương tác
 *
 * @author tpc-pascal
 */
public class XuLyTep {

    private static final Scanner sc = new Scanner(System.in);
    private static final String DEFAULT_CHUNK = "100";

    public static void main(String[] args) {
        while (true) {
            printMenu();
            int choice = readInt("Chọn chức năng: ");
            switch (choice) {
                case 1 -> chiaTep();
                case 2 -> ghepTep();
                case 3 -> kiemTraToanVen();
                case 4 -> thongTinTep();
                case 5 -> taoTepMau();
                case 0 -> { System.out.println("Tạm biệt!"); return; }
                default -> System.out.println("Lựa chọn không hợp lệ!");
            }
            System.out.println();
        }
    }

    // ================= MENU =================
    private static void printMenu() {
        System.out.println("========== ỨNG DỤNG XỬ LÝ TỆP NHỊ PHÂN ==========");
        System.out.println("1. Chia tệp thành các phần");
        System.out.println("2. Ghép các phần thành tệp hoàn chỉnh");
        System.out.println("3. Kiểm tra toàn vẹn (so sánh checksum)");
        System.out.println("4. Xem thông tin tệp");
        System.out.println("5. Tạo tệp mẫu để test");
        System.out.println("0. Thoát");
        System.out.println("=================================================");
    }

    // ================= CHỨC NĂNG 1: CHIA TỆP =================
    private static void chiaTep() {
        try {
            System.out.print("Đường dẫn tệp cần chia: ");
            File input = new File(sc.nextLine().trim());
            if (!input.exists() || !input.isFile()) {
                System.out.println("❌ Tệp không tồn tại: " + input.getAbsolutePath());
                return;
            }

            System.out.print("Thư mục chứa các phần (Enter để dùng 'parts'): ");
            String outDir = sc.nextLine().trim();
            if (outDir.isEmpty()) outDir = "parts";

            int chunkSize = readInt("Kích thước mỗi phần (byte, Enter để dùng " + DEFAULT_CHUNK + "): ", Integer.parseInt(DEFAULT_CHUNK));
            if (chunkSize <= 0) {
                System.out.println("❌ Kích thước phải > 0");
                return;
            }

            long start = System.currentTimeMillis();
            List<File> parts = split(input, outDir, chunkSize);
            long elapsed = System.currentTimeMillis() - start;

            System.out.println("✅ Đã chia thành " + parts.size() + " phần trong thư mục '" + outDir + "'");
            System.out.println("⏱  Thời gian: " + elapsed + " ms");
            System.out.println("🔐 MD5 tệp gốc: " + md5(input));

        } catch (Exception e) {
            System.out.println("❌ Lỗi: " + e.getMessage());
        }
    }

    // ================= CHỨC NĂNG 2: GHÉP TỆP =================
    private static void ghepTep() {
        try {
            System.out.print("Thư mục chứa các phần: ");
            String dirPath = sc.nextLine().trim();
            File dir = new File(dirPath);
            if (!dir.exists() || !dir.isDirectory()) {
                System.out.println("❌ Thư mục không tồn tại: " + dir.getAbsolutePath());
                return;
            }

            File[] partFiles = dir.listFiles((d, name) -> name.contains(".part"));
            if (partFiles == null || partFiles.length == 0) {
                System.out.println("❌ Không tìm thấy file .part nào trong thư mục.");
                return;
            }

            // Sắp xếp theo số thứ tự phần (part0, part1, ...)
            Arrays.sort(partFiles, Comparator.comparingInt(XuLyTep::extractPartIndex));

            System.out.print("Tên tệp đầu ra (Enter để dùng 'merged_output.bin'): ");
            String outName = sc.nextLine().trim();
            if (outName.isEmpty()) outName = "merged_output.bin";
            File output = new File(outName);

            long start = System.currentTimeMillis();
            merge(Arrays.asList(partFiles), output);
            long elapsed = System.currentTimeMillis() - start;

            System.out.println("✅ Đã ghép " + partFiles.length + " phần → " + output.getAbsolutePath());
            System.out.println("⏱  Thời gian: " + elapsed + " ms");
            System.out.println("🔐 MD5 tệp ghép: " + md5(output));

        } catch (Exception e) {
            System.out.println("❌ Lỗi: " + e.getMessage());
        }
    }

    // ================= CHỨC NĂNG 3: KIỂM TRA TOÀN VẸN =================
    private static void kiemTraToanVen() {
        try {
            System.out.print("Tệp gốc: ");
            File f1 = new File(sc.nextLine().trim());
            System.out.print("Tệp cần kiểm tra: ");
            File f2 = new File(sc.nextLine().trim());

            if (!f1.exists() || !f2.exists()) {
                System.out.println("❌ Một trong hai tệp không tồn tại.");
                return;
            }

            System.out.println("Kích thước: " + f1.length() + " vs " + f2.length() + " byte");
            String md5a = md5(f1), md5b = md5(f2);
            String shaa = sha256(f1), shab = sha256(f2);

            System.out.println("MD5   gốc: " + md5a);
            System.out.println("MD5   mới: " + md5b);
            System.out.println("SHA256 gốc: " + shaa);
            System.out.println("SHA256 mới: " + shab);

            boolean sameSize = f1.length() == f2.length();
            boolean sameMd5 = md5a.equals(md5b);
            boolean sameSha = shaa.equals(shab);

            System.out.println("Kích thước khớp: " + (sameSize ? "✅" : "❌"));
            System.out.println("MD5 khớp      : " + (sameMd5 ? "✅" : "❌"));
            System.out.println("SHA256 khớp   : " + (sameSha ? "✅" : "❌"));
            System.out.println(sameSize && sameMd5 && sameSha
                    ? "🎉 Hai tệp HOÀN TOÀN GIỐNG NHAU."
                    : "⚠ Hai tệp KHÁC NHAU.");

        } catch (Exception e) {
            System.out.println("❌ Lỗi: " + e.getMessage());
        }
    }

    // ================= CHỨC NĂNG 4: THÔNG TIN TỆP =================
    private static void thongTinTep() {
        try {
            System.out.print("Đường dẫn tệp: ");
            File f = new File(sc.nextLine().trim());
            if (!f.exists()) {
                System.out.println("❌ Tệp không tồn tại.");
                return;
            }
            System.out.println("Tên       : " + f.getName());
            System.out.println("Đường dẫn : " + f.getAbsolutePath());
            System.out.println("Kích thước: " + f.length() + " byte");
            System.out.println("Sửa lần cuối: " + new Date(f.lastModified()));
            System.out.println("Đọc được  : " + f.canRead());
            System.out.println("Ghi được  : " + f.canWrite());
            System.out.println("MD5       : " + md5(f));
            System.out.println("SHA256    : " + sha256(f));
        } catch (Exception e) {
            System.out.println("❌ Lỗi: " + e.getMessage());
        }
    }

    // ================= CHỨC NĂNG 5: TẠO TỆP MẪU =================
    private static void taoTepMau() {
        try {
            System.out.print("Tên tệp mẫu (Enter để dùng 'sample.jpg'): ");
            String name = sc.nextLine().trim();
            if (name.isEmpty()) name = "sample.jpg";

            int size = readInt("Kích thước (byte, Enter để dùng 500): ", 500);

            try (FileOutputStream fos = new FileOutputStream(name)) {
                byte[] data = new byte[size];
                for (int i = 0; i < size; i++) data[i] = (byte) (i % 256);
                fos.write(data);
            }
            System.out.println("✅ Đã tạo tệp mẫu '" + name + "' (" + size + " byte).");
        } catch (Exception e) {
            System.out.println("❌ Lỗi: " + e.getMessage());
        }
    }

    // ================= HÀM LÕI: SPLIT =================
    public static List<File> split(File inputFile, String outputDir, int chunkSize) throws IOException {
        List<File> parts = new ArrayList<>();
        File dir = new File(outputDir);
        if (!dir.exists()) dir.mkdirs();

        try (FileInputStream fis = new FileInputStream(inputFile)) {
            byte[] buffer = new byte[chunkSize];
            int partIndex = 0, read;
            long totalBytes = 0;
            while ((read = fis.read(buffer)) != -1) {
                File part = new File(dir, inputFile.getName() + ".part" + partIndex++);
                try (FileOutputStream fos = new FileOutputStream(part)) {
                    fos.write(buffer, 0, read);
                }
                parts.add(part);
                totalBytes += read;
            }
            System.out.println("Đã chia thành " + parts.size() + " phần, tổng " + totalBytes + " byte.");
        }
        return parts;
    }

    // ================= HÀM LÕI: MERGE =================
    public static File merge(List<File> parts, File outputFile) throws IOException {
        long totalBytes = 0;
        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            for (File part : parts) {
                try (FileInputStream fis = new FileInputStream(part)) {
                    byte[] buf = new byte[8192];
                    int read;
                    while ((read = fis.read(buf)) != -1) {
                        fos.write(buf, 0, read);
                        totalBytes += read;
                    }
                }
            }
        }
        System.out.println("Đã ghép " + parts.size() + " phần, tổng " + totalBytes + " byte xử lý.");
        return outputFile;
    }

    // ================= TIỆN ÍCH =================
    private static int readInt(String prompt) {
        return readInt(prompt, -1);
    }

    private static int readInt(String prompt, int defaultValue) {
        while (true) {
            System.out.print(prompt);
            String line = sc.nextLine().trim();
            if (line.isEmpty() && defaultValue > 0) return defaultValue;
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("⚠ Vui lòng nhập số nguyên.");
            }
        }
    }

    private static int extractPartIndex(File f) {
        try {
            String n = f.getName();
            return Integer.parseInt(n.substring(n.lastIndexOf(".part") + 5));
        } catch (Exception e) {
            return Integer.MAX_VALUE;
        }
    }

    // ================= CHECKSUM =================
    private static String md5(File f) {
        return checksum(f, "MD5");
    }

    private static String sha256(File f) {
        return checksum(f, "SHA-256");
    }

    private static String checksum(File f, String algo) {
        try (InputStream is = new FileInputStream(f)) {
            MessageDigest md = MessageDigest.getInstance(algo);
            byte[] buf = new byte[8192];
            int read;
            while ((read = is.read(buf)) != -1) md.update(buf, 0, read);
            return bytesToHex(md.digest());
        } catch (IOException | NoSuchAlgorithmException e) {
            return "(lỗi: " + e.getMessage() + ")";
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}