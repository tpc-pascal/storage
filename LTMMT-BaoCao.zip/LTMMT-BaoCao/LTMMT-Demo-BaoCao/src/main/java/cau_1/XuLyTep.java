package cau_1;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.List;

/**
 * ỨNG DỤNG GUI — XỬ LÝ TỆP NHỊ PHÂN (Giao diện hiện đại)
 *
 * @author tpc-pascal
 */
public class XuLyTep extends JFrame {

    // Bảng màu
    private static final Color PRIMARY   = new Color(0x2563EB); // xanh dương
    private static final Color SUCCESS   = new Color(0x16A34A); // xanh lá
    private static final Color DANGER    = new Color(0xDC2626); // đỏ
    private static final Color WARNING   = new Color(0xD97706); // cam
    private static final Color BG        = new Color(0xF8FAFC); // nền sáng
    private static final Color CARD_BG   = Color.WHITE;
    private static final Color TEXT_MUTED= new Color(0x64748B);
    private static final Color BORDER_C  = new Color(0xE2E8F0);

    // Font
    private static final Font FONT_TITLE  = new Font("Segoe UI", Font.BOLD, 16);
    private static final Font FONT_LABEL  = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_INPUT  = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 13);
    private static final Font FONT_LOG    = new Font("JetBrains Mono", Font.PLAIN, 12);

    // Components
    private final JTextField txtInput    = new JTextField(30);
    private final JTextField txtOutDir   = new JTextField("parts", 15);
    private final JTextField txtChunk    = new JTextField("100", 6);
    private final JTextField txtMergeDir = new JTextField("parts", 15);
    private final JTextField txtMergeOut = new JTextField("merged_output.bin", 15);
    private final JTextField txtCheckA   = new JTextField(25);
    private final JTextField txtCheckB   = new JTextField(25);
    private final JTextArea  log         = new JTextArea(12, 60);
    private final JLabel     lblStatus   = new JLabel(" Sẵn sàng");

    public XuLyTep() {
        super("Xử lý tệp nhị phân");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(920, 720);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(820, 640));

        // Nền tổng thể
        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(BG);
        root.setBorder(new EmptyBorder(16, 16, 16, 16));
        setContentPane(root);

        // ===== HEADER =====
        root.add(buildHeader(), BorderLayout.NORTH);

        // ===== BODY: 3 card xếp dọc =====
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(BG);
        body.setBorder(new EmptyBorder(16, 0, 0, 0));

        body.add(buildCard1());
        body.add(Box.createVerticalStrut(12));
        body.add(buildCard2());
        body.add(Box.createVerticalStrut(12));
        body.add(buildCard3());

        JScrollPane scroll = new JScrollPane(body);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setBackground(BG);
        root.add(scroll, BorderLayout.CENTER);

        // ===== LOG =====
        root.add(buildLogPanel(), BorderLayout.SOUTH);
    }

    // ============================================================
    // HEADER
    // ============================================================
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(PRIMARY);
        header.setBorder(new EmptyBorder(14, 20, 14, 20));

        JLabel title = new JLabel("📁  XỬ LÝ TỆP NHỊ PHÂN");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);

        JLabel sub = new JLabel("Chia · Ghép · Kiểm tra toàn vẹn MD5/SHA-256");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sub.setForeground(new Color(0xDBEAFE));

        JPanel text = new JPanel();
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.setOpaque(false);
        text.add(title);
        text.add(Box.createVerticalStrut(2));
        text.add(sub);

        header.add(text, BorderLayout.WEST);
        return header;
    }

    // ============================================================
    // CARD 1 — CHIA TỆP
    // ============================================================
    private JPanel buildCard1() {
        JPanel card = makeCard("1", "Chia tệp nhị phân", "Chọn tệp và kích thước mỗi phần");

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 4, 6, 4);
        g.anchor = GridBagConstraints.WEST;
        g.fill = GridBagConstraints.HORIZONTAL;

        addField(form, g, 0, "Tệp nguồn", txtInput, btn("📂 Chọn", PRIMARY, e -> chonFile(txtInput)));
        addField(form, g, 1, "Thư mục parts", txtOutDir, null);
        addField(form, g, 2, "Kích thước (byte)", txtChunk, null);

        JButton btnSplit = btn("✂  Chia tệp", SUCCESS, e -> chiaTep());
        btnSplit.setPreferredSize(new Dimension(160, 38));
        JPanel action = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        action.setOpaque(false);
        action.add(btnSplit);

        g.gridy = 3; g.gridx = 0; g.gridwidth = 3; g.fill = GridBagConstraints.NONE; g.anchor = GridBagConstraints.EAST;
        form.add(action, g);

        card.add(form, BorderLayout.CENTER);
        return card;
    }

    // ============================================================
    // CARD 2 — GHÉP TỆP
    // ============================================================
    private JPanel buildCard2() {
        JPanel card = makeCard("2", "Ghép tệp", "Ghép các phần .part thành tệp hoàn chỉnh");

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 4, 6, 4);
        g.anchor = GridBagConstraints.WEST;
        g.fill = GridBagConstraints.HORIZONTAL;

        addField(form, g, 0, "Thư mục parts", txtMergeDir, null);
        addField(form, g, 1, "Tệp đầu ra", txtMergeOut, btn("💾 Chọn", PRIMARY, e -> chonFileSave(txtMergeOut)));

        JButton btnMerge = btn("🔗  Ghép tệp", SUCCESS, e -> ghepTep());
        btnMerge.setPreferredSize(new Dimension(160, 38));
        JPanel action = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        action.setOpaque(false);
        action.add(btnMerge);

        g.gridy = 2; g.gridx = 0; g.gridwidth = 3; g.fill = GridBagConstraints.NONE; g.anchor = GridBagConstraints.EAST;
        form.add(action, g);

        card.add(form, BorderLayout.CENTER);
        return card;
    }

    // ============================================================
    // CARD 3 — KIỂM TRA
    // ============================================================
    private JPanel buildCard3() {
        JPanel card = makeCard("3", "Kiểm tra toàn vẹn", "So sánh MD5 + SHA-256 giữa hai tệp");

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 4, 6, 4);
        g.anchor = GridBagConstraints.WEST;
        g.fill = GridBagConstraints.HORIZONTAL;

        addField(form, g, 0, "Tệp A", txtCheckA, btn("📂 Chọn", PRIMARY, e -> chonFile(txtCheckA)));
        addField(form, g, 1, "Tệp B", txtCheckB, btn("📂 Chọn", PRIMARY, e -> chonFile(txtCheckB)));

        JButton btnCheck = btn("🔍  Kiểm tra", WARNING, e -> kiemTra());
        btnCheck.setPreferredSize(new Dimension(160, 38));
        JPanel action = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        action.setOpaque(false);
        action.add(btnCheck);

        g.gridy = 2; g.gridx = 0; g.gridwidth = 3; g.fill = GridBagConstraints.NONE; g.anchor = GridBagConstraints.EAST;
        form.add(action, g);

        card.add(form, BorderLayout.CENTER);
        return card;
    }

    // ============================================================
    // LOG PANEL
    // ============================================================
    private JPanel buildLogPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setBackground(BG);
        panel.setBorder(new EmptyBorder(16, 0, 0, 0));

        JLabel lblLog = new JLabel("📝  Kết quả");
        lblLog.setFont(FONT_TITLE);
        lblLog.setForeground(new Color(0x1E293B));

        JButton btnClear = btn("🗑 Xóa log", new Color(0x64748B), e -> log.setText(""));
        btnClear.setPreferredSize(new Dimension(120, 32));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(lblLog, BorderLayout.WEST);
        top.add(btnClear, BorderLayout.EAST);

        log.setEditable(false);
        log.setFont(FONT_LOG);
        log.setBackground(new Color(0x0F172A));
        log.setForeground(new Color(0xE2E8F0));
        log.setCaretColor(Color.WHITE);
        log.setBorder(new EmptyBorder(10, 12, 10, 12));

        JScrollPane sp = new JScrollPane(log);
        sp.setBorder(new LineBorder(BORDER_C, 1, true));
        sp.setPreferredSize(new Dimension(0, 200));

        // Status bar
        lblStatus.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblStatus.setForeground(TEXT_MUTED);
        lblStatus.setBorder(new EmptyBorder(4, 0, 0, 0));

        panel.add(top, BorderLayout.NORTH);
        panel.add(sp, BorderLayout.CENTER);
        panel.add(lblStatus, BorderLayout.SOUTH);
        return panel;
    }

    // ============================================================
    // HELPER: CARD
    // ============================================================
    private JPanel makeCard(String number, String title, String subtitle) {
        JPanel card = new JPanel(new BorderLayout(0, 10)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 15));
                g2.fillRoundRect(2, 3, getWidth() - 4, getHeight() - 4, 16, 16);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
                g2.setColor(BORDER_C);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(16, 18, 16, 18));

        // Header của card
        JPanel head = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        head.setOpaque(false);

        JLabel badge = new JLabel(number, SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(PRIMARY);
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        badge.setFont(new Font("Segoe UI", Font.BOLD, 13));
        badge.setForeground(Color.WHITE);
        badge.setPreferredSize(new Dimension(28, 28));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(FONT_TITLE);
        lblTitle.setForeground(new Color(0x1E293B));

        JLabel lblSub = new JLabel("— " + subtitle);
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSub.setForeground(TEXT_MUTED);

        head.add(badge);
        head.add(lblTitle);
        head.add(lblSub);

        card.add(head, BorderLayout.NORTH);
        return card;
    }

    // ============================================================
    // HELPER: FIELD
    // ============================================================
    private void addField(JPanel form, GridBagConstraints g, int row,
                          String label, JTextField field, JButton btn) {
        g.gridy = row;

        // Label
        g.gridx = 0; g.weightx = 0; g.gridwidth = 1; g.fill = GridBagConstraints.NONE;
        JLabel lbl = new JLabel(label);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(new Color(0x334155));
        lbl.setPreferredSize(new Dimension(130, 24));
        form.add(lbl, g);

        // Field
        field.setFont(FONT_INPUT);
        field.setPreferredSize(new Dimension(0, 32));
        field.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER_C, 1, true),
                new EmptyBorder(4, 10, 4, 10)));

        g.gridx = 1; g.weightx = 1; g.fill = GridBagConstraints.HORIZONTAL;
        form.add(field, g);

        // Button (nếu có)
        if (btn != null) {
            btn.setPreferredSize(new Dimension(100, 32));
            g.gridx = 2; g.weightx = 0; g.fill = GridBagConstraints.NONE;
            g.insets = new Insets(6, 8, 6, 4);
            form.add(btn, g);
        }
    }

    // ============================================================
    // HELPER: BUTTON
    // ============================================================
    private JButton btn(String text, Color bg, ActionListener l) {
        JButton b = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color c = getModel().isRollover() ? bg.darker() : bg;
                if (getModel().isPressed()) c = bg.darker().darker();
                g2.setColor(c);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        b.setFont(FONT_BUTTON);
        b.setForeground(Color.WHITE);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(120, 34));
        b.addActionListener(l);
        return b;
    }

    // ============================================================
    // LOGIC (giữ nguyên)
    // ============================================================
    private void chiaTep() {
        try {
            File in = new File(txtInput.getText().trim());
            if (!in.isFile()) { log("❌ LỖI: Tệp không tồn tại"); status("Lỗi: tệp không tồn tại", DANGER); return; }
            int chunk = Integer.parseInt(txtChunk.getText().trim());
            if (chunk <= 0) { log("❌ LỖI: chunk phải > 0"); return; }

            File dir = new File(txtOutDir.getText().trim());
            if (!dir.exists()) dir.mkdirs();

            long start = System.currentTimeMillis();
            List<File> parts = new ArrayList<>();
            long total = 0;
            try (FileInputStream fis = new FileInputStream(in)) {
                byte[] buf = new byte[chunk];
                int idx = 0, r;
                while ((r = fis.read(buf)) != -1) {
                    File p = new File(dir, in.getName() + ".part" + idx++);
                    try (FileOutputStream fos = new FileOutputStream(p)) { fos.write(buf, 0, r); }
                    parts.add(p); total += r;
                }
            }
            long ms = System.currentTimeMillis() - start;
            log("✅ Đã chia " + parts.size() + " phần, tổng " + total + " byte (" + ms + " ms)");
            log("🔐 MD5 tệp gốc: " + checksum(in, "MD5"));
            status("Chia thành công " + parts.size() + " phần", SUCCESS);
        } catch (Exception ex) { log("❌ LỖI: " + ex.getMessage()); status("Lỗi: " + ex.getMessage(), DANGER); }
    }

    private void ghepTep() {
        try {
            File dir = new File(txtMergeDir.getText().trim());
            File[] parts = dir.listFiles((d, n) -> n.contains(".part"));
            if (parts == null || parts.length == 0) { log("❌ LỖI: không có file .part"); return; }
            Arrays.sort(parts, Comparator.comparingInt(f -> {
                String n = f.getName();
                try { return Integer.parseInt(n.substring(n.lastIndexOf(".part") + 5)); }
                catch (Exception e) { return Integer.MAX_VALUE; }
            }));

            File out = new File(txtMergeOut.getText().trim());
            long start = System.currentTimeMillis();
            long total = 0;
            try (FileOutputStream fos = new FileOutputStream(out)) {
                for (File p : parts) {
                    try (FileInputStream fis = new FileInputStream(p)) {
                        byte[] buf = new byte[8192]; int r;
                        while ((r = fis.read(buf)) != -1) { fos.write(buf, 0, r); total += r; }
                    }
                }
            }
            long ms = System.currentTimeMillis() - start;
            log("✅ Đã ghép " + parts.length + " phần, tổng " + total + " byte (" + ms + " ms)");
            log("🔐 MD5 tệp ghép: " + checksum(out, "MD5"));
            status("Ghép thành công " + parts.length + " phần", SUCCESS);
        } catch (Exception ex) { log("❌ LỖI: " + ex.getMessage()); status("Lỗi: " + ex.getMessage(), DANGER); }
    }

    private void kiemTra() {
        try {
            File a = new File(txtCheckA.getText().trim());
            File b = new File(txtCheckB.getText().trim());
            if (!a.isFile() || !b.isFile()) { log("❌ LỖI: tệp không tồn tại"); return; }

            boolean size = a.length() == b.length();
            String md5a = checksum(a, "MD5"), md5b = checksum(b, "MD5");
            String shaa = checksum(a, "SHA-256"), shab = checksum(b, "SHA-256");
            boolean smd5 = md5a.equals(md5b), ssha = shaa.equals(shab);

            log("──────── KIỂM TRA TOÀN VẸN ────────");
            log("Kích thước : " + (size ? "OK" : "KHÁC") + " (" + a.length() + " vs " + b.length() + ")");
            log("MD5        : " + (smd5 ? "OK" : "KHÁC"));
            log("  A: " + md5a); log("  B: " + md5b);
            log("SHA-256    : " + (ssha ? "OK" : "KHÁC"));
            boolean allOk = size && smd5 && ssha;
            log(allOk ? "🎉 HOÀN TOÀN GIỐNG NHAU" : "⚠  KHÁC NHAU");
            status(allOk ? "Hai tệp giống hệt" : "Hai tệp khác nhau", allOk ? SUCCESS : WARNING);
        } catch (Exception ex) { log("❌ LỖI: " + ex.getMessage()); }
    }

    private void log(String s) {
        log.append(s + "\n");
        log.setCaretPosition(log.getDocument().getLength());
    }

    private void status(String msg, Color c) {
        lblStatus.setText("  " + msg);
        lblStatus.setForeground(c);
    }

    // ============================================================
    // HELPER: FILE CHOOSER
    // ============================================================
    private void chonFile(JTextField target) {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new FileNameExtensionFilter("Tệp tin", "*.*"));
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
            target.setText(fc.getSelectedFile().getAbsolutePath());
    }

    private void chonFileSave(JTextField target) {
        JFileChooser fc = new JFileChooser();
        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION)
            target.setText(fc.getSelectedFile().getAbsolutePath());
    }

    // ============================================================
    // CHECKSUM
    // ============================================================
    static String checksum(File f, String algo) {
        try (InputStream is = new FileInputStream(f)) {
            MessageDigest md = MessageDigest.getInstance(algo);
            byte[] buf = new byte[8192]; int r;
            while ((r = is.read(buf)) != -1) md.update(buf, 0, r);
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return "(lỗi: " + e.getMessage() + ")"; }
    }

    // ============================================================
    // MAIN
    // ============================================================
    public static void main(String[] args) {
        // Nimbus L&F — đẹp hơn Metal mặc định
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
            UIManager.put("control", BG);
            UIManager.put("nimbusBase", PRIMARY);
            UIManager.put("nimbusFocus", PRIMARY);
            UIManager.put("text", new Color(0x1E293B));
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> new XuLyTep().setVisible(true));
    }
}