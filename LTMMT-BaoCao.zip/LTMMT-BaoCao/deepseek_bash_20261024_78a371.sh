bash -c 'set -e
TMPVENV=$(mktemp -d)/venv
python3 -m venv "$TMPVENV"
"$TMPVENV/bin/pip" install --quiet python-docx
"$TMPVENV/bin/python" - << "PYEOF"
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()
s = doc.styles["Normal"]; s.font.name = "Times New Roman"; s.font.size = Pt(13)

def h1(t): doc.add_heading(t, level=1)
def h2(t): doc.add_heading(t, level=2)
def h3(t): doc.add_heading(t, level=3)
def p(t, style=None): doc.add_paragraph(t, style=style)
def code(t): doc.add_paragraph(t, style="Intense Quote")
def bullet(t): p(t, style="List Bullet")
def num(t): p(t, style="List Number")

title = doc.add_heading("LẬP TRÌNH MẠNG MÁY TÍNH", level=0)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.add_paragraph("")
doc.add_paragraph("BÁO CÁO THỰC HÀNH CUỐI KỲ").alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.add_paragraph("")
for k, v in [("Sinh viên thực hiện:", "[Họ tên – MSSV – Lớp]"),
             ("Giảng viên hướng dẫn:", "[Tên GV]"),
             ("Thời gian thực hiện:", "[Tháng/Năm]")]:
    par = doc.add_paragraph(); par.add_run(k + " ").bold = True; par.add_run(v)
doc.add_page_break()

h1("MỤC LỤC")
for item in [
    "1. Đặt vấn đề", "2. Mục tiêu báo cáo",
    "3. Chương 1: Xử lý tệp nhị phân và văn bản trong Java",
    "4. Chương 2: Scanner và PrintWriter trong xử lý nhập/xuất định dạng",
    "5. Chương 3: Đồng bộ hóa (Synchronization) trong Java",
    "6. Chương 4: Lập trình Socket TCP với Java",
    "7. Chương 5: Multicast trong Java và MulticastSocket",
    "8. Chương 6: Kỹ thuật RMI (Remote Method Invocation)",
    "9. Kết luận và hướng phát triển", "10. Tài liệu tham khảo",
    "11. Phụ lục: Câu hỏi ôn tập",
]: num(item)
doc.add_page_break()

# 1
h1("1. ĐẶT VẤN ĐỀ")
p("Trong lập trình ứng dụng thực tế, việc xử lý tệp tin, nhập/xuất dữ liệu, đồng bộ hóa đa luồng và giao tiếp mạng là những kỹ năng cốt lõi mà mọi lập trình viên Java cần nắm vững. Java cung cấp một hệ sinh thái thư viện mạnh mẽ (java.io, java.nio, java.net, java.rmi, java.util.concurrent...) cho phép xây dựng các ứng dụng từ đơn giản đến phức tạp.")
p("Báo cáo này trình bày 6 chủ đề thực hành trọng tâm, mỗi chủ đề đi kèm một demo minh họa chạy được trên Apache NetBeans, nhằm củng cố cả lý thuyết lẫn kỹ năng thực hành.")
p("Bố cục báo cáo gồm 6 chương tương ứng với 6 chủ đề, kết luận và phụ lục câu hỏi ôn tập. Mỗi chương được trình bày theo cấu trúc: Cơ sở lý thuyết → Phân tích → Demo → Kết quả thực nghiệm → Nhận xét → Ứng dụng thực tế.")

# 2
h1("2. MỤC TIÊU BÁO CÁO")
for m in [
    "Hiểu và vận dụng được cơ chế đọc/ghi tệp nhị phân và văn bản trong Java.",
    "Sử dụng thành thạo Scanner, PrintWriter để nhập/xuất dữ liệu có định dạng (CSV).",
    "Nắm được cơ chế đồng bộ hóa trong đa luồng và hậu quả của race condition.",
    "Xây dựng được ứng dụng Client–Server qua Socket TCP.",
    "Hiểu và triển khai được Multicast UDP trong Java.",
    "Nắm được kiến trúc RMI và triển khai được lời gọi phương thức từ xa.",
]:
    bullet(m)

# CHƯƠNG 1
h1("CHƯƠNG 1: XỬ LÝ TỆP NHỊ PHÂN VÀ VĂN BẢN TRONG JAVA")
h2("1.1. Cơ sở lý thuyết")
h3("1.1.1. Khái niệm tệp nhị phân và văn bản")
p("Tệp nhị phân lưu trữ dữ liệu dưới dạng byte, không có mã hóa ký tự. Ví dụ: ảnh, PDF, âm thanh, video, file nén.")
p("Tệp văn bản lưu trữ dữ liệu dưới dạng ký tự, có mã hóa (UTF-8, ASCII...). Ví dụ: .txt, .csv, .json, .xml.")
h3("1.1.2. Phân loại luồng tệp")
t = doc.add_table(rows=1, cols=4); t.style = "Table Grid"
h = t.rows[0].cells
h[0].text="Loại"; h[1].text="Lớp cơ sở"; h[2].text="Đơn vị"; h[3].text="Ứng dụng"
for r in [
    ("Nhị phân (byte)", "InputStream / OutputStream", "byte (8-bit)", "Ảnh, PDF, âm thanh, video, file nén"),
    ("Văn bản (ký tự)", "Reader / Writer", "ký tự (16-bit)", "File .txt, .csv, .json, log"),
]:
    c = t.add_row().cells
    for i, v in enumerate(r): c[i].text = v
h3("1.1.3. Các lớp cụ thể thường dùng")
for b in [
    "FileInputStream / FileOutputStream — đọc/ghi byte thô.",
    "BufferedInputStream / BufferedOutputStream — thêm bộ đệm, tăng hiệu năng.",
    "DataInputStream / DataOutputStream — đọc/ghi kiểu nguyên thủy.",
    "FileReader / FileWriter — đọc/ghi ký tự.",
    "BufferedReader / BufferedWriter — bộ đệm ký tự, có readLine().",
]:
    bullet(b)
h2("1.2. Phân tích")
p("Việc chia nhỏ tệp nhị phân thành các đoạn có nhiều ứng dụng:")
for b in [
    "Truyền file qua mạng có giới hạn kích thước gói.",
    "Resume download (tải tiếp khi mất kết nối).",
    "Song song hóa việc tải file (nhiều phần cùng lúc).",
]:
    bullet(b)
p("Khi chia nhỏ, cần chú ý đọc đúng số byte thực tế (read trả về), đặc biệt ở phần cuối file — phần cuối có thể ít hơn CHUNK_SIZE.")

h2("1.3. Demo: Chia tệp nhị phân 100 byte và ghép lại")
h3("1.3.1. Mục tiêu")
p("Chia một file ảnh/PDF thành các đoạn 100 byte, sau đó ghép lại và kiểm tra tính toàn vẹn.")
h3("1.3.2. Ý tưởng thuật toán")
num("Mở FileInputStream trên file gốc.")
num("Đọc lần lượt vào buffer 100 byte; mỗi lần đọc ghi ra file partN.")
num("Khi ghép: mở FileOutputStream, đọc lần lượt từng part và ghi nối tiếp.")
num("So sánh kích thước và nội dung byte giữa file gốc và file ghép.")
h3("1.3.3. Mã nguồn")
code("""private static final int CHUNK_SIZE = 100;

public static List<File> split(File inputFile, String outputDir) throws IOException {
    List<File> parts = new ArrayList<>();
    File dir = new File(outputDir);
    if (!dir.exists()) dir.mkdirs();
    try (FileInputStream fis = new FileInputStream(inputFile)) {
        byte[] buffer = new byte[CHUNK_SIZE];
        int partIndex = 0, totalBytes = 0, read;
        while ((read = fis.read(buffer)) != -1) {
            File part = new File(dir, inputFile.getName() + ".part" + partIndex++);
            try (FileOutputStream fos = new FileOutputStream(part)) {
                fos.write(buffer, 0, read);
            }
            parts.add(part);
            totalBytes += read;
        }
        System.out.println("Đã chia thành " + parts.size() + " phần, tổng " + totalBytes + " byte.");
    }
    return parts;
}

public static File merge(List<File> parts, File outputFile) throws IOException {
    int totalBytes = 0;
    try (FileOutputStream fos = new FileOutputStream(outputFile)) {
        for (File part : parts) {
            try (FileInputStream fis = new FileInputStream(part)) {
                byte[] buf = new byte[CHUNK_SIZE];
                int read;
                while ((read = fis.read(buf)) != -1) {
                    fos.write(buf, 0, read);
                    totalBytes += read;
                }
            }
        }
    }
    System.out.println("Đã ghép " + parts.size() + " phần, tổng " + totalBytes + " byte xử lý.");
    return outputFile;
}""")
h2("1.4. Kết quả thực nghiệm")
for b in [
    "File gốc sample.jpg: 500 byte.",
    "Chia thành 5 phần: sample.jpg.part0 … part4, mỗi phần 100 byte.",
    "File ghép sample_merged.jpg: 500 byte.",
    "Log: Đã chia thành 5 phần, tổng 500 byte. / Đã ghép 5 phần, tổng 500 byte xử lý.",
    "So sánh: Khớp = true → nội dung byte giống hệt.",
]:
    bullet(b)
h2("1.5. Nhận xét")
p("Việc chia nhỏ file hữu ích khi truyền file qua mạng có giới hạn kích thước gói hoặc cần resume download. Cần đọc đúng số byte thực tế (read trả về), đặc biệt ở phần cuối file.")
h2("1.6. Ứng dụng thực tế")
for b in [
    "Truyền file qua mạng (FTP, HTTP range request).",
    "Resume download.",
    "Backup dữ liệu.",
    "Chia sẻ file P2P.",
]:
    bullet(b)
doc.add_page_break()

# CHƯƠNG 2
h1("CHƯƠNG 2: SCANNER VÀ PRINTWRITER TRONG XỬ LÝ NHẬP/XUẤT ĐỊNH DẠNG")
h2("2.1. Cơ sở lý thuyết")
h3("2.1.1. Scanner")
p("Scanner là lớp tiện ích đọc dữ liệu từ nhiều nguồn (System.in, file, chuỗi), hỗ trợ parse kiểu (nextInt, nextDouble, nextLine...).")
h3("2.1.2. PrintWriter")
p("PrintWriter là lớp ghi dữ liệu đã định dạng ra Writer, có print, println, printf tương tự System.out.")
h3("2.1.3. Định dạng CSV")
p("CSV (Comma-Separated Values): mỗi dòng là một bản ghi, các trường cách nhau bởi dấu phẩy. Nếu trường chứa dấu phẩy hoặc xuống dòng, cần bọc trong dấu ngoặc kép.")
h2("2.2. Phân tích")
p("Ưu điểm của Scanner:")
for b in [
    "Dễ dùng, hỗ trợ nhiều kiểu dữ liệu.",
    "Có thể đọc từ nhiều nguồn.",
]:
    bullet(b)
p("Nhược điểm:")
for b in [
    "Chậm hơn BufferedReader khi đọc số lượng lớn.",
    "Không thread-safe.",
]:
    bullet(b)
p("Ưu điểm của PrintWriter:")
for b in [
    "Hỗ trợ định dạng (printf).",
    "Tự động flush nếu cần.",
]:
    bullet(b)

h2("2.3. Demo: Nhập thông tin nhân viên → lưu CSV")
h3("2.3.1. Mục tiêu")
p("Nhập từ bàn phím thông tin nhiều nhân viên (ID, họ tên, phòng ban, lương), ghi ra employee.csv mở được bằng Excel.")
h3("2.3.2. Luồng xử lý")
num("Tạo Scanner(System.in) để đọc bàn phím.")
num("Tạo PrintWriter(new FileWriter(\"employee.csv\")).")
num("Ghi dòng header: ID,HoTen,PhongBan,Luong.")
num("Vòng lặp nhập từng nhân viên, ghi bằng printf với định dạng CSV.")
num("flush() và đóng file.")
num("Đọc lại bằng Scanner(new File(...)) để kiểm tra.")
h3("2.3.3. Mã nguồn")
code("""try (Scanner sc = new Scanner(System.in);
     PrintWriter pw = new PrintWriter(new FileWriter("employee.csv"))) {
    pw.println("ID,HoTen,PhongBan,Luong");
    System.out.print("Nhập số nhân viên: ");
    int n = Integer.parseInt(sc.nextLine());
    for (int i = 0; i < n; i++) {
        System.out.print("ID: "); String id = sc.nextLine();
        System.out.print("Họ tên: "); String name = sc.nextLine();
        System.out.print("Phòng ban: "); String dept = sc.nextLine();
        System.out.print("Lương: "); String salary = sc.nextLine();
        pw.printf("%s,\\"%s\\",\\"%s\\",%s%n", id, name, dept, salary);
    }
    pw.flush();
}""")
h2("2.4. Kết quả thực nghiệm")
code("""ID,HoTen,PhongBan,Luong
NV01,"Nguyễn Văn A","Kế toán",15000000
NV02,"Trần Thị B","IT",20000000""")
p("File employee.csv mở trong Excel hiển thị đúng 4 cột, không lỗi tách cột do dấu phẩy trong tên.")
h2("2.5. Nhận xét")
p("Cần bọc ngoặc kép các trường văn bản để tránh lỗi CSV. Nếu muốn Excel hiển thị đúng tiếng Việt, nên ghi UTF-8 có BOM.")
h2("2.6. Ứng dụng thực tế")
for b in [
    "Xuất báo cáo.",
    "Nhập liệu hàng loạt.",
    "Trao đổi dữ liệu với Excel/Google Sheets.",
]:
    bullet(b)
doc.add_page_break()

# CHƯƠNG 3
h1("CHƯƠNG 3: ĐỒNG BỘ HÓA (SYNCHRONIZATION) TRONG JAVA")
h2("3.1. Cơ sở lý thuyết")
h3("3.1.1. Race condition")
p("Khi nhiều thread cùng truy cập và thay đổi tài nguyên chia sẻ mà không đồng bộ, xảy ra race condition — kết quả phụ thuộc vào thứ tự thực thi không xác định của các thread.")
h3("3.1.2. Mutual exclusion")
p("Java cung cấp từ khóa synchronized để đảm bảo mutual exclusion: tại một thời điểm chỉ một thread được vào vùng critical section.")
h3("3.1.3. Các cấp độ đồng bộ")
for b in [
    "Phương thức synchronized: khóa trên this (instance method) hoặc trên class (static method).",
    "Khối synchronized(obj): khóa trên đối tượng cụ thể, linh hoạt hơn.",
    "ReentrantLock: khóa tường minh, hỗ trợ tryLock, lockInterruptibly.",
    "AtomicInteger, AtomicLong: biến nguyên tử, không cần khóa cho phép toán đơn giản.",
]:
    bullet(b)
h2("3.2. Phân tích")
p("Tại sao tickets-- không nguyên tử?")
p("Phép tickets-- gồm 3 bước: đọc giá trị, giảm, ghi lại. Hai thread có thể cùng đọc tickets = 1, cùng thấy > 0, cùng giảm → bán 2 vé dù chỉ còn 1.")
p("synchronized đảm bảo chỉ một thread vào vùng critical tại một thời điểm, ngăn race condition.")
h2("3.3. Demo: Bán vé (shared counter) có và không synchronized")
h3("3.3.1. Mục tiêu")
p("Mô phỏng 3 thread cùng bán 100 vé. So sánh kết quả khi không đồng bộ và có đồng bộ.")
h3("3.3.2. Kịch bản")
num("TicketCounter giữ biến tickets = 100.")
num("Hàm sell() kiểm tra tickets > 0, giảm tickets--.")
num("Chạy 3 thread, mỗi thread gọi sell() 100 lần.")
num("Kỳ vọng: bán đúng 100 vé, còn lại 0.")
h3("3.3.3. Mã nguồn")
code("""class TicketCounter {
    private int tickets = 100;
    public void sellUnsynchronized(String name) {
        if (tickets > 0) {
            try { Thread.sleep(1); } catch (InterruptedException e) {}
            tickets--;
        }
    }
    public synchronized void sellSynchronized(String name) {
        if (tickets > 0) {
            try { Thread.sleep(1); } catch (InterruptedException e) {}
            tickets--;
        }
    }
}""")
h2("3.4. Kết quả thực nghiệm")
t = doc.add_table(rows=1, cols=3); t.style = "Table Grid"
h = t.rows[0].cells
h[0].text="Trường hợp"; h[1].text="Số vé còn lại"; h[2].text="Nhận xét"
for r in [
    ("Không synchronized", "Thường âm (-37, -12...) hoặc khác 0", "Race condition: nhiều thread cùng đọc tickets > 0 trước khi giảm → bán quá số vé"),
    ("Có synchronized", "Luôn = 0", "Đồng bộ hoạt động đúng, không bán quá"),
]:
    c = t.add_row().cells
    for i, v in enumerate(r): c[i].text = v
h2("3.5. Nhận xét")
p("Đồng bộ hóa là bắt buộc khi có shared mutable state. Tuy nhiên lạm dụng synchronized có thể gây deadlock hoặc giảm hiệu năng; nên cân nhắc AtomicInteger cho phép toán đơn giản, hoặc ConcurrentHashMap cho collection.")
h2("3.6. Ứng dụng thực tế")
for b in [
    "Quản lý tài khoản ngân hàng.",
    "Đặt vé/đặt hàng.",
    "Bộ đếm chia sẻ.",
    "Hàng đợi sự kiện.",
]:
    bullet(b)
doc.add_page_break()

# CHƯƠNG 4
h1("CHƯƠNG 4: LẬP TRÌNH SOCKET TCP VỚI JAVA")
h2("4.1. Cơ sở lý thuyết")
h3("4.1.1. Socket")
p("Socket là điểm cuối (endpoint) của kết nối mạng, được xác định bởi cặp (IP, port). TCP là giao thức hướng kết nối, tin cậy, đảm bảo thứ tự và toàn vẹn dữ liệu.")
h3("4.1.2. Mô hình Client–Server qua TCP")
num("Server tạo ServerSocket(port) và gọi accept() — block chờ client.")
num("Client tạo Socket(host, port) — kết nối tới server.")
num("Hai bên trao đổi qua InputStream/OutputStream của socket.")
num("Đóng kết nối bằng close().")
h2("4.2. Phân tích")
p("Ưu điểm của Socket TCP:")
for b in [
    "Tin cậy, đảm bảo thứ tự.",
    "Dễ dùng, tích hợp sẵn trong JDK.",
]:
    bullet(b)
p("Nhược điểm:")
for b in [
    "Chậm hơn UDP.",
    "Cần xử lý IOException, đóng tài nguyên.",
    "Server đơn luồng chỉ phục vụ 1 client — cần ExecutorService cho đa client.",
]:
    bullet(b)
h2("4.3. Demo: Client gửi chuỗi → Server ghi log")
h3("4.3.1. Mục tiêu")
p("Client nhập văn bản từ bàn phím, gửi qua TCP tới server; server ghi từng dòng vào server_log.txt.")
h3("4.3.2. Luồng xử lý Server")
num("Tạo ServerSocket(5000).")
num("accept() chờ client.")
num("Bọc InputStream của socket trong BufferedReader.")
num("Đọc từng dòng bằng readLine(), ghi vào PrintWriter của file log.")
num("Khi nhận exit → thoát vòng lặp, đóng kết nối.")
h3("4.3.3. Luồng xử lý Client")
num("Tạo Socket(\"localhost\", 5000).")
num("Đọc bàn phím bằng BufferedReader(System.in).")
num("Gửi từng dòng qua PrintWriter(socket.getOutputStream(), true).")
num("Gõ exit để thoát.")
h3("4.3.4. Mã nguồn")
code("""// TCPServer.java
try (ServerSocket server = new ServerSocket(5000);
     PrintWriter log = new PrintWriter(new FileWriter("server_log.txt", true))) {
    System.out.println("Server đang chờ kết nối ở port 5000...");
    try (Socket client = server.accept();
         BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))) {
        String line;
        while ((line = in.readLine()) != null) {
            System.out.println("Nhận: " + line);
            log.println(line); log.flush();
            if (line.equalsIgnoreCase("exit")) break;
        }
    }
}

// TCPClient.java
try (Socket socket = new Socket("localhost", 5000);
     PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
     BufferedReader kb = new BufferedReader(new InputStreamReader(System.in))) {
    String line;
    while ((line = kb.readLine()) != null) {
        out.println(line);
        if (line.equalsIgnoreCase("exit")) break;
    }
}""")
h2("4.4. Kết quả thực nghiệm")
for b in [
    "Chạy TCPServer → console: Server đang chờ kết nối ở port 5000...",
    "Chạy TCPClient, nhập: Xin chào server / Đây là dòng thứ hai / exit",
    "File server_log.txt chứa đúng nội dung đã gửi.",
    "Console server in: Nhận: Xin chào server / Nhận: Đây là dòng thứ hai",
]:
    bullet(b)
h2("4.5. Nhận xét")
p("Socket TCP phù hợp cho ứng dụng cần truyền dữ liệu tin cậy (chat, file transfer, HTTP). Cần xử lý IOException, đóng tài nguyên đúng cách, và có thể dùng ExecutorService để phục vụ nhiều client đồng thời.")
h2("4.6. Ứng dụng thực tế")
for b in [
    "Chat server/client.",
    "Truyền file.",
    "HTTP server đơn giản.",
    "Điều khiển từ xa.",
]:
    bullet(b)
doc.add_page_break()

# CHƯƠNG 5
h1("CHƯƠNG 5: MULTICAST TRONG JAVA VÀ MULTICASTSOCKET")
h2("5.1. Cơ sở lý thuyết")
h3("5.1.1. Multicast")
p("Multicast là cơ chế truyền một gói tin tới một nhóm địa chỉ (multicast group), thay vì unicast (1–1) hay broadcast (1–tất cả trong subnet). Multicast tiết kiệm băng thông khi cần gửi cùng dữ liệu cho nhiều receiver.")
h3("5.1.2. Địa chỉ và giao thức")
for b in [
    "Địa chỉ multicast IPv4: 224.0.0.0 – 239.255.255.255 (thường dùng 230.0.0.1).",
    "Giao thức nền: UDP (không đảm bảo tin cậy).",
    "Java: lớp MulticastSocket, phương thức joinGroup(InetAddress), leaveGroup(...).",
    "Gửi: DatagramPacket(buf, len, group, port) + socket.send(packet).",
    "Nhận: socket.receive(packet) sau khi đã joinGroup.",
]:
    bullet(b)
h2("5.2. Phân tích")
p("Ưu điểm multicast:")
for b in [
    "Tiết kiệm băng thông (gửi 1 lần, nhiều client nhận).",
    "Phù hợp streaming, cập nhật trạng thái đồng loạt.",
]:
    bullet(b)
p("Nhược điểm:")
for b in [
    "Không đảm bảo tin cậy (UDP).",
    "Có thể bị chặn bởi firewall.",
    "Không hoạt động qua Internet (chỉ trong LAN hoặc mạng hỗ trợ multicast).",
]:
    bullet(b)
h2("5.3. Demo: 1 server phát, nhiều client nhận")
h3("5.3.1. Mục tiêu")
p("Server gửi 5 thông điệp multicast tới group 230.0.0.1:4446; tất cả client trong group đều nhận và hiển thị.")
h3("5.3.2. Luồng xử lý Server")
p("Tạo MulticastSocket(), tạo DatagramPacket với địa chỉ group và port, gửi 5 thông điệp cách nhau 1 giây.")
h3("5.3.3. Luồng xử lý Client")
p("Tạo MulticastSocket(4446), joinGroup(230.0.0.1), receive() 5 lần, in nội dung, leaveGroup().")
h3("5.3.4. Mã nguồn")
code("""// MulticastServer.java
InetAddress group = InetAddress.getByName("230.0.0.1");
try (MulticastSocket socket = new MulticastSocket()) {
    for (int i = 1; i <= 5; i++) {
        String msg = "Thông điệp multicast #" + i;
        byte[] buf = msg.getBytes();
        socket.send(new DatagramPacket(buf, buf.length, group, 4446));
        System.out.println("Đã gửi: " + msg);
        Thread.sleep(1000);
    }
}

// MulticastClient.java
InetAddress group = InetAddress.getByName("230.0.0.1");
try (MulticastSocket socket = new MulticastSocket(4446)) {
    socket.joinGroup(group);
    byte[] buf = new byte[1024];
    for (int i = 0; i < 5; i++) {
        DatagramPacket packet = new DatagramPacket(buf, buf.length);
        socket.receive(packet);
        System.out.println("Nhận: " + new String(packet.getData(), 0, packet.getLength()));
    }
    socket.leaveGroup(group);
}""")
h2("5.4. Kết quả thực nghiệm")
p("Chạy MulticastServer → gửi 5 thông điệp. Chạy 3 instance MulticastClient → cả 3 đều in đủ 5 thông điệp giống nhau → multicast hoạt động đúng.")
h2("5.5. Nhận xét")
p("Multicast phù hợp cho streaming, cập nhật trạng thái đồng loạt (stock ticker, game lobby). Lưu ý multicast có thể bị chặn bởi firewall hoặc không hoạt động qua Internet. Cần đặt TTL phù hợp nếu muốn gói đi xa hơn subnet (socket.setTimeToLive(1)).")
h2("5.6. Ứng dụng thực tế")
for b in [
    "Streaming video/audio.",
    "Cập nhật trạng thái đồng loạt (stock ticker, game lobby).",
    "Phân phối phần mềm trong LAN.",
    "Video conference.",
]:
    bullet(b)
doc.add_page_break()

# CHƯƠNG 6
h1("CHƯƠNG 6: KỸ THUẬT RMI (REMOTE METHOD INVOCATION)")
h2("6.1. Cơ sở lý thuyết")
h3("6.1.1. Khái niệm RMI")
p("RMI cho phép một chương trình Java gọi phương thức của đối tượng nằm ở JVM khác (khác máy hoặc khác process) như thể gọi local. RMI che giấu chi tiết marshalling/unmarshalling và truyền tải mạng.")
h3("6.1.2. Kiến trúc 3 thành phần")
p("Stub (phía client): proxy của remote object, chuyển lời gọi thành dữ liệu mạng, gửi tới server, nhận kết quả.")
p("Skeleton (phía server): nhận dữ liệu, unmarshal, gọi phương thức thực, marshal kết quả trả về (từ Java 2 tích hợp vào RMI runtime).")
p("Registry: dịch vụ danh bạ ánh xạ tên → tham chiếu remote object. Server đăng ký bằng rebind; client tra cứu bằng lookup.")
h3("6.1.3. Yêu cầu")
for b in [
    "Interface remote phải kế thừa java.rmi.Remote.",
    "Mỗi phương thức phải khai báo throws RemoteException.",
    "Implementation kế thừa UnicastRemoteObject (hoặc export thủ công).",
    "Tham số/giá trị trả về phải Serializable.",
]:
    bullet(b)
h2("6.2. Phân tích")
p("Ưu điểm RMI:")
for b in [
    "Đơn giản hóa lập trình phân tán trong Java.",
    "Che giấu chi tiết mạng, marshalling.",
    "Tích hợp sẵn trong JDK.",
]:
    bullet(b)
p("Nhược điểm:")
for b in [
    "Gắn chặt với Java.",
    "Cần mở port 1099 trên firewall nếu chạy khác máy.",
]:
    bullet(b)
h2("6.3. Demo: Client gọi sayHello() từ Server")
h3("6.3.1. Mục tiêu")
p("Xây dựng RMI server đăng ký HelloService tại port 1099; client tra cứu và gọi sayHello(), nhận chuỗi trả về; server log Server đã được gọi từ xa.")
h3("6.3.2. Cấu trúc 4 file")
p("Hello.java (interface), HelloImpl.java (implementation), RMIServer.java, RMIClient.java.")
h3("6.3.3. Mã nguồn")
code("""// Hello.java
public interface Hello extends Remote {
    String sayHello() throws RemoteException;
}

// HelloImpl.java
public class HelloImpl extends UnicastRemoteObject implements Hello {
    public HelloImpl() throws RemoteException { super(); }
    public String sayHello() throws RemoteException {
        System.out.println("Server đã được gọi từ xa");
        return "Hello từ RMI Server!";
    }
}

// RMIServer.java
Registry registry = LocateRegistry.createRegistry(1099);
registry.rebind("HelloService", new HelloImpl());
System.out.println("RMI Server đã sẵn sàng tại port 1099");

// RMIClient.java
Registry registry = LocateRegistry.getRegistry("localhost", 1099);
Hello hello = (Hello) registry.lookup("HelloService");
System.out.println("Kết quả từ server: " + hello.sayHello());""")
h2("6.4. Kết quả thực nghiệm")
for b in [
    "Chạy RMIServer → console: RMI Server đã sẵn sàng tại port 1099, tên HelloService.",
    "Chạy RMIClient → console client: Kết quả từ server: Hello từ RMI Server!",
    "Console server đồng thời in: Server đã được gọi từ xa → lời gọi từ xa hoạt động.",
]:
    bullet(b)
h2("6.5. Nhận xét")
p("RMI đơn giản hóa lập trình phân tán trong Java nhưng gắn chặt với Java. Trên JDK 17+ không cần chạy rmic — stub được sinh động. Cần mở port 1099 trên firewall nếu chạy khác máy. RMI là nền tảng để hiểu các công nghệ cao hơn như EJB, Spring Remoting.")
h2("6.6. Ứng dụng thực tế")
for b in [
    "Hệ thống phân tán trong doanh nghiệp.",
    "Gọi dịch vụ từ xa trong ứng dụng Java.",
    "Nền tảng học EJB, Spring Remoting.",
]:
    bullet(b)
doc.add_page_break()

# KẾT LUẬN
h1("KẾT LUẬN VÀ HƯỚNG PHÁT TRIỂN")
h2("Kết luận")
p("Qua 6 chủ đề thực hành, báo cáo đã trình bày và minh họa được:")
for b in [
    "Xử lý tệp nhị phân/văn bản — chia nhỏ và ghép file 100 byte, kiểm tra toàn vẹn thành công.",
    "Scanner/PrintWriter — nhập liệu bàn phím, xuất CSV mở được bằng Excel.",
    "Đồng bộ hóa — chứng minh race condition khi không synchronized và kết quả đúng khi có đồng bộ.",
    "Socket TCP — client–server gửi chuỗi, server ghi log đầy đủ.",
    "Multicast — một server phát, nhiều client cùng nhận thông điệp.",
    "RMI — client gọi phương thức từ xa sayHello(), server log xác nhận.",
]:
    bullet(b)
p("Mỗi demo đều chạy được trên Apache NetBeans, kết quả đúng như kỳ vọng, log hiển thị rõ ràng.")
h2("Hướng phát triển")
for b in [
    "Mở rộng demo 1 thành ứng dụng truyền file qua mạng có chia nhỏ + checksum (MD5/SHA-256) để kiểm tra toàn vẹn.",
    "Demo 2: thêm chức năng đọc/ghi CSV bằng thư viện OpenCSV, hỗ trợ Unicode đầy đủ.",
    "Demo 3: so sánh thêm ReentrantLock và AtomicInteger về hiệu năng.",
    "Demo 4: nâng cấp server dùng thread pool (ExecutorService) phục vụ nhiều client đồng thời.",
    "Demo 5: thêm giao diện JavaFX/Swing hiển thị thông điệp multicast realtime.",
    "Demo 6: kết hợp RMI với SSL/TLS để bảo mật lời gọi từ xa.",
]:
    bullet(b)

h1("TÀI LIỆU THAM KHẢO")
for i, ref in enumerate([
    "Oracle. Java SE Documentation – Java I/O, Networking, RMI. https://docs.oracle.com/javase/",
    "Herbert Schildt. Java: The Complete Reference, 12th Edition. McGraw-Hill, 2021.",
    "Cay S. Horstmann. Core Java Volume II — Advanced Features, 11th Edition. Pearson, 2019.",
    "Apache NetBeans Documentation. https://netbeans.apache.org/",
    "Baeldung. Java Networking Tutorials, Java RMI Guide. https://www.baeldung.com/",
], 1):
    p(f"[{i}] {ref}")

h1("PHỤ LỤC: CÂU HỎI ÔN TẬP")
h2("Chương 1")
for q in [
    "Phân biệt tệp nhị phân và tệp văn bản.",
    "Tại sao cần đọc đúng số byte thực tế khi chia tệp?",
    "Làm sao kiểm tra tính toàn vẹn sau khi ghép?",
]:
    bullet(q)
h2("Chương 2")
for q in [
    "Scanner và BufferedReader khác nhau thế nào?",
    "Tại sao cần bọc ngoặc kép trường văn bản trong CSV?",
    "Làm sao ghi UTF-8 có BOM?",
]:
    bullet(q)
h2("Chương 3")
for q in [
    "Race condition là gì? Cho ví dụ.",
    "synchronized hoạt động như thế nào?",
    "Khi nào nên dùng AtomicInteger thay vì synchronized?",
]:
    bullet(q)
h2("Chương 4")
for q in [
    "Mô tả quy trình Client–Server qua TCP.",
    "Làm sao server phục vụ nhiều client đồng thời?",
    "Tại sao cần đóng socket sau khi dùng?",
]:
    bullet(q)
h2("Chương 5")
for q in [
    "Multicast khác unicast và broadcast thế nào?",
    "Tại sao multicast dùng UDP thay vì TCP?",
    "Làm sao giới hạn multicast trong subnet?",
]:
    bullet(q)
h2("Chương 6")
for q in [
    "RMI là gì? Kiến trúc 3 thành phần gồm những gì?",
    "Yêu cầu để một interface trở thành remote interface?",
    "Registry trong RMI có vai trò gì?",
]:
    bullet(q)

doc.save("2-CK-Tra-Loi.docx")
print("Đã tạo: 2-CK-Tra-Loi.docx")
PYEOF
rm -rf "$(dirname "$TMPVENV")"'