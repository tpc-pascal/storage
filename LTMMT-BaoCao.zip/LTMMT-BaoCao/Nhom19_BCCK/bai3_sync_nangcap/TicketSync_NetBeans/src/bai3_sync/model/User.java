package bai3_sync.model;

public record User(int id, String username, String fullName, String role, boolean active) {
    public boolean isAdmin() { return "ADMIN".equalsIgnoreCase(role); }
}
