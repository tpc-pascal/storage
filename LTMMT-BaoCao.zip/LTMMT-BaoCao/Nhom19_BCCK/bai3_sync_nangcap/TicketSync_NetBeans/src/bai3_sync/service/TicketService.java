package bai3_sync.service;

import bai3_sync.config.Database;
import bai3_sync.model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * Logic bán vé. SYNC dùng synchronized + transaction/row lock.
 * UNSYNC cố tình dùng SELECT-đợi-UPDATE không điều kiện để minh họa race condition.
 * Không dùng chế độ UNSYNC cho hệ thống bán vé thật.
 */
public class TicketService {
    private final AuthService authService = new AuthService();
    private static final long DEMO_DELAY_MS = 600L;

    public record Stats(int totalTickets, int soldTickets, int availableTickets,
                        int saleTransactions, int duplicateTickets) {}
    public record PurchaseResult(String ticketCode, int counterNo, String mode, String buyer) {}
    public record InventoryRow(String code, String status, int purchaseCount, String lastCounter, String lastBuyer, String soldAt) {}
    public record SaleRow(String ticketCode, String buyer, String counter, String purchaseTime, String mode, boolean duplicate) {}

    public Stats getStats() throws SQLException {
        String sql = "SELECT " +
                "(SELECT COUNT(*) FROM dbo.Tickets) AS TotalTickets, " +
                "(SELECT COUNT(*) FROM dbo.Tickets WHERE Status='SOLD') AS SoldTickets, " +
                "(SELECT COUNT(*) FROM dbo.Tickets WHERE Status='AVAILABLE') AS AvailableTickets, " +
                "(SELECT COUNT(*) FROM dbo.Purchases) AS SaleTransactions, " +
                "(SELECT COUNT(*) FROM (SELECT TicketId FROM dbo.Purchases GROUP BY TicketId HAVING COUNT(*) > 1) d) AS DuplicateTickets";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            rs.next();
            return new Stats(rs.getInt("TotalTickets"), rs.getInt("SoldTickets"), rs.getInt("AvailableTickets"),
                    rs.getInt("SaleTransactions"), rs.getInt("DuplicateTickets"));
        }
    }

    public List<InventoryRow> listInventory() throws SQLException {
        String sql = "SELECT t.TicketCode, t.Status, COALESCE(pc.PurchaseCount, 0) AS PurchaseCount, " +
                "COALESCE(CONCAT(N'Quầy ', recent.CounterNo), N'—') AS LastCounter, " +
                "COALESCE(recent.Username, N'—') AS LastBuyer, " +
                "COALESCE(CONVERT(VARCHAR(19), recent.PurchaseTime, 120), N'—') AS LastTime " +
                "FROM dbo.Tickets t " +
                "LEFT JOIN (SELECT TicketId, COUNT(*) AS PurchaseCount FROM dbo.Purchases GROUP BY TicketId) pc ON pc.TicketId=t.TicketId " +
                "OUTER APPLY (SELECT TOP (1) p.CounterNo, u.Username, p.PurchaseTime FROM dbo.Purchases p " +
                "JOIN dbo.AppUsers u ON u.UserId=p.UserId WHERE p.TicketId=t.TicketId " +
                "ORDER BY p.PurchaseTime DESC, p.PurchaseId DESC) recent " +
                "ORDER BY t.TicketId";
        List<InventoryRow> rows = new ArrayList<>();
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) rows.add(new InventoryRow(rs.getString(1), rs.getString(2), rs.getInt(3),
                    rs.getString(4) == null ? "—" : rs.getString(4),
                    rs.getString(5) == null ? "—" : rs.getString(5),
                    rs.getString(6) == null ? "—" : rs.getString(6)));
        }
        return rows;
    }

    public List<SaleRow> listMyPurchases(int userId) throws SQLException {
        String sql = "SELECT t.TicketCode, u.Username, CONCAT(N'Quầy ',p.CounterNo) AS CounterName, " +
                "CONVERT(VARCHAR(19),p.PurchaseTime,120) AS BoughtAt, p.SyncMode, " +
                "CASE WHEN x.Cnt > 1 THEN 1 ELSE 0 END AS IsDuplicate " +
                "FROM dbo.Purchases p JOIN dbo.Tickets t ON t.TicketId=p.TicketId " +
                "JOIN dbo.AppUsers u ON u.UserId=p.UserId " +
                "JOIN (SELECT TicketId, COUNT(*) Cnt FROM dbo.Purchases GROUP BY TicketId) x ON x.TicketId=p.TicketId " +
                "WHERE p.UserId=? ORDER BY p.PurchaseTime DESC, p.PurchaseId DESC";
        List<SaleRow> rows = new ArrayList<>();
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) rows.add(new SaleRow(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getBoolean(6)));
            }
        }
        return rows;
    }

    public List<SaleRow> listRecentSales() throws SQLException {
        String sql = "SELECT TOP (100) t.TicketCode, u.Username, CONCAT(N'Quầy ',p.CounterNo) AS CounterName, " +
                "CONVERT(VARCHAR(19),p.PurchaseTime,120) AS BoughtAt, p.SyncMode, " +
                "CASE WHEN x.Cnt > 1 THEN 1 ELSE 0 END AS IsDuplicate " +
                "FROM dbo.Purchases p JOIN dbo.Tickets t ON t.TicketId=p.TicketId " +
                "JOIN dbo.AppUsers u ON u.UserId=p.UserId " +
                "JOIN (SELECT TicketId, COUNT(*) Cnt FROM dbo.Purchases GROUP BY TicketId) x ON x.TicketId=p.TicketId " +
                "ORDER BY p.PurchaseTime DESC, p.PurchaseId DESC";
        List<SaleRow> rows = new ArrayList<>();
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) rows.add(new SaleRow(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getBoolean(6)));
        }
        return rows;
    }

    /** Đồng bộ hóa Java (monitor) kết hợp khóa dòng phía SQL Server. */
    public synchronized PurchaseResult buySynchronized(int userId, int counterNo) throws Exception {
        try (Connection c = Database.getConnection()) {
            c.setAutoCommit(false);
            c.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
            try {
                int ticketId;
                String code;
                String sql = "SELECT TOP (1) TicketId, TicketCode FROM dbo.Tickets WITH (UPDLOCK, READPAST, ROWLOCK) " +
                        "WHERE Status='AVAILABLE' ORDER BY TicketId";
                try (PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) throw new SQLException("Đã bán hết vé.");
                    ticketId = rs.getInt(1); code = rs.getString(2);
                }
                Thread.sleep(DEMO_DELAY_MS); // tạo độ trễ giống các quầy xử lý thực tế
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE dbo.Tickets SET Status='SOLD', SoldAt=SYSDATETIME() WHERE TicketId=? AND Status='AVAILABLE'")) {
                    ps.setInt(1, ticketId);
                    if (ps.executeUpdate() != 1) throw new SQLException("Vé vừa được quầy khác mua. Hãy thử lại.");
                }
                insertPurchase(c, userId, ticketId, counterNo, "SYNC");
                c.commit();
                return new PurchaseResult(code, counterNo, "SYNC", usernameOf(userId));
            } catch (Exception ex) {
                try { c.rollback(); } catch (SQLException ignored) {}
                throw ex;
            }
        }
    }

    /**
     * Không đồng bộ: SELECT vé rảnh, nhả khóa đọc, chờ một khoảng thời gian rồi UPDATE không kiểm tra trạng thái.
     * Nhiều luồng có thể cùng chọn một TicketId và cùng ghi một lượt bán cho vé đó.
     */
    public PurchaseResult buyUnsynchronized(int userId, int counterNo) throws Exception {
        try (Connection c = Database.getConnection()) {
            c.setAutoCommit(false);
            c.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
            try {
                int ticketId;
                String code;
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT TOP (1) TicketId, TicketCode FROM dbo.Tickets WHERE Status='AVAILABLE' ORDER BY TicketId");
                     ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) throw new SQLException("Không tìm thấy vé còn trống.");
                    ticketId = rs.getInt(1); code = rs.getString(2);
                }
                Thread.sleep(DEMO_DELAY_MS); // cố tình mở cửa sổ race condition
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE dbo.Tickets SET Status='SOLD', SoldAt=SYSDATETIME() WHERE TicketId=?")) {
                    ps.setInt(1, ticketId); // cố tình KHÔNG có điều kiện Status='AVAILABLE'
                    ps.executeUpdate();
                }
                insertPurchase(c, userId, ticketId, counterNo, "UNSYNC");
                c.commit();
                return new PurchaseResult(code, counterNo, "UNSYNC", usernameOf(userId));
            } catch (Exception ex) {
                try { c.rollback(); } catch (SQLException ignored) {}
                throw ex;
            }
        }
    }

    private void insertPurchase(Connection c, int userId, int ticketId, int counterNo, String mode) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT dbo.Purchases(UserId, TicketId, CounterNo, SyncMode) VALUES (?, ?, ?, ?)")) {
            ps.setInt(1, userId); ps.setInt(2, ticketId); ps.setInt(3, counterNo); ps.setString(4, mode);
            ps.executeUpdate();
        }
    }

    private String usernameOf(int userId) throws SQLException {
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement("SELECT Username FROM dbo.AppUsers WHERE UserId=?")) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getString(1) : "?"; }
        }
    }

    /** Chạy ba giao dịch đồng thời cho ba tài khoản demo tại ba quầy. */
    public List<PurchaseResult> simulateThreeCounters(boolean synchronizedMode) throws Exception {
        String[] usernames = {"khach1", "khach2", "khach3"};
        List<User> buyers = new ArrayList<>();
        for (String username : usernames) {
            User user = authService.findByUsername(username);
            if (user == null || !user.active()) throw new SQLException("Thiếu hoặc tài khoản demo bị khóa: " + username);
            buyers.add(user);
        }
        ExecutorService pool = Executors.newFixedThreadPool(3);
        try {
            List<Future<PurchaseResult>> futures = new ArrayList<>();
            for (int i = 0; i < 3; i++) {
                final int counter = i + 1;
                final User buyer = buyers.get(i);
                futures.add(pool.submit(() -> synchronizedMode
                        ? buySynchronized(buyer.id(), counter)
                        : buyUnsynchronized(buyer.id(), counter)));
            }
            List<PurchaseResult> result = new ArrayList<>();
            for (Future<PurchaseResult> f : futures) {
                try { result.add(f.get()); }
                catch (ExecutionException ex) {
                    Throwable cause = ex.getCause();
                    if (cause instanceof Exception e) throw e;
                    throw new RuntimeException(cause);
                }
            }
            return result;
        } finally {
            pool.shutdownNow();
        }
    }

    /** Chỉ dùng cho dữ liệu thực hành: xóa lịch sử và mở lại toàn bộ vé. */
    public void resetDemoData() throws SQLException {
        try (Connection c = Database.getConnection()) {
            c.setAutoCommit(false);
            try (Statement st = c.createStatement()) {
                st.executeUpdate("DELETE FROM dbo.Purchases");
                st.executeUpdate("UPDATE dbo.Tickets SET Status='AVAILABLE', SoldAt=NULL");
                c.commit();
            } catch (SQLException ex) {
                try { c.rollback(); } catch (SQLException ignored) {}
                throw ex;
            }
        }
    }
}
