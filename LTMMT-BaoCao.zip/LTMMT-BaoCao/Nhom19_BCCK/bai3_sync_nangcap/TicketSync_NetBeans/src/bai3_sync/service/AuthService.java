package bai3_sync.service;

import bai3_sync.dao.UserDao;
import bai3_sync.model.User;

import java.sql.SQLException;
import java.util.List;

public class AuthService {
    private final UserDao users = new UserDao();

    public User login(String username, char[] password) throws SQLException {
        if (username == null || username.isBlank() || password == null || password.length == 0)
            throw new SQLException("Vui lòng nhập tên đăng nhập và mật khẩu.");
        User user = users.authenticate(username, password);
        if (user == null) throw new SQLException("Tên đăng nhập hoặc mật khẩu không đúng.");
        return user;
    }

    public void register(String username, String fullName, char[] password, char[] confirm) throws SQLException {
        if (username == null || !username.trim().matches("[A-Za-z0-9_.-]{3,40}"))
            throw new SQLException("Tên đăng nhập gồm 3–40 ký tự: chữ, số, dấu chấm, gạch ngang hoặc gạch dưới.");
        if (fullName == null || fullName.trim().length() < 2) throw new SQLException("Vui lòng nhập họ tên hợp lệ.");
        if (password == null || password.length < 8) throw new SQLException("Mật khẩu phải có ít nhất 8 ký tự.");
        if (!java.util.Arrays.equals(password, confirm)) throw new SQLException("Mật khẩu xác nhận không khớp.");
        users.register(username, fullName, password);
    }

    public void updateProfile(int userId, String fullName) throws SQLException {
        if (fullName == null || fullName.trim().length() < 2) throw new SQLException("Họ tên cần ít nhất 2 ký tự.");
        users.updateFullName(userId, fullName);
    }

    public void changePassword(int userId, String currentPassword, char[] newPassword, char[] confirm) throws SQLException {
        if (currentPassword == null || currentPassword.isBlank()) throw new SQLException("Nhập mật khẩu hiện tại.");
        if (newPassword == null || newPassword.length < 8) throw new SQLException("Mật khẩu mới phải có ít nhất 8 ký tự.");
        if (!java.util.Arrays.equals(newPassword, confirm)) throw new SQLException("Mật khẩu xác nhận không khớp.");
        users.updatePassword(userId, currentPassword, newPassword);
    }

    public List<User> listUsers() throws SQLException { return users.listAll(); }
    public void setRole(int userId, String role) throws SQLException { users.updateRole(userId, role); }
    public void setActive(int userId, boolean active) throws SQLException { users.setActive(userId, active); }
    public User findByUsername(String username) throws SQLException { return users.findByUsername(username); }
}
