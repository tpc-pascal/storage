package bai3_sync.config;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public final class Database {
    private static final Properties PROPERTIES = loadProperties();
    private Database() {}

    private static Properties loadProperties() {
        Properties p = new Properties();
        Path file = Path.of("db.properties");
        if (Files.isRegularFile(file)) {
            try (InputStream in = Files.newInputStream(file)) { p.load(in); }
            catch (IOException e) { System.err.println("Không đọc được db.properties: " + e.getMessage()); }
        }
        return p;
    }

    private static String value(String key, String env, String fallback) {
        String v = System.getenv(env);
        if (v != null && !v.isBlank()) return v.trim();
        v = PROPERTIES.getProperty(key);
        return v == null || v.isBlank() ? fallback : v.trim();
    }

    public static Connection getConnection() throws SQLException {
        String url = value("db.url", "TICKET_DB_URL",
                "jdbc:sqlserver://localhost:1433;databaseName=TicketSyncDB;encrypt=true;trustServerCertificate=true");
        String user = value("db.user", "TICKET_DB_USER", "sa");
        String pass = value("db.password", "TICKET_DB_PASSWORD", "YourStrong!Passw0rd");
        return DriverManager.getConnection(url, user, pass);
    }

    public static void testConnection() throws SQLException {
        try (Connection ignored = getConnection()) { /* kết nối thành công */ }
    }
}
