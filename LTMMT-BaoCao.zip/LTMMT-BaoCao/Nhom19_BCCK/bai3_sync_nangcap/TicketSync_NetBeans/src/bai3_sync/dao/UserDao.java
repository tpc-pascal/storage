package bai3_sync.dao;

import bai3_sync.config.Database;
import bai3_sync.model.User;
import bai3_sync.util.PasswordUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
    private static User map(ResultSet rs) throws SQLException {
        return new User(rs.getInt("UserId"), rs.getString("Username"), rs.getString("FullName"),
                rs.getString("UserRole"), rs.getBoolean("IsActive"));
    }

    public User authenticate(String username, char[] password) throws SQLException {
        String sql = "SELECT UserId, Username, FullName, UserRole, IsActive, PasswordSalt, PasswordHash " +
                "FROM dbo.AppUsers WHERE Username = ?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                if (!rs.getBoolean("IsActive")) throw new SQLException("Tài khoản đang bị khóa. Vui lòng liên hệ quản trị viên.");
                if (!PasswordUtil.verify(password, rs.getString("PasswordSalt"), rs.getString("PasswordHash"))) return null;
                return map(rs);
            }
        }
    }

    public User findByUsername(String username) throws SQLException {
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(
                "SELECT UserId, Username, FullName, UserRole, IsActive FROM dbo.AppUsers WHERE Username=?")) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? map(rs) : null; }
        }
    }

    public List<User> listAll() throws SQLException {
        List<User> result = new ArrayList<>();
        String sql = "SELECT UserId, Username, FullName, UserRole, IsActive FROM dbo.AppUsers ORDER BY UserId";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) result.add(map(rs));
        }
        return result;
    }

    public void register(String username, String fullName, char[] password) throws SQLException {
        PasswordUtil.Credentials creds = PasswordUtil.hash(password);
        String sql = "INSERT dbo.AppUsers(Username, FullName, PasswordSalt, PasswordHash, UserRole, IsActive) " +
                "VALUES (?, ?, ?, ?, 'USER', 1)";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username.trim()); ps.setString(2, fullName.trim());
            ps.setString(3, creds.salt()); ps.setString(4, creds.hash());
            ps.executeUpdate();
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 2601 || ex.getErrorCode() == 2627 || "23000".equals(ex.getSQLState())) {
                throw new SQLException("Tên đăng nhập đã tồn tại.", ex);
            }
            throw ex;
        }
    }

    public void updateFullName(int userId, String fullName) throws SQLException {
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(
                "UPDATE dbo.AppUsers SET FullName=? WHERE UserId=?")) {
            ps.setString(1, fullName.trim()); ps.setInt(2, userId);
            if (ps.executeUpdate() != 1) throw new SQLException("Không tìm thấy tài khoản để cập nhật.");
        }
    }

    public void updatePassword(int userId, String currentPassword, char[] newPassword) throws SQLException {
        String select = "SELECT PasswordSalt, PasswordHash FROM dbo.AppUsers WHERE UserId=? AND IsActive=1";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(select)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next() || !PasswordUtil.verify(currentPassword.toCharArray(), rs.getString(1), rs.getString(2)))
                    throw new SQLException("Mật khẩu hiện tại không chính xác.");
            }
        }
        PasswordUtil.Credentials creds = PasswordUtil.hash(newPassword);
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(
                "UPDATE dbo.AppUsers SET PasswordSalt=?, PasswordHash=? WHERE UserId=?")) {
            ps.setString(1, creds.salt()); ps.setString(2, creds.hash()); ps.setInt(3, userId);
            ps.executeUpdate();
        }
    }

    public void updateRole(int userId, String role) throws SQLException {
        if (!"USER".equals(role) && !"ADMIN".equals(role)) throw new SQLException("Vai trò không hợp lệ.");
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(
                "UPDATE dbo.AppUsers SET UserRole=? WHERE UserId=?")) {
            ps.setString(1, role); ps.setInt(2, userId);
            if (ps.executeUpdate() != 1) throw new SQLException("Không tìm thấy tài khoản.");
        }
    }

    public void setActive(int userId, boolean active) throws SQLException {
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(
                "UPDATE dbo.AppUsers SET IsActive=? WHERE UserId=?")) {
            ps.setBoolean(1, active); ps.setInt(2, userId);
            if (ps.executeUpdate() != 1) throw new SQLException("Không tìm thấy tài khoản.");
        }
    }
}
