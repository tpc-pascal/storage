package bai3_sync;

import bai3_sync.ui.LoginFrame;
import bai3_sync.ui.UiStyle;

import javax.swing.SwingUtilities;

public class App {
    public static void main(String[] args) {
        UiStyle.install();
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
