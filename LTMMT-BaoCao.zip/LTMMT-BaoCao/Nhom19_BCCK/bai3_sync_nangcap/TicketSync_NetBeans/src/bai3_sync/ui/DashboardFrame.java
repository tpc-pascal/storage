package bai3_sync.ui;

import bai3_sync.model.User;
import bai3_sync.service.TicketService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class DashboardFrame extends JFrame {
    private User currentUser;
    private final TicketService ticketService = new TicketService();
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel pages = new JPanel(cardLayout);
    private final Map<String, JButton> navButtons = new LinkedHashMap<>();
    private final JLabel welcome = new JLabel();
    private OverviewPanel overviewPanel;
    private BuyTicketPanel buyPanel;
    private MyTicketsPanel myTicketsPanel;
    private AccountPanel accountPanel;
    private UserManagementPanel userManagementPanel;
    private String activePage = "overview";

    public DashboardFrame(User user) {
        this.currentUser = user;
        setTitle("TicketSync | Hệ thống bán vé");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(1340, 830);
        setMinimumSize(new Dimension(1120, 700));
        setLocationRelativeTo(null);
        buildUi();
    }

    private void buildUi() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UiStyle.BG);
        root.add(buildSidebar(), BorderLayout.WEST);
        JPanel right = new JPanel(new BorderLayout());
        right.setBackground(UiStyle.BG);
        right.add(buildTopBar(), BorderLayout.NORTH);
        pages.setOpaque(false);
        pages.setBorder(new EmptyBorder(4, 22, 22, 22));
        overviewPanel = new OverviewPanel(ticketService);
        buyPanel = new BuyTicketPanel(currentUser, ticketService, this::refreshAll);
        myTicketsPanel = new MyTicketsPanel(currentUser, ticketService);
        accountPanel = new AccountPanel(currentUser, this::onUserUpdated);
        pages.add(overviewPanel, "overview");
        pages.add(buyPanel, "buy");
        pages.add(myTicketsPanel, "tickets");
        pages.add(accountPanel, "account");
        if (currentUser.isAdmin()) {
            userManagementPanel = new UserManagementPanel(currentUser);
            pages.add(userManagementPanel, "users");
        }
        right.add(pages, BorderLayout.CENTER);
        root.add(right, BorderLayout.CENTER);
        setContentPane(root);
        showPage("overview");
    }

    private JPanel buildSidebar() {
        JPanel side = new JPanel(new BorderLayout());
        side.setBackground(UiStyle.NAVY);
        side.setPreferredSize(new Dimension(225, 0));

        JPanel top = new JPanel();
        top.setOpaque(false);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setBorder(new EmptyBorder(26, 18, 18, 18));

        JLabel brand = new JLabel("TicketSync");
        brand.setFont(new Font("Segoe UI", Font.BOLD, 24));
        brand.setForeground(Color.WHITE);

        JLabel tagline = new JLabel("BÁN VÉ • ĐỒNG BỘ • HIỆU QUẢ");
        tagline.setFont(new Font("Segoe UI", Font.BOLD, 10));
        tagline.setForeground(new Color(220, 232, 250));

        top.add(brand);
        top.add(Box.createVerticalStrut(8));
        top.add(tagline);
        top.add(Box.createVerticalStrut(28));

        JLabel section = new JLabel("KHÔNG GIAN LÀM VIỆC");
        section.setFont(new Font("Segoe UI", Font.BOLD, 11));
        section.setForeground(new Color(220, 232, 250));
        top.add(section);
        top.add(Box.createVerticalStrut(12));

        addNav(top, "overview", "•   Tổng quan");
        addNav(top, "buy", "•   Mua vé");
        addNav(top, "tickets", "•   Vé đã mua");
        addNav(top, "account", "•   Tài khoản");
        if (currentUser.isAdmin()) {
            addNav(top, "users", "•   Quản lý tài khoản");
        }

        top.add(Box.createVerticalGlue());

        JPanel bottom = new JPanel();
        bottom.setOpaque(false);
        bottom.setLayout(new BoxLayout(bottom, BoxLayout.Y_AXIS));
        bottom.setBorder(new EmptyBorder(15, 0, 0, 0));

        JLabel dot = new JLabel("●  Hệ thống bán vé");
        dot.setFont(UiStyle.FONT_BOLD);
        dot.setForeground(new Color(140, 240, 190));

        JLabel version = new JLabel("Bài 3 • Java Multithreading");
        version.setFont(new Font("Segoe UI", Font.BOLD, 11));
        version.setForeground(Color.WHITE);

        bottom.add(new JSeparator());
        bottom.add(Box.createVerticalStrut(14));
        bottom.add(dot);
        bottom.add(Box.createVerticalStrut(6));
        bottom.add(version);
        top.add(bottom);

        side.add(top, BorderLayout.CENTER);
        return side;
    }

    private void addNav(JPanel parent, String key, String text) {
        JButton b = new JButton(text);
        b.setUI(new BasicButtonUI());
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        // Nền nút sáng + Chữ ĐEN ĐẬM rõ ràng
        b.setForeground(UiStyle.TEXT);
        b.setBackground(Color.WHITE);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UiStyle.BORDER, 1),
                new EmptyBorder(11, 14, 11, 14)
        ));
        b.setOpaque(true);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(e -> showPage(key));
        navButtons.put(key, b);
        parent.add(b);
        parent.add(Box.createVerticalStrut(7));
    }

    private JPanel buildTopBar() {
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(Color.WHITE);
        top.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UiStyle.BORDER),
                new EmptyBorder(15, 24, 15, 22)
        ));

        JPanel userInfo = new JPanel();
        userInfo.setOpaque(false);
        userInfo.setLayout(new BoxLayout(userInfo, BoxLayout.Y_AXIS));

        welcome.setFont(new Font("Segoe UI", Font.BOLD, 16));
        welcome.setForeground(UiStyle.TEXT);

        JLabel role = new JLabel(currentUser.isAdmin() ? "QUẢN TRỊ VIÊN" : "TÀI KHOẢN NGƯỜI MUA");
        role.setFont(new Font("Segoe UI", Font.BOLD, 11));
        role.setForeground(UiStyle.TEXT);

        userInfo.add(welcome);
        userInfo.add(Box.createVerticalStrut(3));
        userInfo.add(role);
        updateWelcome();
        top.add(userInfo, BorderLayout.WEST);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);

        JLabel mode = new JLabel("●  Sẵn sàng");
        mode.setForeground(UiStyle.GREEN);
        mode.setFont(UiStyle.FONT_BOLD);
        right.add(mode);

        JButton logout = UiStyle.secondary("Đăng xuất");
        logout.addActionListener(e -> logout());
        right.add(logout);

        top.add(right, BorderLayout.EAST);
        return top;
    }

    private void showPage(String key) {
        if ("users".equals(key) && !currentUser.isAdmin()) return;
        activePage = key;
        cardLayout.show(pages, key);
        navButtons.forEach((k, b) -> {
            boolean selected = k.equals(key);
            // Khi chọn: nền xanh sáng nổi bật, viền xanh đậm, chữ ĐEN ĐẬM
            b.setBackground(selected ? new Color(187, 222, 251) : Color.WHITE);
            b.setForeground(UiStyle.TEXT);
            b.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(selected ? new Color(24, 91, 174) : UiStyle.BORDER, selected ? 2 : 1),
                    new EmptyBorder(10, 13, 10, 13)
            ));
        });
        if ("overview".equals(key)) overviewPanel.refreshData();
        if ("tickets".equals(key)) myTicketsPanel.refreshData();
        if ("users".equals(key) && userManagementPanel != null) userManagementPanel.refreshData();
    }

    private void refreshAll() {
        overviewPanel.refreshData();
        myTicketsPanel.refreshData();
        if (userManagementPanel != null) userManagementPanel.refreshData();
    }

    private void onUserUpdated(User updated) {
        currentUser = updated;
        updateWelcome();
        accountPanel.setUser(updated);
    }

    private void updateWelcome() {
        welcome.setText("Xin chào, " + currentUser.fullName());
    }

    private void logout() {
        int choice = JOptionPane.showConfirmDialog(this, "Bạn muốn đăng xuất khỏi TicketSync?", "Đăng xuất", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
}