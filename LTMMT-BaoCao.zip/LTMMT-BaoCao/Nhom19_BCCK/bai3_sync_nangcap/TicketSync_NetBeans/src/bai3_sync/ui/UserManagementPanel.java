package bai3_sync.ui;

import bai3_sync.model.User;
import bai3_sync.service.AuthService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserManagementPanel extends JPanel {
    private final User currentUser;
    private final AuthService auth = new AuthService();
    private final List<User> loadedUsers = new ArrayList<>();
    private final DefaultTableModel model = new DefaultTableModel(new Object[]{"ID", "Tên đăng nhập", "Họ và tên", "Vai trò", "Trạng thái"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JLabel status = UiStyle.muted("Dành cho quản trị viên");

    public UserManagementPanel(User currentUser) {
        this.currentUser = currentUser;
        setOpaque(false); setLayout(new BorderLayout(0, 14));
        JPanel top = new JPanel(new BorderLayout()); top.setOpaque(false);
        JPanel h = new JPanel(); h.setOpaque(false); h.setLayout(new BoxLayout(h, BoxLayout.Y_AXIS));
        h.add(UiStyle.title("Quản lý tài khoản")); h.add(Box.createVerticalStrut(5));
        h.add(UiStyle.muted("Xem tài khoản đã đăng ký, cấp quyền quản trị và khóa / mở khóa người dùng."));
        top.add(h, BorderLayout.WEST); JButton refresh = UiStyle.secondary("↻  Làm mới"); refresh.addActionListener(e -> refreshData()); top.add(refresh, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);
        JPanel card = UiStyle.card(); card.setLayout(new BorderLayout(0, 12));
        JPanel cardHead = new JPanel(new BorderLayout()); cardHead.setOpaque(false);
        JLabel title = new JLabel("Danh sách người dùng"); title.setFont(new Font("Segoe UI", Font.BOLD, 17)); title.setForeground(UiStyle.TEXT);
        cardHead.add(title, BorderLayout.WEST); cardHead.add(status, BorderLayout.EAST); card.add(cardHead, BorderLayout.NORTH);
        UiStyle.styleTable(table); card.add(new JScrollPane(table), BorderLayout.CENTER);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); actions.setOpaque(false);
        JButton user = UiStyle.secondary("Đặt vai trò USER"); user.addActionListener(e -> changeRole("USER"));
        JButton admin = UiStyle.button("Cấp quyền ADMIN", UiStyle.BLUE, Color.WHITE); admin.addActionListener(e -> changeRole("ADMIN"));
        JButton active = UiStyle.secondary("Khóa / Mở khóa"); active.addActionListener(e -> toggleActive());
        actions.add(user); actions.add(admin); actions.add(active); card.add(actions, BorderLayout.SOUTH);
        add(card, BorderLayout.CENTER); refreshData();
    }

    private User selectedUser() {
        int selected = table.getSelectedRow(); if (selected < 0) return null;
        int modelRow = table.convertRowIndexToModel(selected);
        int id = (int) model.getValueAt(modelRow, 0);
        return loadedUsers.stream().filter(u -> u.id() == id).findFirst().orElse(null);
    }

    private void changeRole(String role) {
        User target = selectedUser();
        if (target == null) { JOptionPane.showMessageDialog(this, "Hãy chọn một tài khoản trong bảng."); return; }
        if (target.id() == currentUser.id()) { JOptionPane.showMessageDialog(this, "Không thể tự đổi vai trò của tài khoản đang đăng nhập.", "Bị từ chối", JOptionPane.WARNING_MESSAGE); return; }
        try { auth.setRole(target.id(), role); status.setText("Đã cập nhật quyền cho " + target.username()); refreshData(); }
        catch (SQLException ex) { showError(ex); }
    }

    private void toggleActive() {
        User target = selectedUser();
        if (target == null) { JOptionPane.showMessageDialog(this, "Hãy chọn một tài khoản trong bảng."); return; }
        if (target.id() == currentUser.id()) { JOptionPane.showMessageDialog(this, "Không thể tự khóa tài khoản đang đăng nhập.", "Bị từ chối", JOptionPane.WARNING_MESSAGE); return; }
        String action = target.active() ? "khóa" : "mở khóa";
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn " + action + " tài khoản " + target.username() + "?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        try { auth.setActive(target.id(), !target.active()); refreshData(); }
        catch (SQLException ex) { showError(ex); }
    }

    public void refreshData() {
        status.setText("Đang tải danh sách...");
        new SwingWorker<List<User>, Void>() {
            @Override protected List<User> doInBackground() throws Exception { return auth.listUsers(); }
            @Override protected void done() {
                try {
                    List<User> rows = get(); loadedUsers.clear(); loadedUsers.addAll(rows); model.setRowCount(0);
                    for (User u : rows) model.addRow(new Object[]{u.id(), u.username(), u.fullName(), u.role(), u.active() ? "Đang hoạt động" : "Đã khóa"});
                    status.setText(rows.size() + " tài khoản");
                } catch (Exception ex) { showError(ex); }
            }
        }.execute();
    }

    private void showError(Exception ex) {
        Throwable c = ex.getCause(); JOptionPane.showMessageDialog(this, c == null ? ex.getMessage() : c.getMessage(), "Lỗi quản lý tài khoản", JOptionPane.ERROR_MESSAGE);
    }
}
