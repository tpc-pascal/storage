package bai3_sync.ui;

import bai3_sync.model.User;
import bai3_sync.service.TicketService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MyTicketsPanel extends JPanel {
    private final User user;
    private final TicketService service;
    private final DefaultTableModel model = new DefaultTableModel(new Object[]{"Mã vé", "Quầy mua", "Thời gian", "Chế độ", "Cảnh báo"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JLabel summary = UiStyle.muted("Đang tải...");

    public MyTicketsPanel(User user, TicketService service) {
        this.user = user; this.service = service;
        setOpaque(false); setLayout(new BorderLayout(0, 14));
        JPanel top = new JPanel(new BorderLayout()); top.setOpaque(false);
        JPanel h = new JPanel(); h.setOpaque(false); h.setLayout(new BoxLayout(h, BoxLayout.Y_AXIS));
        h.add(UiStyle.title("Vé đã mua của tôi")); h.add(Box.createVerticalStrut(5));
        h.add(UiStyle.muted("Lịch sử giao dịch gắn với tài khoản " + user.username() + "."));
        top.add(h, BorderLayout.WEST);
        JButton refresh = UiStyle.secondary("↻  Làm mới"); refresh.addActionListener(e -> refreshData()); top.add(refresh, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);
        JPanel card = UiStyle.card(); card.setLayout(new BorderLayout(0, 10));
        JPanel head = new JPanel(new BorderLayout()); head.setOpaque(false);
        JLabel label = new JLabel("Lịch sử mua vé"); label.setFont(new Font("Segoe UI", Font.BOLD, 17)); label.setForeground(UiStyle.TEXT);
        head.add(label, BorderLayout.WEST); head.add(summary, BorderLayout.EAST); card.add(head, BorderLayout.NORTH);
        UiStyle.styleTable(table); card.add(new JScrollPane(table), BorderLayout.CENTER); add(card, BorderLayout.CENTER);
        refreshData();
    }

    public void refreshData() {
        summary.setText("Đang cập nhật...");
        new SwingWorker<List<TicketService.SaleRow>, Void>() {
            @Override protected List<TicketService.SaleRow> doInBackground() throws Exception { return service.listMyPurchases(user.id()); }
            @Override protected void done() {
                try {
                    List<TicketService.SaleRow> rows = get(); model.setRowCount(0);
                    int dupes = 0;
                    for (TicketService.SaleRow r : rows) {
                        boolean dup = r.duplicate(); if (dup) dupes++;
                        model.addRow(new Object[]{r.ticketCode(), r.counter(), r.purchaseTime(),
                                "SYNC".equals(r.mode()) ? "Có đồng bộ" : "Không đồng bộ",
                                dup ? "⚠ Vé có lượt bán trùng" : "Hợp lệ"});
                    }
                    summary.setText(rows.size() + " giao dịch • " + dupes + " lượt có cảnh báo");
                } catch (Exception ex) {
                    summary.setText("Không tải được");
                    Throwable c = ex.getCause(); JOptionPane.showMessageDialog(MyTicketsPanel.this,
                            c == null ? ex.getMessage() : c.getMessage(), "Lỗi lịch sử", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }
}
