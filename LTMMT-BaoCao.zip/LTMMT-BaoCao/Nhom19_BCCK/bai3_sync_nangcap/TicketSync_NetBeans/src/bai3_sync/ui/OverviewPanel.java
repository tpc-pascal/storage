package bai3_sync.ui;

import bai3_sync.service.TicketService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class OverviewPanel extends JPanel {
    private final TicketService service;
    private final JLabel total = new JLabel("—"), sold = new JLabel("—"), available = new JLabel("—"), transactions = new JLabel("—"), duplicates = new JLabel("—");
    private final DefaultTableModel model = new DefaultTableModel(new Object[]{"Mã vé", "Trạng thái", "Lượt ghi nhận", "Quầy gần nhất", "Tài khoản mua", "Thời gian bán gần nhất"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JLabel status = UiStyle.muted("Đang tải dữ liệu...");

    public OverviewPanel(TicketService service) {
        this.service = service;
        setOpaque(false); setLayout(new BorderLayout(0, 14));
        JPanel top = new JPanel(new BorderLayout()); top.setOpaque(false);
        JPanel texts = new JPanel(); texts.setOpaque(false); texts.setLayout(new BoxLayout(texts, BoxLayout.Y_AXIS));
        texts.add(UiStyle.title("Tổng quan bán vé")); texts.add(Box.createVerticalStrut(5)); texts.add(UiStyle.muted("Thống kê vé đã bán, vé còn trống và các giao dịch được ghi nhận."));
        top.add(texts, BorderLayout.WEST);
        JButton refresh = UiStyle.secondary("↻  Làm mới"); refresh.addActionListener(e -> refreshData()); top.add(refresh, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);

        JPanel body = new JPanel(new BorderLayout(0, 14)); body.setOpaque(false);
        JPanel cards = new JPanel(new GridLayout(1, 5, 10, 0)); cards.setOpaque(false);
        cards.add(metricCard("Tổng số vé", total, UiStyle.BLUE, "Kho vé hiện có"));
        cards.add(metricCard("Vé đã bán", sold, UiStyle.TEAL, "Số vé duy nhất"));
        cards.add(metricCard("Vé còn lại", available, UiStyle.GREEN, "Có thể tiếp tục bán"));
        cards.add(metricCard("Lượt mua", transactions, UiStyle.PURPLE, "Số giao dịch ghi nhận"));
        cards.add(metricCard("Vé bán trùng", duplicates, UiStyle.RED, "Chỉ xuất hiện khi có lỗi"));
        body.add(cards, BorderLayout.NORTH);

        JPanel inventory = UiStyle.card(); inventory.setLayout(new BorderLayout(0, 10));
        JPanel invHead = new JPanel(new BorderLayout()); invHead.setOpaque(false);
        JLabel invTitle = new JLabel("Danh sách vé trong hệ thống"); invTitle.setFont(new Font("Segoe UI", Font.BOLD, 17)); invTitle.setForeground(UiStyle.TEXT);
        invHead.add(invTitle, BorderLayout.WEST); invHead.add(status, BorderLayout.EAST);
        inventory.add(invHead, BorderLayout.NORTH);
        UiStyle.styleTable(table); table.setFillsViewportHeight(true);
        inventory.add(new JScrollPane(table), BorderLayout.CENTER);
        body.add(inventory, BorderLayout.CENTER);
        add(body, BorderLayout.CENTER);
        refreshData();
    }

    private JPanel metricCard(String label, JLabel value, Color accent, String detail) {
        JPanel card = UiStyle.card(); card.setLayout(new BorderLayout(0, 9));
        JPanel labelRow = new JPanel(new BorderLayout()); labelRow.setOpaque(false);
        JLabel l = new JLabel(label); l.setFont(UiStyle.FONT_BOLD); l.setForeground(UiStyle.MUTED);
        JLabel dot = new JLabel("●"); dot.setForeground(accent); labelRow.add(l, BorderLayout.WEST); labelRow.add(dot, BorderLayout.EAST);
        value.setFont(new Font("Segoe UI", Font.BOLD, 28)); value.setForeground(UiStyle.TEXT);
        JLabel d = UiStyle.muted(detail); d.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        card.add(labelRow, BorderLayout.NORTH); card.add(value, BorderLayout.CENTER); card.add(d, BorderLayout.SOUTH);
        return card;
    }

    public void refreshData() {
        status.setText("Đang cập nhật...");
        new SwingWorker<Void, Void>() {
            private TicketService.Stats stats;
            private List<TicketService.InventoryRow> rows;
            @Override protected Void doInBackground() throws Exception { stats = service.getStats(); rows = service.listInventory(); return null; }
            @Override protected void done() {
                try {
                    get();
                    total.setText(String.valueOf(stats.totalTickets())); sold.setText(String.valueOf(stats.soldTickets()));
                    available.setText(String.valueOf(stats.availableTickets())); transactions.setText(String.valueOf(stats.saleTransactions()));
                    duplicates.setText(String.valueOf(stats.duplicateTickets()));
                    model.setRowCount(0);
                    for (TicketService.InventoryRow r : rows) {
                        String state = "AVAILABLE".equals(r.status()) ? "Còn vé" : "Đã bán";
                        String count = r.purchaseCount() > 1 ? r.purchaseCount() + "  ⚠" : String.valueOf(r.purchaseCount());
                        model.addRow(new Object[]{r.code(), state, count, r.lastCounter(), r.lastBuyer(), r.soldAt()});
                    }
                    status.setText(rows.size() + " vé");
                } catch (Exception ex) {
                    status.setText("Không tải được dữ liệu");
                    JOptionPane.showMessageDialog(OverviewPanel.this, rootMessage(ex), "Lỗi tải thống kê", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }

    private String rootMessage(Exception ex) { Throwable c = ex.getCause(); return c == null ? ex.getMessage() : c.getMessage(); }
}
