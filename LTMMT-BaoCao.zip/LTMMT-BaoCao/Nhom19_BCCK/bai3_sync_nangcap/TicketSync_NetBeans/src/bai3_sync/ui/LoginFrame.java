package bai3_sync.ui;

import bai3_sync.config.Database;
import bai3_sync.model.User;
import bai3_sync.service.AuthService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;

public class LoginFrame extends JFrame {
    private final JTextField usernameField = new JTextField("admin", 22);
    private final JPasswordField passwordField = new JPasswordField("Admin@123", 22);
    private final AuthService auth = new AuthService();
    private final JButton loginButton = UiStyle.primary("Đăng nhập  →");

    public LoginFrame() {
        setTitle("TicketSync | Đăng nhập");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(850, 540);
        setMinimumSize(new Dimension(780, 500));
        setLocationRelativeTo(null);
        buildUi();
    }

    private void buildUi() {
        JPanel root = new JPanel(new GridLayout(1, 2));
        root.setBackground(UiStyle.BG);
        JPanel brand = new JPanel();
        brand.setBackground(UiStyle.NAVY);
        brand.setBorder(new EmptyBorder(38, 35, 35, 35));
        brand.setLayout(new BoxLayout(brand, BoxLayout.Y_AXIS));
        JLabel logo = new JLabel("◆  TicketSync");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 29)); logo.setForeground(Color.WHITE);
        JLabel tagline = new JLabel("BÁN VÉ  •  ĐỒNG BỘ  •  HIỆU QUẢ");
        tagline.setFont(new Font("Segoe UI", Font.BOLD, 11)); tagline.setForeground(new Color(156, 190, 232));
        brand.add(logo); brand.add(Box.createVerticalStrut(15)); brand.add(tagline);
        brand.add(Box.createVerticalStrut(52));
        JLabel big = new JLabel("Kiểm soát bán vé");
        big.setFont(new Font("Segoe UI", Font.BOLD, 26)); big.setForeground(Color.WHITE);
        JLabel line1 = new JLabel("dễ dàng trên 3 quầy.");
        line1.setFont(new Font("Segoe UI", Font.BOLD, 24)); line1.setForeground(Color.WHITE);
        brand.add(big); brand.add(line1); brand.add(Box.createVerticalStrut(18));
        JTextArea description = new JTextArea("Theo dõi vé đã bán, vé còn lại và so sánh\nhành vi đa luồng khi có / không có synchronized.");
        description.setFont(new Font("Segoe UI", Font.PLAIN, 14)); description.setForeground(new Color(203, 216, 235));
        description.setOpaque(false); description.setEditable(false); description.setFocusable(false);
        brand.add(description); brand.add(Box.createVerticalGlue());
        JLabel bottom = new JLabel("BÀI 3  /  JAVA MULTITHREADING");
        bottom.setFont(new Font("Segoe UI", Font.BOLD, 11)); bottom.setForeground(new Color(130, 158, 197));
        brand.add(bottom);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UiStyle.BG);
        JPanel content = new JPanel(); content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(new EmptyBorder(28, 38, 28, 38));
        JLabel heading = new JLabel("Chào mừng trở lại"); heading.setFont(new Font("Segoe UI", Font.BOLD, 25)); heading.setForeground(UiStyle.TEXT);
        JLabel subtitle = UiStyle.muted("Đăng nhập để vào hệ thống bán vé");
        content.add(heading); content.add(Box.createVerticalStrut(7)); content.add(subtitle);
        content.add(Box.createVerticalStrut(28));
        content.add(label("Tên đăng nhập")); content.add(Box.createVerticalStrut(7)); prepareField(usernameField); content.add(usernameField);
        content.add(Box.createVerticalStrut(16));
        content.add(label("Mật khẩu")); content.add(Box.createVerticalStrut(7)); prepareField(passwordField); content.add(passwordField);
        content.add(Box.createVerticalStrut(22));
        loginButton.setAlignmentX(Component.LEFT_ALIGNMENT); loginButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        loginButton.addActionListener(e -> login()); content.add(loginButton);
        content.add(Box.createVerticalStrut(14));
        JButton register = UiStyle.secondary("Tạo tài khoản mới"); register.setAlignmentX(Component.LEFT_ALIGNMENT);
        register.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        register.addActionListener(e -> {
            setVisible(false);
            new RegisterFrame(() -> setVisible(true)).setVisible(true);
        });
        content.add(register); content.add(Box.createVerticalStrut(16));
        JLabel demo = new JLabel("Demo: admin / Admin@123"); demo.setForeground(UiStyle.MUTED); demo.setFont(new Font("Segoe UI", Font.PLAIN, 12)); content.add(demo);
        JLabel demo2 = new JLabel("khach1, khach2, khach3 / Khach@123"); demo2.setForeground(UiStyle.MUTED); demo2.setFont(new Font("Segoe UI", Font.PLAIN, 12)); content.add(demo2);
        form.add(content); root.add(brand); root.add(form); setContentPane(root);
        getRootPane().setDefaultButton(loginButton);
    }

    private JLabel label(String text) { JLabel l = new JLabel(text); l.setFont(UiStyle.FONT_BOLD); l.setForeground(UiStyle.TEXT); return l; }
    private void prepareField(JComponent field) {
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        field.setPreferredSize(new Dimension(290, 40));
        field.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(UiStyle.BORDER), new EmptyBorder(7, 10, 7, 10)));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    private void login() {
        loginButton.setEnabled(false);
        char[] password = passwordField.getPassword();
        try {
            User user = auth.login(usernameField.getText(), password);
            dispose();
            new DashboardFrame(user).setVisible(true);
        } catch (SQLException ex) {
            String message = ex.getMessage() == null ? "Không thể đăng nhập." : ex.getMessage();
            if (message.toLowerCase().contains("connect") || message.toLowerCase().contains("connection") || message.contains("SQL Server")) {
                message += "\n\nKiểm tra SQL Server, script sql/01_create_database.sql và file db.properties.";
            }
            JOptionPane.showMessageDialog(this, message, "Đăng nhập thất bại", JOptionPane.ERROR_MESSAGE);
        } finally {
            java.util.Arrays.fill(password, '\0');
            loginButton.setEnabled(true);
        }
    }
}
