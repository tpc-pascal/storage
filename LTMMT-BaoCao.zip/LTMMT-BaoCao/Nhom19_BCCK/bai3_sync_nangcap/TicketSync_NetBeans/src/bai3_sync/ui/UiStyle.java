package bai3_sync.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.JTableHeader;
import java.awt.*;

public final class UiStyle {

    // Màu chủ đạo
    public static final Color NAVY = new Color(18, 35, 66);
    public static final Color NAVY_LIGHT = new Color(30, 54, 91);
    public static final Color BLUE = new Color(24, 91, 174);
    public static final Color TEAL = new Color(0, 112, 110);
    public static final Color PURPLE = new Color(91, 67, 175);
    public static final Color GREEN = new Color(16, 95, 62);
    public static final Color RED = new Color(170, 39, 48);

    // Nền sáng, chữ ĐEN ĐẬM tuyệt đối để tương phản cao
    public static final Color BG = new Color(237, 242, 249);
    public static final Color WHITE = Color.WHITE;
    public static final Color TEXT = new Color(10, 15, 25);       // Đen đậm
    public static final Color MUTED = new Color(25, 32, 45);      // Đen đậm vừa (thay cho xám nhạt)
    public static final Color BORDER = new Color(160, 178, 204);

    // Màu nền nút sáng để đi kèm chữ ĐEN ĐẬM
    public static final Color LIGHT_BLUE = new Color(215, 230, 250);
    public static final Color LIGHT_HOVER = new Color(195, 216, 245);
    public static final Color TABLE_HEADER = new Color(210, 224, 244);

    public static final Font FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FONT_BOLD = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 25);

    private UiStyle() {}

    public static void install() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }

        UIManager.put("Label.font", FONT);
        UIManager.put("Label.foreground", TEXT);

        UIManager.put("Button.font", FONT_BOLD);
        UIManager.put("Button.foreground", TEXT);
        UIManager.put("Button.background", LIGHT_BLUE);

        UIManager.put("TextField.font", FONT);
        UIManager.put("TextField.foreground", TEXT);
        UIManager.put("TextField.background", WHITE);
        UIManager.put("TextField.caretForeground", TEXT);

        UIManager.put("PasswordField.font", FONT);
        UIManager.put("PasswordField.foreground", TEXT);
        UIManager.put("PasswordField.background", WHITE);
        UIManager.put("PasswordField.caretForeground", TEXT);

        UIManager.put("ComboBox.font", FONT_BOLD);
        UIManager.put("ComboBox.foreground", TEXT);
        UIManager.put("ComboBox.background", WHITE);

        UIManager.put("Table.font", FONT);
        UIManager.put("Table.foreground", TEXT);
        UIManager.put("Table.background", WHITE);
        UIManager.put("Table.selectionForeground", TEXT);
        UIManager.put("Table.selectionBackground", LIGHT_BLUE);
        UIManager.put("Table.rowHeight", 32);

        UIManager.put("TableHeader.font", FONT_BOLD);
        UIManager.put("TableHeader.foreground", TEXT);
        UIManager.put("TableHeader.background", TABLE_HEADER);

        UIManager.put("TabbedPane.font", FONT_BOLD);
        UIManager.put("TabbedPane.foreground", TEXT);

        UIManager.put("CheckBox.foreground", TEXT);
        UIManager.put("RadioButton.foreground", TEXT);
        UIManager.put("OptionPane.messageForeground", TEXT);
    }

    // Nút chuẩn: Dùng BasicButtonUI để Windows không tự ý biến nút thành màu trắng làm mất chữ
    public static JButton button(String text, Color background, Color foreground) {
        JButton b = new JButton(text);
        b.setUI(new BasicButtonUI());
        b.setFont(FONT_BOLD);
        b.setForeground(TEXT); // Luôn ưu tiên chữ Đen Đậm nếu nền sáng, hoặc dùng foreground được truyền
        if (isDarkColor(background)) {
            // Nếu bạn muốn mọi nút đều là chữ đen đậm trên nền sáng có viền màu:
            b.setBackground(new Color(230, 238, 250));
            b.setForeground(TEXT);
            b.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(background, 2),
                    new EmptyBorder(8, 14, 8, 14)
            ));
        } else {
            b.setBackground(background);
            b.setForeground(TEXT);
            b.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER, 1),
                    new EmptyBorder(9, 15, 9, 15)
            ));
        }
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.setBorderPainted(true);
        return b;
    }

    private static boolean isDarkColor(Color c) {
        double luminance = (0.299 * c.getRed() + 0.587 * c.getGreen() + 0.114 * c.getBlue()) / 255;
        return luminance < 0.6;
    }

    // Nút chính: nền xanh sáng, viền xanh đậm, chữ ĐEN ĐẬM
    public static JButton primary(String text) {
        return button(text, BLUE, TEXT);
    }

    // Nút phụ: nền xanh nhạt, chữ ĐEN ĐẬM
    public static JButton secondary(String text) {
        return button(text, LIGHT_BLUE, TEXT);
    }

    public static JPanel card() {
        JPanel p = new JPanel();
        p.setBackground(WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1),
                new EmptyBorder(18, 18, 18, 18)
        ));
        return p;
    }

    public static JLabel title(String text) {
        JLabel label = new JLabel(text);
        label.setFont(FONT_TITLE);
        label.setForeground(TEXT);
        return label;
    }

    public static JLabel muted(String text) {
        JLabel label = new JLabel(text);
        label.setFont(FONT);
        label.setForeground(MUTED);
        return label;
    }

    public static void styleTable(JTable table) {
        table.setFont(FONT);
        table.setForeground(TEXT);
        table.setBackground(WHITE);
        table.setRowHeight(32);
        table.setFillsViewportHeight(true);
        table.setShowVerticalLines(false);
        table.setGridColor(BORDER);
        table.setSelectionBackground(LIGHT_BLUE);
        table.setSelectionForeground(TEXT);
        table.setIntercellSpacing(new Dimension(0, 1));

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_BOLD);
        header.setBackground(TABLE_HEADER);
        header.setForeground(TEXT);
        header.setPreferredSize(new Dimension(0, 36));

        table.setAutoCreateRowSorter(true);
    }

    public static JPanel pageHeader(String heading, String subtitle) {
        JPanel p = new JPanel(new BorderLayout(8, 6));
        p.setOpaque(false);

        JLabel h = title(heading);
        JLabel s = muted(subtitle);

        JPanel stack = new JPanel();
        stack.setOpaque(false);
        stack.setLayout(new BoxLayout(stack, BoxLayout.Y_AXIS));

        stack.add(h);
        stack.add(Box.createVerticalStrut(5));
        stack.add(s);

        p.add(stack, BorderLayout.WEST);
        p.setBorder(new EmptyBorder(0, 0, 14, 0));

        return p;
    }
}