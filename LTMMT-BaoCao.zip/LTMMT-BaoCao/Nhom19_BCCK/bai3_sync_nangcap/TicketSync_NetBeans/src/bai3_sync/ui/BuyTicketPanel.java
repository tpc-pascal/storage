package bai3_sync.ui;

import bai3_sync.model.User;
import bai3_sync.service.TicketService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.util.List;

public class BuyTicketPanel extends JPanel {

    private final User user;
    private final TicketService service;
    private final Runnable onDataChanged;

    private final JComboBox<String> mode = new JComboBox<>(
            new String[]{
                "Có đồng bộ hóa — synchronized",
                "Không đồng bộ — race condition demo"
            }
    );

    private final JLabel result = new JLabel(
            "Chọn chế độ, sau đó chọn quầy cần mua vé."
    );

    private final JButton[] counterButtons = new JButton[3];

    private final JButton simulate = new JButton("Mô phỏng 3 quầy mua đồng thời");
    private final JButton reset = new JButton("Đặt lại dữ liệu thực hành");

    // Chữ ĐEN ĐẬM toàn bộ để độ tương phản tối đa
    private static final Color DARK_TEXT = new Color(10, 15, 25);
    private static final Color MUTED_TEXT = new Color(20, 28, 40);
    private static final Color PAGE_BG = new Color(237, 242, 249);
    private static final Color CARD_BG = Color.WHITE;
    private static final Color CARD_BORDER = new Color(160, 178, 204);

    // Màu viền đậm + Màu nền sáng cho từng quầy để chữ ĐEN ĐẬM nổi bật
    private static final Color[] COUNTER_ACCENTS = {
        new Color(0, 112, 110),   // Quầy 1 - xanh teal đậm
        new Color(24, 91, 174),   // Quầy 2 - xanh dương đậm
        new Color(91, 67, 175)    // Quầy 3 - tím đậm
    };

    private static final Color[] COUNTER_LIGHT_BG = {
        new Color(215, 242, 240), // Nền sáng Quầy 1
        new Color(216, 232, 252), // Nền sáng Quầy 2
        new Color(230, 224, 250)  // Nền sáng Quầy 3
    };

    public BuyTicketPanel(
            User user,
            TicketService service,
            Runnable onDataChanged) {

        this.user = user;
        this.service = service;
        this.onDataChanged = onDataChanged;

        setOpaque(true);
        setBackground(PAGE_BG);
        setLayout(new BorderLayout(0, 14));
        setBorder(new EmptyBorder(8, 8, 8, 8));

        // ===== TIÊU ĐỀ =====
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);

        JPanel heading = new JPanel();
        heading.setOpaque(false);
        heading.setLayout(new BoxLayout(heading, BoxLayout.Y_AXIS));

        heading.add(UiStyle.title("Mua vé tại quầy"));
        heading.add(Box.createVerticalStrut(5));

        JLabel greeting = new JLabel(
                "Xin chào " + user.fullName()
                + ". Chọn quầy và phương thức đồng bộ hóa."
        );
        greeting.setFont(UiStyle.FONT);
        greeting.setForeground(MUTED_TEXT);
        heading.add(greeting);

        top.add(heading, BorderLayout.WEST);
        add(top, BorderLayout.NORTH);

        // ===== KHU VỰC NỘI DUNG =====
        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        // ===== 01. CHẾ ĐỘ XỬ LÝ =====
        JPanel modeCard = createCard();
        modeCard.setLayout(new BorderLayout(12, 12));

        JLabel modeTitle = createSectionTitle("01   CHỌN CHẾ ĐỘ XỬ LÝ");
        modeCard.add(modeTitle, BorderLayout.NORTH);

        mode.setFont(UiStyle.FONT_BOLD);
        mode.setForeground(DARK_TEXT);
        mode.setBackground(Color.WHITE);
        mode.setPreferredSize(new Dimension(380, 42));
        mode.setFocusable(true);

        modeCard.add(mode, BorderLayout.CENTER);

        JTextArea note = new JTextArea(
                "Có đồng bộ: các yêu cầu tại cùng ứng dụng được tuần tự hóa, "
                + "vé được khóa và cập nhật có kiểm tra.\n"
                + "Không đồng bộ: cố tình tạo độ trễ và bỏ kiểm tra trạng thái "
                + "khi cập nhật để làm lộ lỗi bán trùng."
        );

        note.setEditable(false);
        note.setFocusable(false);
        note.setOpaque(false);
        note.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        note.setForeground(MUTED_TEXT);
        note.setLineWrap(true);
        note.setWrapStyleWord(true);

        modeCard.add(note, BorderLayout.SOUTH);

        content.add(modeCard);
        content.add(Box.createVerticalStrut(16));

        // ===== 02. CHỌN QUẦY =====
        JLabel counterTitle = createSectionTitle("02   CHỌN QUẦY BÁN VÉ");

        JPanel counterHeader = new JPanel(new BorderLayout());
        counterHeader.setOpaque(false);
        counterHeader.add(counterTitle, BorderLayout.WEST);

        content.add(counterHeader);
        content.add(Box.createVerticalStrut(10));

        JPanel counters = new JPanel(new GridLayout(1, 3, 14, 0));
        counters.setOpaque(false);

        for (int i = 0; i < 3; i++) {
            final int counter = i + 1;
            final Color accentColor = COUNTER_ACCENTS[i];
            final Color bgColor = COUNTER_LIGHT_BG[i];

            JPanel card = createCard();
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

            JLabel icon = new JLabel("QUẦY 0" + counter);
            icon.setFont(new Font("Segoe UI", Font.BOLD, 13));
            icon.setForeground(accentColor);
            icon.setAlignmentX(Component.LEFT_ALIGNMENT);

            JLabel title = new JLabel("Quầy " + counter);
            title.setFont(new Font("Segoe UI", Font.BOLD, 20));
            title.setForeground(DARK_TEXT);
            title.setAlignmentX(Component.LEFT_ALIGNMENT);

            JLabel subtitle = new JLabel("Sẵn sàng phục vụ");
            subtitle.setFont(UiStyle.FONT);
            subtitle.setForeground(MUTED_TEXT);
            subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

            JButton buy = new JButton("Mua vé tại quầy " + counter + "  →");
            styleActionButton(buy, bgColor, accentColor, DARK_TEXT);
            buy.setAlignmentX(Component.LEFT_ALIGNMENT);
            buy.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
            buy.setPreferredSize(new Dimension(260, 44));

            buy.addActionListener(e -> buy(counter));
            counterButtons[i] = buy;

            card.add(icon);
            card.add(Box.createVerticalStrut(8));
            card.add(title);
            card.add(Box.createVerticalStrut(5));
            card.add(subtitle);
            card.add(Box.createVerticalGlue());
            card.add(Box.createVerticalStrut(16));
            card.add(buy);

            counters.add(card);
        }

        content.add(counters);
        content.add(Box.createVerticalStrut(16));

        // ===== KHU VỰC THAO TÁC VÀ KẾT QUẢ =====
        JPanel actionCard = createCard();
        actionCard.setLayout(new BorderLayout(10, 14));

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        actions.setOpaque(false);

        styleActionButton(
                simulate,
                new Color(216, 232, 252),
                new Color(24, 91, 174),
                DARK_TEXT
        );

        styleActionButton(
                reset,
                new Color(252, 222, 225),
                new Color(170, 39, 48),
                DARK_TEXT
        );

        simulate.addActionListener(e -> simulate());
        actions.add(simulate);

        if (user.isAdmin()) {
            reset.addActionListener(e -> resetDemo());
            actions.add(reset);
        }

        actionCard.add(actions, BorderLayout.NORTH);

        result.setForeground(DARK_TEXT);
        result.setFont(UiStyle.FONT_BOLD);
        result.setOpaque(false);
        actionCard.add(result, BorderLayout.CENTER);

        content.add(actionCard);
        add(content, BorderLayout.CENTER);
    }

    private JPanel createCard() {
        JPanel panel = new JPanel();
        panel.setBackground(CARD_BG);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(CARD_BORDER, 1),
                new EmptyBorder(18, 18, 18, 18)
        ));
        return panel;
    }

    private JLabel createSectionTitle(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 15));
        label.setForeground(DARK_TEXT);
        return label;
    }

    private void styleActionButton(
            JButton button,
            Color background,
            Color borderColor,
            Color foreground) {

        button.setUI(new BasicButtonUI());
        button.setBackground(background);
        button.setForeground(foreground); // Chữ ĐEN ĐẬM
        button.setFont(UiStyle.FONT_BOLD);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(true);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor, 2),
                new EmptyBorder(9, 16, 9, 16)
        ));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private boolean syncMode() {
        return mode.getSelectedIndex() == 0;
    }

    private void setBusy(boolean busy) {
        for (JButton button : counterButtons) {
            button.setEnabled(!busy);
        }
        simulate.setEnabled(!busy);
        mode.setEnabled(!busy);
        if (user.isAdmin()) {
            reset.setEnabled(!busy);
        }
    }

    private void buy(int counter) {
        boolean sync = syncMode();
        setBusy(true);
        result.setText("Đang xử lý giao dịch tại Quầy " + counter + "...");

        new SwingWorker<TicketService.PurchaseResult, Void>() {
            @Override
            protected TicketService.PurchaseResult doInBackground() throws Exception {
                return sync
                        ? service.buySynchronized(user.id(), counter)
                        : service.buyUnsynchronized(user.id(), counter);
            }

            @Override
            protected void done() {
                try {
                    TicketService.PurchaseResult purchase = get();
                    result.setText(
                            "Đã ghi nhận vé " + purchase.ticketCode()
                            + " tại Quầy " + purchase.counterNo()
                            + " (" + modeName(purchase.mode()) + ")."
                    );

                    JOptionPane.showMessageDialog(
                            BuyTicketPanel.this,
                            "Mua vé thành công!\n"
                            + "Mã vé: " + purchase.ticketCode() + "\n"
                            + "Quầy: " + purchase.counterNo() + "\n"
                            + "Chế độ: " + modeName(purchase.mode()),
                            "Giao dịch thành công",
                            JOptionPane.INFORMATION_MESSAGE
                    );

                    onDataChanged.run();
                } catch (Exception ex) {
                    showError(ex);
                } finally {
                    setBusy(false);
                }
            }
        }.execute();
    }

    private void simulate() {
        boolean sync = syncMode();
        setBusy(true);
        result.setText("Đang chạy 3 luồng tại Quầy 1, 2, 3 với ba tài khoản demo...");

        new SwingWorker<List<TicketService.PurchaseResult>, Void>() {
            @Override
            protected List<TicketService.PurchaseResult> doInBackground() throws Exception {
                return service.simulateThreeCounters(sync);
            }

            @Override
            protected void done() {
                try {
                    List<TicketService.PurchaseResult> rows = get();
                    StringBuilder message = new StringBuilder("KẾT QUẢ MÔ PHỎNG 3 QUẦY\n\n");

                    for (TicketService.PurchaseResult purchase : rows) {
                        message.append("Quầy ")
                                .append(purchase.counterNo())
                                .append(" — ")
                                .append(purchase.buyer())
                                .append(" — vé ")
                                .append(purchase.ticketCode())
                                .append("\n");
                    }

                    TicketService.Stats stats = service.getStats();
                    message.append("\nVé duy nhất đã bán: ")
                            .append(stats.soldTickets())
                            .append(" / ")
                            .append(stats.totalTickets())
                            .append("\nLượt mua ghi nhận: ")
                            .append(stats.saleTransactions())
                            .append("\nMã vé bị bán trùng: ")
                            .append(stats.duplicateTickets());

                    result.setText(
                            sync
                            ? "Đã chạy xong ba quầy ở chế độ đồng bộ."
                            : "Đã chạy xong ba quầy ở chế độ không đồng bộ — kiểm tra vé trùng."
                    );

                    JOptionPane.showMessageDialog(
                            BuyTicketPanel.this,
                            message.toString(),
                            "Kết quả mô phỏng",
                            JOptionPane.INFORMATION_MESSAGE
                    );

                    onDataChanged.run();
                } catch (Exception ex) {
                    showError(ex);
                } finally {
                    setBusy(false);
                }
            }
        }.execute();
    }

    private void resetDemo() {
        int answer = JOptionPane.showConfirmDialog(
                this,
                "Thao tác sẽ xóa toàn bộ lịch sử mua vé và mở lại tất cả vé. "
                + "Chỉ dùng để làm lại bài thực hành.\n"
                + "Bạn có muốn tiếp tục?",
                "Đặt lại dữ liệu demo",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (answer != JOptionPane.YES_OPTION) {
            return;
        }

        setBusy(true);

        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                service.resetDemoData();
                return null;
            }

            @Override
            protected void done() {
                try {
                    get();
                    result.setText("Đã đặt lại vé và lịch sử giao dịch.");
                    onDataChanged.run();
                } catch (Exception ex) {
                    showError(ex);
                } finally {
                    setBusy(false);
                }
            }
        }.execute();
    }

    private String modeName(String mode) {
        return "SYNC".equals(mode) ? "Có đồng bộ" : "Không đồng bộ";
    }

    private void showError(Exception ex) {
        Throwable cause = ex.getCause();
        while (cause != null && cause.getCause() != null) {
            cause = cause.getCause();
        }
        String message = cause == null ? ex.getMessage() : cause.getMessage();
        if (message == null) {
            message = "Có lỗi khi xử lý giao dịch.";
        }
        result.setText("Giao dịch chưa hoàn tất: " + message);
        JOptionPane.showMessageDialog(
                this,
                message,
                "Không thể hoàn tất",
                JOptionPane.WARNING_MESSAGE
        );
    }
}