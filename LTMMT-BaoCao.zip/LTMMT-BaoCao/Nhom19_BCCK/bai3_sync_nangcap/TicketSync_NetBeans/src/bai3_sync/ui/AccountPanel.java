package bai3_sync.ui;

import bai3_sync.model.User;
import bai3_sync.service.AuthService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;
import java.util.function.Consumer;

public class AccountPanel extends JPanel {
    private User user;
    private final AuthService auth = new AuthService();
    private final Consumer<User> onUserUpdated;
    private final JTextField fullName = new JTextField();
    private final JLabel username = new JLabel(), role = new JLabel();
    private final JPasswordField currentPassword = new JPasswordField();
    private final JPasswordField newPassword = new JPasswordField();
    private final JPasswordField confirmPassword = new JPasswordField();

    public AccountPanel(User user, Consumer<User> onUserUpdated) {
        this.user = user; this.onUserUpdated = onUserUpdated;
        setOpaque(false); setLayout(new BorderLayout(0, 14));
        JPanel header = new JPanel(); header.setOpaque(false); header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.add(UiStyle.title("Tài khoản của tôi")); header.add(Box.createVerticalStrut(5)); header.add(UiStyle.muted("Cập nhật thông tin cá nhân và thay đổi mật khẩu."));
        add(header, BorderLayout.NORTH);

        JPanel body = new JPanel(new GridLayout(1, 2, 14, 0)); body.setOpaque(false);
        JPanel profile = UiStyle.card(); profile.setLayout(new BoxLayout(profile, BoxLayout.Y_AXIS));
        JLabel pTitle = sectionTitle("Thông tin hồ sơ"); profile.add(pTitle); profile.add(Box.createVerticalStrut(18));
        username.setForeground(UiStyle.MUTED); username.setFont(UiStyle.FONT_BOLD); addLabel(profile, "Tên đăng nhập"); profile.add(username); profile.add(Box.createVerticalStrut(16));
        addLabel(profile, "Vai trò"); role.setFont(UiStyle.FONT_BOLD); role.setForeground(UiStyle.BLUE); profile.add(role); profile.add(Box.createVerticalStrut(16));
        addLabel(profile, "Họ và tên hiển thị"); prepare(fullName); profile.add(fullName); profile.add(Box.createVerticalStrut(18));
        JButton save = UiStyle.primary("Lưu thông tin"); save.setAlignmentX(Component.LEFT_ALIGNMENT); save.addActionListener(e -> saveProfile()); profile.add(save);

        JPanel password = UiStyle.card(); password.setLayout(new BoxLayout(password, BoxLayout.Y_AXIS));
        password.add(sectionTitle("Bảo mật tài khoản")); password.add(Box.createVerticalStrut(18));
        addLabel(password, "Mật khẩu hiện tại"); prepare(currentPassword); password.add(currentPassword); password.add(Box.createVerticalStrut(12));
        addLabel(password, "Mật khẩu mới (ít nhất 8 ký tự)"); prepare(newPassword); password.add(newPassword); password.add(Box.createVerticalStrut(12));
        addLabel(password, "Xác nhận mật khẩu mới"); prepare(confirmPassword); password.add(confirmPassword); password.add(Box.createVerticalStrut(18));
        JButton change = UiStyle.button("Đổi mật khẩu", UiStyle.NAVY, Color.WHITE); change.setAlignmentX(Component.LEFT_ALIGNMENT); change.addActionListener(e -> changePassword()); password.add(change);
        body.add(profile); body.add(password); add(body, BorderLayout.CENTER); setUser(user);
    }

    private JLabel sectionTitle(String text) { JLabel l = new JLabel(text); l.setFont(new Font("Segoe UI", Font.BOLD, 18)); l.setForeground(UiStyle.TEXT); return l; }
    private void addLabel(JPanel parent, String text) {
        JLabel l = new JLabel(text); l.setForeground(UiStyle.MUTED); l.setFont(new Font("Segoe UI", Font.BOLD, 12)); l.setAlignmentX(Component.LEFT_ALIGNMENT);
        parent.add(l); parent.add(Box.createVerticalStrut(6));
    }
    private void prepare(JComponent c) {
        c.setPreferredSize(new Dimension(220, 37)); c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 37)); c.setAlignmentX(Component.LEFT_ALIGNMENT);
        c.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(UiStyle.BORDER), new EmptyBorder(7, 9, 7, 9)));
    }
    public void setUser(User user) {
        this.user = user; username.setText(user.username()); role.setText(user.isAdmin() ? "QUẢN TRỊ VIÊN" : "NGƯỜI MUA VÉ"); fullName.setText(user.fullName());
    }
    private void saveProfile() {
        try {
            auth.updateProfile(user.id(), fullName.getText());
            User updated = new User(user.id(), user.username(), fullName.getText().trim(), user.role(), user.active());
            setUser(updated); onUserUpdated.accept(updated);
            JOptionPane.showMessageDialog(this, "Đã cập nhật thông tin tài khoản.", "Thành công", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) { JOptionPane.showMessageDialog(this, ex.getMessage(), "Không thể lưu", JOptionPane.WARNING_MESSAGE); }
    }
    private void changePassword() {
        char[] current = currentPassword.getPassword(), next = newPassword.getPassword(), confirm = confirmPassword.getPassword();
        try {
            auth.changePassword(user.id(), new String(current), next, confirm);
            currentPassword.setText(""); newPassword.setText(""); confirmPassword.setText("");
            JOptionPane.showMessageDialog(this, "Đã đổi mật khẩu. Hãy ghi nhớ mật khẩu mới.", "Thành công", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) { JOptionPane.showMessageDialog(this, ex.getMessage(), "Không thể đổi mật khẩu", JOptionPane.WARNING_MESSAGE); }
        finally { java.util.Arrays.fill(current, '\0'); java.util.Arrays.fill(next, '\0'); java.util.Arrays.fill(confirm, '\0'); }
    }
}
