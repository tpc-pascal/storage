package bai3_sync.ui;

import bai3_sync.service.AuthService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;

public class RegisterFrame extends JFrame {
    private final JTextField fullName = new JTextField();
    private final JTextField username = new JTextField();
    private final JPasswordField password = new JPasswordField();
    private final JPasswordField confirm = new JPasswordField();
    private final AuthService auth = new AuthService();
    private final Runnable onClose;

    public RegisterFrame(Runnable onClose) {
        this.onClose = onClose;
        setTitle("TicketSync | Đăng ký tài khoản");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(510, 590); setMinimumSize(new Dimension(470, 560)); setLocationRelativeTo(null);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosed(java.awt.event.WindowEvent e) { if (RegisterFrame.this.onClose != null) RegisterFrame.this.onClose.run(); }
        });
        buildUi();
    }

    private void buildUi() {
        JPanel root = new JPanel(new BorderLayout()); root.setBackground(UiStyle.BG); root.setBorder(new EmptyBorder(26, 34, 26, 34));
        JLabel heading = UiStyle.title("Tạo tài khoản");
        JLabel subtitle = UiStyle.muted("Tài khoản mới mặc định có quyền người mua vé.");
        JPanel header = new JPanel(); header.setOpaque(false); header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.add(heading); header.add(Box.createVerticalStrut(7)); header.add(subtitle); root.add(header, BorderLayout.NORTH);
        JPanel fields = new JPanel(new GridLayout(4, 1, 0, 9)); fields.setOpaque(false); fields.setBorder(new EmptyBorder(24, 0, 20, 0));
        addField(fields, "Họ và tên", fullName); addField(fields, "Tên đăng nhập (3–40 ký tự)", username);
        addField(fields, "Mật khẩu (ít nhất 8 ký tự)", password); addField(fields, "Nhập lại mật khẩu", confirm);
        root.add(fields, BorderLayout.CENTER);
        JPanel buttons = new JPanel(new GridLayout(1, 2, 12, 0)); buttons.setOpaque(false);
        JButton back = UiStyle.secondary("Quay lại"); back.addActionListener(e -> dispose());
        JButton submit = UiStyle.primary("Đăng ký tài khoản"); submit.addActionListener(e -> register());
        buttons.add(back); buttons.add(submit); root.add(buttons, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private void addField(JPanel parent, String label, JComponent field) {
        JPanel p = new JPanel(new BorderLayout(0, 5)); p.setOpaque(false);
        JLabel l = new JLabel(label); l.setFont(UiStyle.FONT_BOLD); l.setForeground(UiStyle.TEXT);
        field.setPreferredSize(new Dimension(100, 36));
        field.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(UiStyle.BORDER), new EmptyBorder(7, 9, 7, 9)));
        p.add(l, BorderLayout.NORTH); p.add(field, BorderLayout.CENTER); parent.add(p);
    }

    private void register() {
        char[] pw = password.getPassword(), cf = confirm.getPassword();
        try {
            auth.register(username.getText(), fullName.getText(), pw, cf);
            JOptionPane.showMessageDialog(this, "Đăng ký thành công! Bây giờ hãy đăng nhập.", "Thành công", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Không thể đăng ký", JOptionPane.WARNING_MESSAGE);
        } finally {
            java.util.Arrays.fill(pw, '\0'); java.util.Arrays.fill(cf, '\0');
        }
    }
}
