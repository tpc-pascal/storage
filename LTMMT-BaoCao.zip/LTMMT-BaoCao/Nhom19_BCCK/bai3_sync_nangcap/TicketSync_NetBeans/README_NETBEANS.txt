TICKETSYNC - BAI 3 SYNCHRONIZATION - NETBEANS JAVA SWING + SQL SERVER
====================================================================

PROJECT JAVA/ANT DOC LAP.
Tat ca form duoc tao bang Java Swing trong code, khong can mo cac file .form.

1. TAO DATABASE
----------------
- Mo SQL Server Management Studio (SSMS), ket noi Database Engine.
- Mo file sql/01_create_database.sql.
- Bam Execute de tao database TicketSyncDB, 4 tai khoan demo va 30 ve.
- LUU Y: Script co DROP TABLE de tao lai du lieu mau. Chay lai se XOA lich su mua ve va tai khoan dang ky them.

2. CAU HINH KET NOI DATABASE
----------------------------
- Copy file db.properties.example, doi ten thanh db.properties (nam o thu muc goc TicketSync_NetBeans).
- Mo db.properties va sua user/password SQL Server cho dung may cua ban.
- JDBC driver da duoc dat trong thu muc lib cua project.
- Mac dinh dang dung:
  db.url=jdbc:sqlserver://localhost:1433;databaseName=TicketSyncDB;encrypt=true;trustServerCertificate=true
  db.user=sa
  db.password=MAT_KHAU_SQL_SERVER_CUA_BAN
- Neu SQL Server cua ban khong nghe o localhost:1433, hay sua URL theo Server name/port dang dung trong SSMS.
- SQL Server can duoc bat dich vu Database Engine va TCP/IP neu ket noi bang TCP/IP.

3. MO VA CHAY TRONG NETBEANS
------------------------------
- Trong NetBeans, chon File > Open Project va mo rieng thu muc bai3_sync_nangcap/TicketSync_NetBeans.
- Bam Run Project (F6) de chay bai 3.

4. CHAY CHUONG TRINH
--------------------
- Chay module bai3_sync_nangcap bang Run Project (F6).
- Dang nhap bang tai khoan mau o muc 5.
- Neu loi driver/ket noi: kiem tra SQL Server, db.properties va file JDBC trong thu muc lib.

5. TAI KHOAN MAU
----------------
ADMIN: admin / Admin@123
Khach 1: khach1 / Khach@123
Khach 2: khach2 / Khach@123
Khach 3: khach3 / Khach@123
Nguoi dung co the tu dang ky tai khoan moi tren form dang nhap.

6. CAC FORM / CLASS CHINH
-------------------------
bai3_sync.App                         Diem chay chuong trinh
bai3_sync.config.Database             Mo ket noi JDBC SQL Server
bai3_sync.dao.UserDao                 CRUD/kiem tra tai khoan bang PreparedStatement
bai3_sync.model.User                  Model tai khoan
bai3_sync.service.AuthService         Dang nhap/dang ky/doi mat khau/phan quyen
bai3_sync.service.TicketService       Ban ve, thong ke, lich su, mo phong 3 luong
bai3_sync.util.PasswordUtil           Bam mat khau PBKDF2-HMAC-SHA256
bai3_sync.ui.LoginFrame               Form dang nhap
bai3_sync.ui.RegisterFrame            Form dang ky
bai3_sync.ui.DashboardFrame           Khung giao dien chinh va menu
bai3_sync.ui.OverviewPanel             Tong so ve/da ban/con lai/ve trung va danh sach ve
bai3_sync.ui.BuyTicketPanel            Chon che do + Quay 1/2/3 + mo phong 3 luong
bai3_sync.ui.MyTicketsPanel            Lich su ve cua tai khoan dang dang nhap
bai3_sync.ui.AccountPanel              Ho so va doi mat khau
bai3_sync.ui.UserManagementPanel       Quan ly tai khoan (chi ADMIN)
bai3_sync.ui.UiStyle                   Mau sac/thanh phan giao dien dung chung

7. CACH TRINH DIEN BAI 3
-----------------------
A. Dang nhap admin -> Mua ve -> chon "Co dong bo hoa" -> bam "Mo phong 3 quay mua dong thoi".
B. Ghi lai tong so ve duy nhat da ban, so giao dich va so ma ve bi trung.
C. Bam "Dat lai du lieu thuc hanh" (chi ADMIN) de mo lai ve va xoa lich su giao dich.
D. Chon "Khong dong bo" -> chay mo phong 3 quay lai. Vi phan UNSYNC co chu y tao khoang tre va khong kiem tra lai trang thai ve trong UPDATE, cac luong co the ghi nhan ban trung. Race condition phu thuoc lich dieu phoi thread nen khong dam bao lan nao cung xuat hien.
E. Vao Tong quan xem thong ke; vao Ve da mua de xem lich su cua tai khoan.

8. LUU Y VE KET QUA THUC HANH
-----------------------------
- SYNC: khoa synchronized o Java va khoa dong du lieu SQL Server ngan viec cac giao dich trong demo lay cung mot ve.
- UNSYNC: chi danh cho mo phong loi race condition, KHONG dung de ban ve that.
- So ve con lai la so dong Tickets co Status='AVAILABLE'. So ve duy nhat da ban la so dong Tickets co Status='SOLD'. Luot mua la so dong Purchases. Neu UNSYNC bi trung, luot mua co the lon hon so ve duy nhat da ban.
- Khong dung RESET neu muon giu lich su mua ve.
