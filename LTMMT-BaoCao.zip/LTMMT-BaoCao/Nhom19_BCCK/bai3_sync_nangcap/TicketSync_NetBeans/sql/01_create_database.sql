/*
  TicketSync - SQL Server
  Chay toan bo file nay bang SQL Server Management Studio (SSMS).
  Co chu y: bang Purchases co chu y KHONG tao UNIQUE(TicketId), vi can cho phep
  che do UNSYNC ghi nhan ve bi ban trung de quan sat race condition trong bai hoc.
*/
IF DB_ID(N'TicketSyncDB') IS NULL
    CREATE DATABASE TicketSyncDB;
GO
USE TicketSyncDB;
GO

IF OBJECT_ID(N'dbo.Purchases', N'U') IS NOT NULL DROP TABLE dbo.Purchases;
IF OBJECT_ID(N'dbo.Tickets', N'U') IS NOT NULL DROP TABLE dbo.Tickets;
IF OBJECT_ID(N'dbo.AppUsers', N'U') IS NOT NULL DROP TABLE dbo.AppUsers;
GO

CREATE TABLE dbo.AppUsers (
    UserId        INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_AppUsers PRIMARY KEY,
    Username      NVARCHAR(40) NOT NULL,
    FullName      NVARCHAR(100) NOT NULL,
    PasswordSalt  VARCHAR(64) NOT NULL,
    PasswordHash  VARCHAR(128) NOT NULL,
    UserRole      VARCHAR(10) NOT NULL CONSTRAINT DF_AppUsers_Role DEFAULT 'USER',
    IsActive      BIT NOT NULL CONSTRAINT DF_AppUsers_Active DEFAULT 1,
    CreatedAt     DATETIME2(0) NOT NULL CONSTRAINT DF_AppUsers_CreatedAt DEFAULT SYSDATETIME(),
    CONSTRAINT UQ_AppUsers_Username UNIQUE (Username),
    CONSTRAINT CK_AppUsers_Role CHECK (UserRole IN ('USER','ADMIN'))
);
GO

CREATE TABLE dbo.Tickets (
    TicketId   INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Tickets PRIMARY KEY,
    TicketCode VARCHAR(20) NOT NULL,
    Status     VARCHAR(12) NOT NULL CONSTRAINT DF_Tickets_Status DEFAULT 'AVAILABLE',
    CreatedAt  DATETIME2(0) NOT NULL CONSTRAINT DF_Tickets_CreatedAt DEFAULT SYSDATETIME(),
    SoldAt     DATETIME2(0) NULL,
    CONSTRAINT UQ_Tickets_TicketCode UNIQUE (TicketCode),
    CONSTRAINT CK_Tickets_Status CHECK (Status IN ('AVAILABLE','SOLD'))
);
GO

CREATE TABLE dbo.Purchases (
    PurchaseId   BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Purchases PRIMARY KEY,
    UserId       INT NOT NULL,
    TicketId     INT NOT NULL,
    CounterNo    TINYINT NOT NULL,
    SyncMode     VARCHAR(10) NOT NULL,
    PurchaseTime DATETIME2(0) NOT NULL CONSTRAINT DF_Purchases_Time DEFAULT SYSDATETIME(),
    CONSTRAINT FK_Purchases_Users FOREIGN KEY (UserId) REFERENCES dbo.AppUsers(UserId),
    CONSTRAINT FK_Purchases_Tickets FOREIGN KEY (TicketId) REFERENCES dbo.Tickets(TicketId),
    CONSTRAINT CK_Purchases_Counter CHECK (CounterNo BETWEEN 1 AND 3),
    CONSTRAINT CK_Purchases_Mode CHECK (SyncMode IN ('SYNC','UNSYNC'))
);
GO
CREATE INDEX IX_Tickets_Status ON dbo.Tickets(Status, TicketId);
CREATE INDEX IX_Purchases_UserId ON dbo.Purchases(UserId, PurchaseTime DESC);
CREATE INDEX IX_Purchases_TicketId ON dbo.Purchases(TicketId);
GO

/* Tài khoản demo dùng PBKDF2-HMAC-SHA256, 120.000 vòng, salt riêng từng tài khoản.
   admin / Admin@123; khach1, khach2, khach3 / Khach@123 */
INSERT dbo.AppUsers (Username, FullName, PasswordSalt, PasswordHash, UserRole, IsActive) VALUES
(N'admin',  N'Quản trị hệ thống', 'ABEiM0RVZneImaq7zN3u/w==', 'pjHcpvaFOmL5VCnTT7YK/4R6TLJ21vl5l3A/vsPn2xk=', 'ADMIN', 1),
(N'khach1', N'Nguyễn Minh An',    'ECEyQ1RldoeYqbrL3O3+Dw==', 'xtdDr1XKZobPPyf1/rcYmDchU6DfYIVQtYuHBSYlMIM=', 'USER', 1),
(N'khach2', N'Trần Gia Bảo',     'IDFCU2R1hpeoucrb7P0OHw==', 'xgpvFU7HlrsfW8wYnY06BamJujv36MY3J84EHFUtlGg=', 'USER', 1),
(N'khach3', N'Lê Ngọc Hà',       'MEFSY3SFlqe4ydrr/A0eLw==', 'pftreTbUab7M5XyAS9o57jOhl9WETizwoGfzophfwEk=', 'USER', 1);
GO

DECLARE @i INT = 1;
WHILE @i <= 30
BEGIN
    INSERT dbo.Tickets (TicketCode, Status)
    VALUES ('VE-' + RIGHT('000' + CONVERT(VARCHAR(3), @i), 3), 'AVAILABLE');
    SET @i = @i + 1;
END;
GO

PRINT N'Đã tạo CSDL TicketSyncDB, 4 tài khoản demo và 30 vé ban đầu.';
GO
