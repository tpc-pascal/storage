package bai6_rmi_nangcap;

import java.rmi.RemoteException;
import java.rmi.server.RemoteServer;
import java.rmi.server.ServerNotActiveException;
import java.rmi.server.UnicastRemoteObject;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.function.Consumer;

/** Cài đặt dịch vụ RMI và ghi lại địa chỉ Client đã gọi đến. */
public final class HelloServiceImpl extends UnicastRemoteObject implements HelloInterface {
    private static final long serialVersionUID = 1L;
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    private final transient Consumer<String> logger;

    /**
     * @param servicePort cổng TCP cố định dành cho đối tượng RMI, ví dụ 1100.
     * @param logger nơi nhận log; có thể null.
     */
    public HelloServiceImpl(int servicePort, Consumer<String> logger) throws RemoteException {
        super(servicePort);
        this.logger = logger;
    }

    @Override
    public String sayHello() throws RemoteException {
        String clientHost;
        try {
            clientHost = RemoteServer.getClientHost();
        } catch (ServerNotActiveException ex) {
            clientHost = "không xác định";
        }

        String now = LocalDateTime.now().format(TIME_FORMAT);
        log("Log Server: Server đã được gọi từ xa (Bởi Client IP: " + clientHost + ") | Phương thức=sayHello() | Thời điểm=" + now);
        return "Xin chào! Server đã thực thi sayHello() từ xa thành công.\n"
                + "Client: " + clientHost + "\n"
                + "Thời điểm xử lý: " + now;
    }

    private void log(String message) {
        if (logger != null) {
            logger.accept(message);
        }
    }
}
