package bai6_rmi_nangcap;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

/** Các hàm hỗ trợ lấy địa chỉ IPv4 để trình diễn trong mạng LAN. */
public final class NetworkUtils {
    private NetworkUtils() { }

    /** Trả về IPv4 LAN đầu tiên tìm được; nếu không có thì dùng loopback. */
    public static String findLanIPv4() {
        List<String> candidates = getLanIPv4Addresses();
        return candidates.isEmpty() ? "127.0.0.1" : candidates.get(0);
    }

    public static List<String> getLanIPv4Addresses() {
        List<String> addresses = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            if (interfaces == null) return addresses;
            for (NetworkInterface networkInterface : Collections.list(interfaces)) {
                try {
                    if (!networkInterface.isUp() || networkInterface.isLoopback() || networkInterface.isVirtual()) continue;
                    for (InetAddress address : Collections.list(networkInterface.getInetAddresses())) {
                        if (address instanceof Inet4Address
                                && !address.isLoopbackAddress()
                                && address.isSiteLocalAddress()) {
                            String value = address.getHostAddress();
                            if (!addresses.contains(value)) addresses.add(value);
                        }
                    }
                } catch (SocketException ignored) {
                    // Bỏ qua interface đang không thể truy cập và tiếp tục quét interface kế tiếp.
                }
            }
        } catch (SocketException ignored) {
            // Trả về danh sách rỗng; phía gọi sẽ dùng 127.0.0.1 làm phương án dự phòng.
        }
        return addresses;
    }

    public static boolean isValidPort(int port) {
        return port >= 1 && port <= 65535;
    }
}
