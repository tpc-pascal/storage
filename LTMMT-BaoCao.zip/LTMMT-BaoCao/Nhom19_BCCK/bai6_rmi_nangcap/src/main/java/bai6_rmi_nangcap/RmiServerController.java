package bai6_rmi_nangcap;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.ExportException;
import java.rmi.server.UnicastRemoteObject;
import java.util.function.Consumer;

/** Quản lý vòng đời Registry và đối tượng dịch vụ RMI. */
public final class RmiServerController {
    private final Consumer<String> logger;
    private Registry registry;
    private boolean ownsRegistry;
    private HelloServiceImpl service;
    private String serviceName;
    private int registryPort;
    private int servicePort;

    public RmiServerController(Consumer<String> logger) {
        this.logger = logger;
    }

    public synchronized void start(String advertisedHost, int requestedRegistryPort,
                                   int requestedServicePort, String requestedServiceName) throws Exception {
        if (isRunning()) throw new IllegalStateException("Server đang chạy. Hãy dừng Server trước khi đổi cấu hình.");
        String host = advertisedHost == null ? "" : advertisedHost.trim();
        String name = requestedServiceName == null ? "" : requestedServiceName.trim();
        if (host.isEmpty()) throw new IllegalArgumentException("Địa chỉ IP công bố không được để trống.");
        if (!NetworkUtils.isValidPort(requestedRegistryPort)) throw new IllegalArgumentException("Cổng Registry phải nằm trong khoảng 1–65535.");
        if (!NetworkUtils.isValidPort(requestedServicePort)) throw new IllegalArgumentException("Cổng dịch vụ phải nằm trong khoảng 1–65535.");
        if (requestedRegistryPort == requestedServicePort) throw new IllegalArgumentException("Cổng Registry và cổng dịch vụ phải khác nhau.");
        if (name.isEmpty() || name.contains("/") || name.contains("\\")) {
            throw new IllegalArgumentException("Tên dịch vụ không hợp lệ. Ví dụ: HelloService");
        }

        // RMI đưa host này vào stub mà Registry trả cho Client. Phải thiết lập trước khi export object.
        System.setProperty("java.rmi.server.hostname", host);
        Registry newRegistry = null;
        boolean createdHere = false;
        HelloServiceImpl newService = null;
        try {
            try {
                newRegistry = LocateRegistry.createRegistry(requestedRegistryPort);
                createdHere = true;
                log("Đã tạo RMI Registry tại cổng " + requestedRegistryPort + ".");
            } catch (ExportException portInUse) {
                // Nếu đã có rmiregistry chạy ngoài, thử tái sử dụng; không tự ý tắt Registry của tiến trình khác.
                Registry existing = LocateRegistry.getRegistry("127.0.0.1", requestedRegistryPort);
                existing.list();
                newRegistry = existing;
                log("Phát hiện Registry có sẵn tại cổng " + requestedRegistryPort + ", đang sử dụng Registry đó.");
            }

            newService = new HelloServiceImpl(requestedServicePort, this::log);
            newRegistry.rebind(name, newService);

            registry = newRegistry;
            ownsRegistry = createdHere;
            service = newService;
            serviceName = name;
            registryPort = requestedRegistryPort;
            servicePort = requestedServicePort;

            log("Đã đăng ký dịch vụ '" + name + "'.");
            log("Địa chỉ công bố trong stub: " + host + ".");
            log("Registry TCP: " + requestedRegistryPort + " | Dịch vụ TCP: " + requestedServicePort + ".");
            log("Server sẵn sàng nhận lời gọi. Hãy giữ ứng dụng mở trong lúc demo.");
        } catch (Exception ex) {
            if (newService != null) {
                try { UnicastRemoteObject.unexportObject(newService, true); } catch (Exception ignored) { }
            }
            if (createdHere && newRegistry != null) {
                try { UnicastRemoteObject.unexportObject(newRegistry, true); } catch (Exception ignored) { }
            }
            throw ex;
        }
    }

    public synchronized void stop() {
        if (registry == null && service == null) {
            log("Server hiện không chạy.");
            return;
        }
        if (registry != null && serviceName != null) {
            try {
                registry.unbind(serviceName);
                log("Đã gỡ đăng ký dịch vụ '" + serviceName + "'.");
            } catch (NotBoundException ignored) {
                log("Tên dịch vụ đã được gỡ đăng ký trước đó.");
            } catch (RemoteException ex) {
                log("Không thể gỡ đăng ký dịch vụ: " + ex.getMessage());
            }
        }
        if (service != null) {
            try { UnicastRemoteObject.unexportObject(service, true); }
            catch (Exception ex) { log("Thông báo khi đóng đối tượng dịch vụ: " + ex.getMessage()); }
        }
        if (ownsRegistry && registry != null) {
            try { UnicastRemoteObject.unexportObject(registry, true); }
            catch (Exception ex) { log("Thông báo khi đóng Registry: " + ex.getMessage()); }
        }
        registry = null;
        service = null;
        serviceName = null;
        ownsRegistry = false;
        log("Server đã dừng.");
    }

    public synchronized boolean isRunning() {
        return service != null && registry != null;
    }

    public synchronized int getRegistryPort() { return registryPort; }
    public synchronized int getServicePort() { return servicePort; }

    private void log(String message) {
        if (logger != null) logger.accept(message);
    }
}
