package bai6_rmi_nangcap;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/** Thực hiện lookup dịch vụ trong Registry và gọi phương thức từ xa. */
public final class RmiClientController {
    public String callSayHello(String host, int registryPort, String serviceName) throws Exception {
        String targetHost = host == null ? "" : host.trim();
        String targetName = serviceName == null ? "" : serviceName.trim();
        if (targetHost.isEmpty()) throw new IllegalArgumentException("Hãy nhập IP/host của Server.");
        if (!NetworkUtils.isValidPort(registryPort)) throw new IllegalArgumentException("Cổng Registry phải nằm trong khoảng 1–65535.");
        if (targetName.isEmpty() || targetName.contains("/") || targetName.contains("\\")) {
            throw new IllegalArgumentException("Tên dịch vụ không hợp lệ. Ví dụ: HelloService");
        }
        Registry registry = LocateRegistry.getRegistry(targetHost, registryPort);
        HelloInterface service = (HelloInterface) registry.lookup(targetName);
        return service.sayHello();
    }
}
