package bai6_rmi_nangcap;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Giao diện từ xa: Client gọi sayHello() như một phương thức thông thường,
 * nhưng lời gọi được chuyển qua mạng đến đối tượng đang chạy trên Server.
 */
public interface HelloInterface extends Remote {
    String sayHello() throws RemoteException;
}
