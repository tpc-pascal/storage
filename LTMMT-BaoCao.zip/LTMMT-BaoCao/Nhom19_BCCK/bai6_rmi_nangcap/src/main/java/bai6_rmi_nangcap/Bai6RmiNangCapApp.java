package bai6_rmi_nangcap;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.text.DefaultCaret;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.FlowLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/** Điểm khởi chạy ứng dụng demo RMI có giao diện Swing. */
public final class Bai6RmiNangCapApp extends JFrame {
    private static final Color NAVY = new Color(18, 38, 67);
    private static final Color BLUE = new Color(43, 105, 230);
    private static final Color BLUE_DARK = new Color(31, 78, 180);
    private static final Color BACKGROUND = new Color(244, 247, 252);
    private static final Color TEXT = new Color(33, 48, 69);
    private static final Color MUTED = new Color(103, 119, 140);
    private static final Color GREEN = new Color(22, 145, 91);
    private static final Color RED = new Color(202, 57, 66);
    private static final Color AMBER = new Color(184, 116, 15);
    private static final Color LINE = new Color(226, 232, 241);
    private static final DateTimeFormatter LOG_TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final RmiServerController serverController;
    private final RmiClientController clientController = new RmiClientController();

    private final JTextField serverHostField = new JTextField("127.0.0.1", 18);
    private final JTextField registryPortField = new JTextField("1099", 8);
    private final JTextField servicePortField = new JTextField("1100", 8);
    private final JTextField serverServiceNameField = new JTextField("HelloService", 18);
    private final JTextField clientHostField = new JTextField("127.0.0.1", 18);
    private final JTextField clientRegistryPortField = new JTextField("1099", 8);
    private final JTextField clientServiceNameField = new JTextField("HelloService", 18);

    private final JTextArea serverLogArea = createLogArea();
    private final JTextArea clientLogArea = createLogArea();
    private final JTextArea responseArea = new JTextArea(5, 30);

    private final JLabel serverStatus = statusLabel("●  ĐANG DỪNG", RED);
    private final JLabel clientStatus = statusLabel("●  CHƯA GỌI", MUTED);
    private final JLabel dashboardServerStatus = statusLabel("●  Server chưa chạy", RED);
    private final JLabel dashboardClientStatus = statusLabel("●  Chưa có lời gọi", MUTED);
    private final JLabel dashboardAddress = new JLabel("127.0.0.1 : 1099  /  service 1100");
    private final JButton startServerButton = primaryButton("▶  Khởi động Server");
    private final JButton stopServerButton = secondaryButton("■  Dừng Server");
    private final JButton callButton = primaryButton("⇧  Gọi sayHello()");
    private final JLabel overviewMessage = new JLabel("Sẵn sàng cấu hình phiên demo.");

    public Bai6RmiNangCapApp() {
        super("Bài 6 RMI Nâng Cấp | Java Remote Method Invocation");
        serverController = new RmiServerController(this::appendServerLog);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setMinimumSize(new Dimension(1000, 700));
        setSize(1180, 820);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BACKGROUND);

        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(BACKGROUND);
        root.add(buildHeader(), BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("SansSerif", Font.BOLD, 13));
        tabs.setForeground(TEXT);
        tabs.setBackground(BACKGROUND);
        tabs.setBorder(new EmptyBorder(12, 18, 12, 18));
        tabs.addTab("  Tổng quan  ", buildOverviewTab());
        tabs.addTab("  Cấu hình Server  ", buildServerTab());
        tabs.addTab("  Client gọi từ xa  ", buildClientTab());
        root.add(tabs, BorderLayout.CENTER);
        setContentPane(root);

        stopServerButton.setEnabled(false);
        responseArea.setEditable(false);
        responseArea.setLineWrap(true);
        responseArea.setWrapStyleWord(true);
        responseArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        responseArea.setForeground(TEXT);
        responseArea.setBackground(new Color(248, 250, 253));
        responseArea.setBorder(new EmptyBorder(12, 13, 12, 13));

        wireActions();
        updateDashboardAddress();
        appendServerLog("Ứng dụng đã khởi động. Cấu hình mặc định dành cho demo trên cùng máy.");
        appendClientLog("Nhập cấu hình Server rồi nhấn 'Gọi sayHello()' để kiểm thử.");

        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                if (serverController.isRunning()) {
                    int choice = JOptionPane.showConfirmDialog(Bai6RmiNangCapApp.this,
                            "Server đang chạy. Dừng Server và đóng ứng dụng?", "Xác nhận thoát",
                            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if (choice != JOptionPane.YES_OPTION) return;
                    serverController.stop();
                }
                dispose();
                System.exit(0);
            }
        });
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout(20, 0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, NAVY, getWidth(), getHeight(), new Color(37, 81, 143)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        header.setBorder(new EmptyBorder(20, 28, 20, 28));
        header.setPreferredSize(new Dimension(1000, 116));
        header.setOpaque(false);

        JPanel brand = new JPanel();
        brand.setOpaque(false);
        brand.setLayout(new BoxLayout(brand, BoxLayout.Y_AXIS));
        JLabel eyebrow = new JLabel("JAVA NETWORKING LAB     /     BÀI THỰC HÀNH SỐ 06");
        eyebrow.setFont(new Font("SansSerif", Font.BOLD, 10));
        eyebrow.setForeground(new Color(174, 205, 255));
        JLabel title = new JLabel("RMI • GỌI PHƯƠNG THỨC TỪ XA");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        JLabel subtitle = new JLabel("Remote Method Invocation  ·  Registry  ·  Stub  ·  Server Log");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 12));
        subtitle.setForeground(new Color(221, 231, 247));
        brand.add(eyebrow);
        brand.add(Box.createVerticalStrut(7));
        brand.add(title);
        brand.add(Box.createVerticalStrut(4));
        brand.add(subtitle);

        JPanel right = new JPanel();
        right.setOpaque(false);
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        JLabel badge = new JLabel("  DEMO READY  ");
        badge.setOpaque(true);
        badge.setBackground(new Color(37, 160, 118));
        badge.setForeground(Color.WHITE);
        badge.setFont(new Font("SansSerif", Font.BOLD, 11));
        badge.setBorder(new EmptyBorder(7, 8, 7, 8));
        badge.setAlignmentX(RIGHT_ALIGNMENT);
        JLabel java = new JLabel("JDK 17+  |  Swing UI");
        java.setForeground(new Color(221, 231, 247));
        java.setFont(new Font("SansSerif", Font.PLAIN, 11));
        java.setAlignmentX(RIGHT_ALIGNMENT);
        right.add(badge);
        right.add(Box.createVerticalStrut(9));
        right.add(java);
        header.add(brand, BorderLayout.CENTER);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    private JPanel buildOverviewTab() {
        JPanel page = pagePanel();
        page.setLayout(new BorderLayout(0, 15));

        CardPanel hero = new CardPanel(new BorderLayout(14, 8));
        hero.setBorder(new EmptyBorder(20, 22, 20, 22));
        JLabel heroTitle = new JLabel("BẢNG ĐIỀU KHIỂN DEMO");
        heroTitle.setFont(new Font("SansSerif", Font.BOLD, 19));
        heroTitle.setForeground(TEXT);
        JLabel heroBody = new JLabel("Khởi động dịch vụ trên Server, sau đó từ Client tìm dịch vụ trong Registry và gọi hàm sayHello().");
        heroBody.setFont(new Font("SansSerif", Font.PLAIN, 13));
        heroBody.setForeground(MUTED);
        JPanel heroText = new JPanel();
        heroText.setOpaque(false);
        heroText.setLayout(new BoxLayout(heroText, BoxLayout.Y_AXIS));
        heroText.add(heroTitle);
        heroText.add(Box.createVerticalStrut(7));
        heroText.add(heroBody);
        hero.add(heroText, BorderLayout.CENTER);
        overviewMessage.setFont(new Font("SansSerif", Font.BOLD, 12));
        overviewMessage.setForeground(BLUE_DARK);
        overviewMessage.setHorizontalAlignment(SwingConstants.RIGHT);
        hero.add(overviewMessage, BorderLayout.SOUTH);

        JPanel statusRow = new JPanel(new GridBagLayout());
        statusRow.setOpaque(false);
        statusRow.setPreferredSize(new Dimension(500, 102));
        GridBagConstraints s = new GridBagConstraints();
        s.gridy = 0; s.weightx = 1; s.fill = GridBagConstraints.BOTH; s.insets = new Insets(0, 0, 0, 10);
        statusRow.add(statusCard("01  /  SERVER", dashboardServerStatus, "Registry + đối tượng dịch vụ"), s);
        s.gridx = 1; s.insets = new Insets(0, 0, 0, 0);
        statusRow.add(statusCard("02  /  CLIENT", dashboardClientStatus, "Lookup + gọi hàm từ xa"), s);

        JPanel flowCard = new CardPanel(new BorderLayout(0, 15));
        flowCard.setBorder(new EmptyBorder(17, 20, 19, 20));
        flowCard.add(sectionHeading("LUỒNG HOẠT ĐỘNG RMI", "Registry giúp Client tìm stub; lời gọi thực tế được chuyển đến đối tượng từ xa."), BorderLayout.NORTH);
        JPanel flow = new JPanel(new GridBagLayout());
        flow.setOpaque(false);
        String[][] nodes = {
                {"CLIENT", "RMIClient"}, {"REGISTRY", "TCP 1099"},
                {"STUB", "Proxy từ xa"}, {"SERVER", "sayHello()"}
        };
        GridBagConstraints f = new GridBagConstraints();
        f.gridy = 0; f.fill = GridBagConstraints.HORIZONTAL; f.weightx = 1; f.insets = new Insets(3, 3, 3, 3);
        for (int i = 0; i < nodes.length; i++) {
            f.gridx = i * 2;
            flow.add(flowNode(nodes[i][0], nodes[i][1], i), f);
            if (i < nodes.length - 1) {
                f.gridx = i * 2 + 1; f.weightx = 0;
                JLabel arrow = new JLabel("➜");
                arrow.setFont(new Font("SansSerif", Font.BOLD, 22));
                arrow.setForeground(new Color(133, 151, 175));
                arrow.setHorizontalAlignment(SwingConstants.CENTER);
                flow.add(arrow, f);
                f.weightx = 1;
            }
        }
        flowCard.add(flow, BorderLayout.CENTER);

        JPanel lower = new JPanel(new GridBagLayout());
        lower.setOpaque(false);
        GridBagConstraints l = new GridBagConstraints();
        l.gridy = 0; l.weightx = 1; l.weighty = 1; l.fill = GridBagConstraints.BOTH; l.insets = new Insets(0, 0, 0, 10);
        lower.add(informationCard("DEMO TRÊN CÙNG MÁY", new String[]{
                "1. Mở tab Cấu hình Server → Khởi động Server.",
                "2. Mở tab Client → dùng 127.0.0.1 và cổng Registry 1099.",
                "3. Nhấn Gọi sayHello(); xem kết quả ở Client và log ở Server."
        }, BLUE), l);
        l.gridx = 1; l.insets = new Insets(0, 0, 0, 0);
        lower.add(informationCard("DEMO QUA HAI MÁY TRONG LAN", new String[]{
                "1. Server chọn IP LAN (nút Lấy IP LAN), rồi khởi động.",
                "2. Client nhập IP LAN của Server, không dùng 127.0.0.1.",
                "3. Cho phép TCP cổng 1099 và 1100 qua Firewall."
        }, GREEN), l);

        JPanel center = new JPanel();
        center.setOpaque(false);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        statusRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 102));
        flowCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 190));
        lower.setMaximumSize(new Dimension(Integer.MAX_VALUE, 190));
        center.add(statusRow);
        center.add(Box.createVerticalStrut(14));
        center.add(flowCard);
        center.add(Box.createVerticalStrut(14));
        center.add(lower);
        page.add(hero, BorderLayout.NORTH);
        page.add(center, BorderLayout.CENTER);
        page.add(addressFooter(), BorderLayout.SOUTH);
        return page;
    }

    private JPanel buildServerTab() {
        JPanel page = pagePanel();
        page.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridy = 0; c.fill = GridBagConstraints.BOTH; c.weighty = 1; c.insets = new Insets(0, 0, 0, 14);
        c.gridx = 0; c.weightx = 0.43;
        page.add(buildServerConfigCard(), c);
        c.gridx = 1; c.weightx = 0.57; c.insets = new Insets(0, 0, 0, 0);
        page.add(buildServerLogCard(), c);
        return page;
    }

    private JPanel buildServerConfigCard() {
        CardPanel card = new CardPanel(new BorderLayout(0, 16));
        card.setBorder(new EmptyBorder(20, 20, 20, 20));
        card.add(sectionHeading("CẤU HÌNH SERVER", "Thông số được sử dụng khi export đối tượng RMI."), BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.gridy = 0; c.weightx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.insets = new Insets(7, 0, 3, 0); c.anchor = GridBagConstraints.WEST;
        addField(form, c, "IP / Host công bố trong Stub", serverHostField, "Cùng máy: 127.0.0.1 · Hai máy: IP LAN của Server");
        c.gridy++;
        addField(form, c, "Cổng RMI Registry", registryPortField, "Client dùng cổng này để tra cứu tên dịch vụ.");
        c.gridy++;
        addField(form, c, "Cổng đối tượng RMI", servicePortField, "Cổng TCP cố định của HelloService; cần mở Firewall.");
        c.gridy++;
        addField(form, c, "Tên dịch vụ", serverServiceNameField, "Tên phải trùng với cấu hình ở Client.");

        JPanel ipActions = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        ipActions.setOpaque(false);
        JButton detectButton = secondaryButton("◎  Lấy IP LAN");
        JButton localButton = ghostButton("Dùng 127.0.0.1");
        detectButton.addActionListener(e -> {
            String ip = NetworkUtils.findLanIPv4();
            serverHostField.setText(ip);
            clientHostField.setText(ip);
            appendServerLog("Đã chọn IP LAN: " + ip + ". Hãy bảo đảm Client có thể truy cập IP này.");
            updateDashboardAddress();
        });
        localButton.addActionListener(e -> {
            serverHostField.setText("127.0.0.1");
            clientHostField.setText("127.0.0.1");
            appendServerLog("Đã đặt IP về 127.0.0.1 cho demo trên cùng máy.");
            updateDashboardAddress();
        });
        ipActions.add(detectButton);
        ipActions.add(Box.createHorizontalStrut(8));
        ipActions.add(localButton);

        JPanel buttonRow = new JPanel(new GridBagLayout());
        buttonRow.setOpaque(false);
        GridBagConstraints b = new GridBagConstraints();
        b.gridx = 0; b.gridy = 0; b.weightx = 1; b.fill = GridBagConstraints.HORIZONTAL; b.insets = new Insets(0, 0, 9, 0);
        buttonRow.add(startServerButton, b);
        b.gridy++; buttonRow.add(stopServerButton, b);
        JPanel actions = new JPanel();
        actions.setOpaque(false);
        actions.setLayout(new BoxLayout(actions, BoxLayout.Y_AXIS));
        actions.add(ipActions);
        actions.add(Box.createVerticalStrut(18));
        actions.add(serverStatus);
        actions.add(Box.createVerticalStrut(13));
        actions.add(buttonRow);

        JPanel middle = new JPanel(new BorderLayout(0, 12));
        middle.setOpaque(false);
        middle.add(form, BorderLayout.NORTH);
        middle.add(actions, BorderLayout.CENTER);
        card.add(middle, BorderLayout.CENTER);
        card.add(notePanel("LƯU Ý MẠNG", "Server công bố đúng địa chỉ mà Client có thể truy cập. Khi demo qua LAN, tránh nhập 127.0.0.1 vì địa chỉ này luôn trỏ về chính máy đang chạy Client."), BorderLayout.SOUTH);
        return card;
    }

    private JPanel buildServerLogCard() {
        CardPanel card = new CardPanel(new BorderLayout(0, 12));
        card.setBorder(new EmptyBorder(20, 20, 20, 20));
        JPanel header = new JPanel(new BorderLayout(8, 0));
        header.setOpaque(false);
        header.add(sectionHeading("NHẬT KÝ SERVER", "Log xuất hiện khi Client gọi phương thức từ xa."), BorderLayout.CENTER);
        JButton clear = ghostButton("Xóa log");
        clear.addActionListener(e -> serverLogArea.setText(""));
        header.add(clear, BorderLayout.EAST);
        card.add(header, BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(serverLogArea);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(38, 57, 82), 1, true));
        scroll.getViewport().setBackground(new Color(12, 24, 42));
        card.add(scroll, BorderLayout.CENTER);
        card.add(notePanel("KẾT QUẢ MONG ĐỢI", "Khi Client gọi thành công, log hiển thị thông báo Server đã được gọi từ xa, địa chỉ IP Client và thời điểm xử lý."), BorderLayout.SOUTH);
        return card;
    }

    private JPanel buildClientTab() {
        JPanel page = pagePanel();
        page.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridy = 0; c.fill = GridBagConstraints.BOTH; c.weighty = 0.58; c.insets = new Insets(0, 0, 13, 0);
        c.gridx = 0; c.weightx = 1;
        page.add(buildClientConfigCard(), c);
        c.gridy = 1; c.weighty = 0.42; c.insets = new Insets(0, 0, 0, 0);
        page.add(buildClientResultCard(), c);
        return page;
    }

    private JPanel buildClientConfigCard() {
        CardPanel card = new CardPanel(new BorderLayout(0, 14));
        card.setBorder(new EmptyBorder(20, 20, 20, 20));
        card.add(sectionHeading("CẤU HÌNH CLIENT", "Địa chỉ dưới đây là máy đang chạy Server, không phải IP của Client."), BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL; c.anchor = GridBagConstraints.WEST; c.insets = new Insets(6, 0, 4, 12); c.gridy = 0;
        c.gridx = 0; c.weightx = 0.46; addCompactField(form, c, "IP / Host Server", clientHostField);
        c.gridx = 1; c.weightx = 0.22; addCompactField(form, c, "Cổng Registry", clientRegistryPortField);
        c.gridx = 2; c.weightx = 0.32; addCompactField(form, c, "Tên dịch vụ", clientServiceNameField);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        actions.setOpaque(false);
        callButton.setPreferredSize(new Dimension(190, 42));
        JButton copyConfig = secondaryButton("↙  Lấy cấu hình từ Server");
        JButton clearLog = ghostButton("Xóa log Client");
        copyConfig.addActionListener(e -> copyServerConfigToClient());
        clearLog.addActionListener(e -> clientLogArea.setText(""));
        actions.add(callButton);
        actions.add(Box.createHorizontalStrut(10));
        actions.add(copyConfig);
        actions.add(Box.createHorizontalStrut(10));
        actions.add(clearLog);
        JPanel body = new JPanel(new BorderLayout(0, 10));
        body.setOpaque(false);
        body.add(form, BorderLayout.NORTH);
        body.add(actions, BorderLayout.CENTER);
        card.add(body, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildClientResultCard() {
        CardPanel card = new CardPanel(new GridBagLayout());
        card.setBorder(new EmptyBorder(17, 20, 17, 20));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.gridy = 0; c.weightx = 0.42; c.weighty = 1; c.fill = GridBagConstraints.BOTH; c.insets = new Insets(0, 0, 0, 14);
        JPanel left = new JPanel(new BorderLayout(0, 8));
        left.setOpaque(false);
        left.add(sectionHeading("PHẢN HỒI TỪ SERVER", "Kết quả nhận được qua Remote Method Call."), BorderLayout.NORTH);
        JScrollPane responseScroll = new JScrollPane(responseArea);
        responseScroll.setBorder(BorderFactory.createLineBorder(LINE, 1, true));
        left.add(responseScroll, BorderLayout.CENTER);
        left.add(clientStatus, BorderLayout.SOUTH);
        card.add(left, c);
        c.gridx = 1; c.weightx = 0.58; c.insets = new Insets(0, 0, 0, 0);
        JPanel right = new JPanel(new BorderLayout(0, 8));
        right.setOpaque(false);
        JPanel titleRow = new JPanel(new BorderLayout());
        titleRow.setOpaque(false);
        titleRow.add(sectionHeading("NHẬT KÝ CLIENT", "Lookup và gọi sayHello()"), BorderLayout.CENTER);
        right.add(titleRow, BorderLayout.NORTH);
        JScrollPane logScroll = new JScrollPane(clientLogArea);
        logScroll.setBorder(BorderFactory.createLineBorder(new Color(38, 57, 82), 1, true));
        right.add(logScroll, BorderLayout.CENTER);
        card.add(right, c);
        return card;
    }

    private JPanel statusCard(String eyebrow, JLabel status, String detail) {
        CardPanel card = new CardPanel(new BorderLayout(0, 8));
        card.setBorder(new EmptyBorder(13, 17, 13, 17));
        JLabel top = new JLabel(eyebrow);
        top.setForeground(MUTED);
        top.setFont(new Font("SansSerif", Font.BOLD, 10));
        status.setFont(new Font("SansSerif", Font.BOLD, 13));
        JLabel desc = new JLabel(detail);
        desc.setForeground(MUTED);
        desc.setFont(new Font("SansSerif", Font.PLAIN, 11));
        JPanel content = new JPanel(); content.setOpaque(false); content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.add(top); content.add(Box.createVerticalStrut(8)); content.add(status); content.add(Box.createVerticalStrut(4)); content.add(desc);
        card.add(content, BorderLayout.CENTER);
        return card;
    }

    private JPanel flowNode(String eyebrow, String description, int index) {
        Color[] fills = {new Color(235, 242, 255), new Color(235, 248, 244), new Color(245, 240, 255), new Color(255, 245, 230)};
        Color[] inks = {BLUE_DARK, GREEN, new Color(111, 69, 181), AMBER};
        CardPanel node = new CardPanel(new BorderLayout(0, 7));
        node.setBackground(fills[index]);
        node.setBorder(new EmptyBorder(13, 10, 13, 10));
        JLabel title = new JLabel(eyebrow, SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 11)); title.setForeground(inks[index]);
        JLabel desc = new JLabel("<html><div style='text-align:center'>" + description + "</div></html>", SwingConstants.CENTER);
        desc.setFont(new Font("SansSerif", Font.PLAIN, 11)); desc.setForeground(TEXT);
        node.add(title, BorderLayout.CENTER); node.add(desc, BorderLayout.SOUTH);
        node.setPreferredSize(new Dimension(150, 78));
        return node;
    }

    private JPanel informationCard(String title, String[] lines, Color accent) {
        CardPanel card = new CardPanel(new BorderLayout(0, 10));
        card.setBorder(new EmptyBorder(15, 17, 15, 17));
        JLabel heading = new JLabel(title);
        heading.setForeground(accent); heading.setFont(new Font("SansSerif", Font.BOLD, 11));
        JPanel body = new JPanel(); body.setOpaque(false); body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        for (String line : lines) {
            JLabel label = new JLabel("•  " + line);
            label.setFont(new Font("SansSerif", Font.PLAIN, 11)); label.setForeground(TEXT);
            label.setBorder(new EmptyBorder(2, 0, 2, 0));
            body.add(label);
        }
        card.add(heading, BorderLayout.NORTH); card.add(body, BorderLayout.CENTER);
        return card;
    }

    private JPanel addressFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        footer.setBorder(new EmptyBorder(0, 2, 0, 2));
        JLabel prefix = new JLabel("CẤU HÌNH SERVER HIỆN TẠI");
        prefix.setFont(new Font("SansSerif", Font.BOLD, 10)); prefix.setForeground(MUTED);
        dashboardAddress.setFont(new Font("Monospaced", Font.BOLD, 12)); dashboardAddress.setForeground(NAVY);
        footer.add(prefix, BorderLayout.WEST); footer.add(dashboardAddress, BorderLayout.EAST);
        return footer;
    }

    private JPanel notePanel(String title, String message) {
        JPanel panel = new JPanel(new BorderLayout(0, 5));
        panel.setOpaque(true); panel.setBackground(new Color(242, 247, 255));
        panel.setBorder(new EmptyBorder(12, 13, 12, 13));
        JLabel heading = new JLabel(title);
        heading.setFont(new Font("SansSerif", Font.BOLD, 10)); heading.setForeground(BLUE_DARK);
        JLabel body = new JLabel("<html><div style='width:265px'>" + message + "</div></html>");
        body.setFont(new Font("SansSerif", Font.PLAIN, 11)); body.setForeground(MUTED);
        panel.add(heading, BorderLayout.NORTH); panel.add(body, BorderLayout.CENTER);
        return panel;
    }

    private JPanel sectionHeading(String title, String subtitle) {
        JPanel panel = new JPanel(); panel.setOpaque(false); panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        JLabel heading = new JLabel(title); heading.setFont(new Font("SansSerif", Font.BOLD, 14)); heading.setForeground(TEXT);
        JLabel sub = new JLabel(subtitle); sub.setFont(new Font("SansSerif", Font.PLAIN, 11)); sub.setForeground(MUTED);
        panel.add(heading); panel.add(Box.createVerticalStrut(5)); panel.add(sub);
        return panel;
    }

    private void addField(JPanel form, GridBagConstraints c, String label, JTextField field, String helper) {
        JPanel wrapper = new JPanel(); wrapper.setOpaque(false); wrapper.setLayout(new BoxLayout(wrapper, BoxLayout.Y_AXIS));
        JLabel labelComponent = new JLabel(label); labelComponent.setFont(new Font("SansSerif", Font.BOLD, 12)); labelComponent.setForeground(TEXT);
        styleField(field);
        JLabel help = new JLabel(helper); help.setFont(new Font("SansSerif", Font.PLAIN, 10)); help.setForeground(MUTED);
        wrapper.add(labelComponent); wrapper.add(Box.createVerticalStrut(5)); wrapper.add(field); wrapper.add(Box.createVerticalStrut(4)); wrapper.add(help);
        form.add(wrapper, c);
    }

    private void addCompactField(JPanel form, GridBagConstraints c, String label, JTextField field) {
        JPanel wrapper = new JPanel(); wrapper.setOpaque(false); wrapper.setLayout(new BoxLayout(wrapper, BoxLayout.Y_AXIS));
        JLabel lab = new JLabel(label); lab.setFont(new Font("SansSerif", Font.BOLD, 12)); lab.setForeground(TEXT);
        styleField(field);
        wrapper.add(lab); wrapper.add(Box.createVerticalStrut(7)); wrapper.add(field);
        form.add(wrapper, c);
    }

    private void styleField(JTextField field) {
        field.setFont(new Font("SansSerif", Font.PLAIN, 13));
        field.setForeground(TEXT); field.setBackground(Color.WHITE);
        field.setCaretColor(BLUE);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(211, 220, 233), 1, true),
                new EmptyBorder(8, 10, 8, 10)));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        field.setPreferredSize(new Dimension(150, 38));
    }

    private JPanel pagePanel() {
        JPanel panel = new JPanel(); panel.setBackground(BACKGROUND); panel.setBorder(new EmptyBorder(10, 8, 9, 8));
        return panel;
    }

    private static JTextArea createLogArea() {
        JTextArea area = new JTextArea();
        area.setEditable(false); area.setLineWrap(true); area.setWrapStyleWord(true);
        area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        area.setBackground(new Color(12, 24, 42)); area.setForeground(new Color(191, 229, 210));
        area.setCaretColor(Color.WHITE); area.setBorder(new EmptyBorder(12, 12, 12, 12));
        if (area.getCaret() instanceof DefaultCaret caret) caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        return area;
    }

    private static JLabel statusLabel(String text, Color foreground) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("SansSerif", Font.BOLD, 12));
        label.setForeground(foreground);
        return label;
    }

    private static JButton primaryButton(String text) {
        return styledButton(text, BLUE, Color.WHITE);
    }

    private static JButton secondaryButton(String text) {
        return styledButton(text, new Color(231, 239, 253), BLUE_DARK);
    }

    private static JButton ghostButton(String text) {
        JButton button = styledButton(text, new Color(247, 249, 252), MUTED);
        button.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(LINE, 1, true), new EmptyBorder(7, 10, 7, 10)));
        return button;
    }

    private static JButton styledButton(String text, Color background, Color foreground) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 12));
        button.setBackground(background); button.setForeground(foreground);
        button.setFocusPainted(false); button.setOpaque(true);
        button.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(background, 1, true), new EmptyBorder(8, 12, 8, 12)));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(190, 38));
        return button;
    }

    private void wireActions() {
        startServerButton.addActionListener(e -> startServerAsync());
        stopServerButton.addActionListener(e -> stopServerAsync());
        callButton.addActionListener(e -> callServerAsync());
        serverHostField.addActionListener(e -> updateDashboardAddress());
        registryPortField.addActionListener(e -> updateDashboardAddress());
        servicePortField.addActionListener(e -> updateDashboardAddress());
        serverServiceNameField.addActionListener(e -> updateDashboardAddress());
    }

    private void startServerAsync() {
        final String host = serverHostField.getText().trim();
        final String name = serverServiceNameField.getText().trim();
        final int registryPort;
        final int servicePort;
        try {
            registryPort = Integer.parseInt(registryPortField.getText().trim());
            servicePort = Integer.parseInt(servicePortField.getText().trim());
        } catch (NumberFormatException ex) {
            showError("Cổng Registry và cổng dịch vụ phải là số nguyên.");
            return;
        }
        startServerButton.setEnabled(false);
        serverStatus.setText("●  ĐANG KHỞI ĐỘNG"); serverStatus.setForeground(AMBER);
        dashboardServerStatus.setText("●  Server đang khởi động"); dashboardServerStatus.setForeground(AMBER);
        overviewMessage.setText("Đang khởi tạo Registry và export đối tượng RMI...");
        updateDashboardAddress();

        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() throws Exception {
                serverController.start(host, registryPort, servicePort, name);
                return null;
            }
            @Override protected void done() {
                try {
                    get();
                    serverStatus.setText("●  SERVER ĐANG CHẠY"); serverStatus.setForeground(GREEN);
                    dashboardServerStatus.setText("●  Server đang hoạt động"); dashboardServerStatus.setForeground(GREEN);
                    overviewMessage.setText("Server sẵn sàng. Chuyển sang tab Client để gọi phương thức.");
                    stopServerButton.setEnabled(true);
                    copyServerConfigToClient();
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() == null ? ex : ex.getCause();
                    serverStatus.setText("●  KHỞI ĐỘNG THẤT BẠI"); serverStatus.setForeground(RED);
                    dashboardServerStatus.setText("●  Không khởi động được"); dashboardServerStatus.setForeground(RED);
                    overviewMessage.setText("Kiểm tra cổng, IP công bố và log Server.");
                    appendServerLog("LỖI KHỞI ĐỘNG: " + usefulMessage(cause));
                    showError(usefulMessage(cause));
                } finally {
                    startServerButton.setEnabled(!serverController.isRunning());
                    stopServerButton.setEnabled(serverController.isRunning());
                    updateDashboardAddress();
                }
            }
        }.execute();
    }

    private void stopServerAsync() {
        stopServerButton.setEnabled(false);
        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() {
                serverController.stop();
                return null;
            }
            @Override protected void done() {
                serverStatus.setText("●  ĐANG DỪNG"); serverStatus.setForeground(RED);
                dashboardServerStatus.setText("●  Server chưa chạy"); dashboardServerStatus.setForeground(RED);
                overviewMessage.setText("Server đã dừng. Có thể thay đổi cấu hình và khởi động lại.");
                startServerButton.setEnabled(true);
                stopServerButton.setEnabled(false);
            }
        }.execute();
    }

    private void callServerAsync() {
        final String host = clientHostField.getText().trim();
        final String name = clientServiceNameField.getText().trim();
        final int port;
        try {
            port = Integer.parseInt(clientRegistryPortField.getText().trim());
        } catch (NumberFormatException ex) {
            showError("Cổng Registry phải là số nguyên.");
            return;
        }
        callButton.setEnabled(false);
        clientStatus.setText("●  ĐANG KẾT NỐI..."); clientStatus.setForeground(AMBER);
        dashboardClientStatus.setText("●  Đang gọi phương thức"); dashboardClientStatus.setForeground(AMBER);
        responseArea.setText("Đang kết nối đến " + host + ":" + port + " ...\nĐang tra cứu dịch vụ '" + name + "'.");
        appendClientLog("Bắt đầu gọi: host=" + host + ", registry=" + port + ", service=" + name);
        overviewMessage.setText("Client đang kết nối. Nếu lỗi, kiểm tra IP, cổng và trạng thái Server.");

        new SwingWorker<String, Void>() {
            @Override protected String doInBackground() throws Exception {
                return clientController.callSayHello(host, port, name);
            }
            @Override protected void done() {
                try {
                    String response = get();
                    responseArea.setText(response);
                    clientStatus.setText("●  GỌI THÀNH CÔNG"); clientStatus.setForeground(GREEN);
                    dashboardClientStatus.setText("●  Lời gọi thành công"); dashboardClientStatus.setForeground(GREEN);
                    appendClientLog("Thành công: nhận phản hồi từ sayHello().");
                    overviewMessage.setText("Đã gọi sayHello() thành công; xem log ở cả Client và Server.");
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() == null ? ex : ex.getCause();
                    String message = usefulMessage(cause);
                    responseArea.setText("Không gọi được dịch vụ.\n\n" + message
                            + "\n\nKiểm tra: Server đã chạy? IP có truy cập được? Registry đúng cổng?"
                            + "\nNếu chạy qua LAN, mở TCP cả cổng Registry và cổng dịch vụ RMI.");
                    clientStatus.setText("●  GỌI THẤT BẠI"); clientStatus.setForeground(RED);
                    dashboardClientStatus.setText("●  Lời gọi thất bại"); dashboardClientStatus.setForeground(RED);
                    appendClientLog("LỖI: " + message);
                    overviewMessage.setText("Lời gọi thất bại. Xem phản hồi Client để kiểm tra cấu hình.");
                } finally {
                    callButton.setEnabled(true);
                }
            }
        }.execute();
    }

    private void copyServerConfigToClient() {
        clientHostField.setText(serverHostField.getText().trim());
        clientRegistryPortField.setText(registryPortField.getText().trim());
        clientServiceNameField.setText(serverServiceNameField.getText().trim());
        appendClientLog("Đã sao chép IP/port/tên dịch vụ từ cấu hình Server vào Client.");
    }

    private void updateDashboardAddress() {
        dashboardAddress.setText(serverHostField.getText().trim() + " : " + registryPortField.getText().trim()
                + "  /  service " + servicePortField.getText().trim() + "  /  " + serverServiceNameField.getText().trim());
    }

    private void appendServerLog(String message) { appendLog(serverLogArea, message); }
    private void appendClientLog(String message) { appendLog(clientLogArea, message); }

    private void appendLog(JTextArea area, String message) {
        Runnable task = () -> {
            area.append("[" + LocalTime.now().format(LOG_TIME) + "] " + message + "\n");
            area.setCaretPosition(area.getDocument().getLength());
        };
        if (SwingUtilities.isEventDispatchThread()) task.run(); else SwingUtilities.invokeLater(task);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Không thể thực hiện", JOptionPane.ERROR_MESSAGE);
    }

    private static String usefulMessage(Throwable throwable) {
        if (throwable == null) return "Lỗi không xác định.";
        String message = throwable.getMessage();
        if (message != null && !message.isBlank()) return throwable.getClass().getSimpleName() + ": " + message;
        return throwable.getClass().getSimpleName();
    }

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
            // Dùng giao diện mặc định nếu hệ thống không có Nimbus.
        }
        SwingUtilities.invokeLater(() -> new Bai6RmiNangCapApp().setVisible(true));
    }

    /** Panel có nền bo góc nhẹ, không phụ thuộc thư viện giao diện ngoài. */
    private static final class CardPanel extends JPanel {
        CardPanel(java.awt.LayoutManager layout) {
            super(layout);
            setOpaque(false);
            setBackground(Color.WHITE);
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
            g2.setColor(LINE);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
