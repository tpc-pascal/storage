@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist out mkdir out
echo [1/2] Dang bien dich project bang JDK hien tai...
javac -encoding UTF-8 -d out src\main\java\bai6_rmi_nangcap\HelloInterface.java src\main\java\bai6_rmi_nangcap\HelloServiceImpl.java src\main\java\bai6_rmi_nangcap\NetworkUtils.java src\main\java\bai6_rmi_nangcap\RmiServerController.java src\main\java\bai6_rmi_nangcap\RmiClientController.java src\main\java\bai6_rmi_nangcap\Bai6RmiNangCapApp.java
if errorlevel 1 (
  echo Bien dich that bai. Hay kiem tra da cai JDK 17 tro len va PATH co javac.
  pause
  exit /b 1
)
echo [2/2] Dang khoi dong giao dien...
java -Dfile.encoding=UTF-8 -cp out bai6_rmi_nangcap.Bai6RmiNangCapApp
endlocal
