package bai5_multicast_nangcap;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.text.DefaultCaret;

/**
 * Bai 5 - Multicast trong Java
 * Ung dung Swing mot file, khong can thu vien ngoai.
 *
 * Chay trong NetBeans:
 * 1. Tao project Java ten bai5_multicast_nangcap.
 * 2. Tao Java Class ten Bai5MulticastNangCap trong Source Packages (package mac dinh).
 * 3. Dan toan bo file nay vao class va Run File.
 *
 * May phat va cac may nhan phai dung cung Group IP multicast va Port.
 * Vi du: Group IP 230.0.0.1, Port 8888.
 */
public class Bai5MulticastNangCap extends JFrame {

    private static final Color BG = new Color(11, 16, 32);
    private static final Color CARD = new Color(21, 29, 49);
    private static final Color CARD_ALT = new Color(27, 37, 61);
    private static final Color INPUT_BG = new Color(13, 20, 37);
    private static final Color BORDER = new Color(47, 61, 89);
    private static final Color TEXT = new Color(235, 242, 255);
    private static final Color MUTED = new Color(158, 174, 201);
    private static final Color CYAN = new Color(54, 211, 232);
    private static final Color BLUE = new Color(73, 126, 255);
    private static final Color GREEN = new Color(67, 214, 151);
    private static final Color RED = new Color(255, 104, 119);

    private final JTextField serverGroupField = createTextField("230.0.0.1");
    private final JTextField serverPortField = createTextField("8888");
    private final JComboBox<NetworkChoice> serverNetworkCombo = createNetworkCombo();
    private final JSpinner ttlSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 32, 1));
    private final JTextArea messageArea = createTextArea(5);
    private final JButton serverStartButton = createButton("MỞ KÊNH PHÁT", GREEN, new Color(8, 35, 32));
    private final JButton serverStopButton = createButton("DỪNG SERVER", new Color(61, 73, 99), TEXT);
    private final JButton sendButton = createButton("➤  PHÁT THÔNG ĐIỆP", BLUE, Color.WHITE);
    private final JLabel serverStateLabel = createStatusLabel("SERVER ĐANG TẮT", RED);

    private final JTextField clientGroupField = createTextField("230.0.0.1");
    private final JTextField clientPortField = createTextField("8888");
    private final JComboBox<NetworkChoice> clientNetworkCombo = createNetworkCombo();
    private final JButton clientStartButton = createButton("▶  BẮT ĐẦU NHẬN", CYAN, new Color(8, 29, 41));
    private final JButton clientStopButton = createButton("■  DỪNG NHẬN", new Color(61, 73, 99), TEXT);
    private final JLabel clientStateLabel = createStatusLabel("CLIENT ĐANG TẮT", RED);
    private final JTextArea receivedArea = createTextArea(16);
    private final JTextArea activityArea = createTextArea(18);
    private final JLabel headerStateLabel = new JLabel("●  Chưa có kết nối");
    private final JLabel sentCountLabel = new JLabel("ĐÃ PHÁT  0");
    private final JLabel receivedCountLabel = new JLabel("ĐÃ NHẬN  0");

    private volatile MulticastSocket senderSocket;
    private volatile MulticastSocket clientSocket;
    private volatile boolean clientRunning = false;
    private volatile InetAddress activeClientGroup;
    private volatile int activeClientPort;
    private volatile NetworkInterface activeClientNetwork;
    private InetAddress activeServerGroup;
    private int activeServerPort;
    private volatile boolean serverStarting = false;
    private final AtomicLong sentCount = new AtomicLong(0);
    private final AtomicLong receivedCount = new AtomicLong(0);

    public Bai5MulticastNangCap() {
        super("Bai5 Multicast Nang Cap | Java Networking Lab");
        applyLookAndFeel();
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setMinimumSize(new Dimension(1000, 700));
        setSize(1220, 820);
        setLocationRelativeTo(null);
        setContentPane(buildRoot());
        wireEvents();
        updateHeaderStatus();
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                stopServer(false);
                stopClient(false);
                dispose();
            }
        });
    }

    private JPanel buildRoot() {
        JPanel root = new JPanel(new BorderLayout(0, 18));
        root.setBackground(BG);
        root.setBorder(new EmptyBorder(22, 24, 22, 24));
        root.add(buildHeader(), BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabs.setForeground(TEXT);
        tabs.setBackground(BG);
        tabs.setBorder(BorderFactory.createEmptyBorder());
        tabs.addTab("  SERVER / PHÁT TIN  ", buildServerTab());
        tabs.addTab("  CLIENT / NHẬN TIN  ", buildClientTab());
        tabs.addTab("  NHẬT KÝ HOẠT ĐỘNG  ", buildLogTab());
        root.add(tabs, BorderLayout.CENTER);

        JLabel footer = new JLabel("JAVA MULTICAST LAB     •     UDP GROUP COMMUNICATION     •     UTF-8");
        footer.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        footer.setForeground(new Color(104, 124, 157));
        root.add(footer, BorderLayout.SOUTH);
        return root;
    }

    private JPanel buildHeader() {
        GradientPanel header = new GradientPanel(new Color(23, 44, 79), new Color(17, 27, 50));
        header.setLayout(new BorderLayout(18, 0));
        header.setBorder(new EmptyBorder(20, 23, 20, 23));
        header.setPreferredSize(new Dimension(1000, 122));

        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        JLabel eyebrow = new JLabel("BÀI 5  /  LẬP TRÌNH MẠNG JAVA");
        eyebrow.setFont(new Font("Segoe UI", Font.BOLD, 10));
        eyebrow.setForeground(CYAN);
        JLabel title = new JLabel("MULTICAST STUDIO");
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setForeground(TEXT);
        JLabel subtitle = new JLabel("Phát một thông điệp — nhiều máy nhận cùng lúc");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(new Color(185, 201, 228));
        left.add(eyebrow);
        left.add(Box.createVerticalStrut(5));
        left.add(title);
        left.add(Box.createVerticalStrut(3));
        left.add(subtitle);
        header.add(left, BorderLayout.CENTER);

        JPanel right = new JPanel();
        right.setOpaque(false);
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        headerStateLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        headerStateLabel.setForeground(new Color(209, 221, 244));
        headerStateLabel.setAlignmentX(Component.RIGHT_ALIGNMENT);
        JPanel counters = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        counters.setOpaque(false);
        styleCounter(sentCountLabel, CYAN);
        styleCounter(receivedCountLabel, GREEN);
        counters.add(sentCountLabel);
        counters.add(receivedCountLabel);
        right.add(headerStateLabel);
        right.add(counters);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    private JPanel buildServerTab() {
        JPanel outer = new JPanel(new BorderLayout(0, 14));
        outer.setOpaque(false);
        outer.setBorder(new EmptyBorder(18, 2, 2, 2));
        outer.add(sectionHeading("KÊNH PHÁT MULTICAST", "Cấu hình nhóm multicast, sau đó nhập thông điệp để gửi đến tất cả client đang tham gia nhóm."), BorderLayout.NORTH);

        JPanel columns = new JPanel(new GridLayout(1, 2, 15, 0));
        columns.setOpaque(false);
        columns.add(buildServerConfigCard());
        columns.add(buildComposeCard());
        outer.add(columns, BorderLayout.CENTER);
        return outer;
    }

    private JPanel buildServerConfigCard() {
        RoundedPanel card = new RoundedPanel(CARD, BORDER, 18);
        card.setLayout(new BorderLayout(0, 16));
        card.add(cardHeading("01  /  CẤU HÌNH SERVER", "Nhập IP multicast và cổng UDP dùng chung với các máy nhận."), BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        addFormRow(form, 0, "GROUP IP", serverGroupField);
        addFormRow(form, 1, "PORT UDP", serverPortField);
        addFormRow(form, 2, "CARD MẠNG", serverNetworkCombo);
        addFormRow(form, 3, "TTL (phạm vi)", ttlSpinner);

        JPanel body = new JPanel();
        body.setOpaque(false);
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.add(form);
        body.add(Box.createVerticalStrut(14));
        body.add(serverStateLabel);
        body.add(Box.createVerticalStrut(13));

        JPanel actions = new JPanel(new GridLayout(1, 2, 9, 0));
        actions.setOpaque(false);
        serverStartButton.setEnabled(true);
        serverStopButton.setEnabled(false);
        actions.add(serverStartButton);
        actions.add(serverStopButton);
        body.add(actions);
        body.add(Box.createVerticalStrut(18));
        body.add(infoBox("MẸO KẾT NỐI", "Các máy nhận phải nhập đúng Group IP và Port. Nếu demo nhiều máy, chọn card mạng đang kết nối cùng LAN/Wi-Fi và cho phép UDP qua tường lửa."));
        card.add(body, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildComposeCard() {
        RoundedPanel card = new RoundedPanel(CARD, BORDER, 18);
        card.setLayout(new BorderLayout(0, 15));
        card.add(cardHeading("02  /  SOẠN THÔNG ĐIỆP", "Nội dung được mã hóa UTF-8 để hỗ trợ tiếng Việt."), BorderLayout.NORTH);

        JPanel body = new JPanel();
        body.setOpaque(false);
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        JLabel messageLabel = fieldLabel("NỘI DUNG GỬI");
        messageLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(messageLabel);
        body.add(Box.createVerticalStrut(8));
        JScrollPane messageScroll = createScroll(messageArea, 220);
        messageScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(messageScroll);
        body.add(Box.createVerticalStrut(13));
        sendButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        sendButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        sendButton.setEnabled(false);
        body.add(sendButton);
        body.add(Box.createVerticalStrut(18));
        body.add(infoBox("CÁCH DEMO", "1. Mở kênh phát.  2. Mở tab Client trên máy này hoặc máy khác.  3. Nhập cùng Group IP/Port và bấm Bắt đầu nhận.  4. Quay lại đây để phát tin."));
        body.add(Box.createVerticalGlue());
        card.add(body, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildClientTab() {
        JPanel outer = new JPanel(new BorderLayout(0, 14));
        outer.setOpaque(false);
        outer.setBorder(new EmptyBorder(18, 2, 2, 2));
        outer.add(sectionHeading("KÊNH NHẬN MULTICAST", "Mỗi client tham gia cùng nhóm IP và cổng UDP sẽ có thể nhận thông điệp do server phát."), BorderLayout.NORTH);

        JPanel columns = new JPanel(new GridLayout(1, 2, 15, 0));
        columns.setOpaque(false);
        columns.add(buildClientConfigCard());
        columns.add(buildReceivedCard());
        outer.add(columns, BorderLayout.CENTER);
        return outer;
    }

    private JPanel buildClientConfigCard() {
        RoundedPanel card = new RoundedPanel(CARD, BORDER, 18);
        card.setLayout(new BorderLayout(0, 16));
        card.add(cardHeading("01  /  THAM GIA GROUP", "Dùng cùng cấu hình với server phát tin."), BorderLayout.NORTH);
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        addFormRow(form, 0, "GROUP IP", clientGroupField);
        addFormRow(form, 1, "PORT UDP", clientPortField);
        addFormRow(form, 2, "CARD MẠNG", clientNetworkCombo);

        JPanel body = new JPanel();
        body.setOpaque(false);
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.add(form);
        body.add(Box.createVerticalStrut(14));
        body.add(clientStateLabel);
        body.add(Box.createVerticalStrut(13));
        JPanel actions = new JPanel(new GridLayout(1, 2, 9, 0));
        actions.setOpaque(false);
        clientStopButton.setEnabled(false);
        actions.add(clientStartButton);
        actions.add(clientStopButton);
        body.add(actions);
        body.add(Box.createVerticalStrut(18));
        body.add(infoBox("LƯU Ý MẠNG", "Multicast không phải gửi đến IP unicast của một máy. Hãy sử dụng địa chỉ lớp D (224–239). Một số Wi-Fi công cộng hoặc router chặn multicast; khi đó nên thử trên cùng mạng LAN."));
        card.add(body, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildReceivedCard() {
        RoundedPanel card = new RoundedPanel(CARD, BORDER, 18);
        card.setLayout(new BorderLayout(0, 14));
        card.add(cardHeading("02  /  THÔNG ĐIỆP NHẬN ĐƯỢC", "Thông điệp và địa chỉ máy gửi sẽ xuất hiện tại đây."), BorderLayout.NORTH);
        card.add(createScroll(receivedArea, 400), BorderLayout.CENTER);
        JButton clear = createButton("XÓA KHUNG NHẬN", new Color(61, 73, 99), TEXT);
        clear.addActionListener(e -> receivedArea.setText(""));
        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        south.setOpaque(false);
        south.add(clear);
        card.add(south, BorderLayout.SOUTH);
        return card;
    }

    private JPanel buildLogTab() {
        RoundedPanel card = new RoundedPanel(CARD, BORDER, 18);
        card.setLayout(new BorderLayout(0, 14));
        JPanel top = new JPanel(new BorderLayout(12, 0));
        top.setOpaque(false);
        top.add(cardHeading("NHẬT KÝ HỆ THỐNG", "Theo dõi thao tác server, client và lỗi mạng trong quá trình demo."), BorderLayout.CENTER);
        JButton clear = createButton("XÓA NHẬT KÝ", new Color(61, 73, 99), TEXT);
        clear.addActionListener(e -> activityArea.setText(""));
        top.add(clear, BorderLayout.EAST);
        card.add(top, BorderLayout.NORTH);
        card.add(createScroll(activityArea, 500), BorderLayout.CENTER);
        JPanel outer = new JPanel(new BorderLayout());
        outer.setOpaque(false);
        outer.setBorder(new EmptyBorder(18, 2, 2, 2));
        outer.add(card, BorderLayout.CENTER);
        return outer;
    }

    private JPanel sectionHeading(String title, String subtitle) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        JLabel t = new JLabel(title);
        t.setFont(new Font("Segoe UI", Font.BOLD, 17));
        t.setForeground(TEXT);
        JLabel s = new JLabel(subtitle);
        s.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        s.setForeground(MUTED);
        p.add(t);
        p.add(Box.createVerticalStrut(5));
        p.add(s);
        return p;
    }

    private JPanel cardHeading(String title, String subtitle) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        JLabel t = new JLabel(title);
        t.setFont(new Font("Segoe UI", Font.BOLD, 13));
        t.setForeground(TEXT);
        JLabel s = new JLabel("<html><div style='width:340px'>" + escapeHtml(subtitle) + "</div></html>");
        s.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        s.setForeground(MUTED);
        p.add(t);
        p.add(Box.createVerticalStrut(7));
        p.add(s);
        return p;
    }

    private JPanel infoBox(String heading, String text) {
        JPanel box = new JPanel();
        box.setOpaque(true);
        box.setBackground(CARD_ALT);
        box.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1), new EmptyBorder(12, 13, 12, 13)));
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        JLabel h = new JLabel(heading);
        h.setFont(new Font("Segoe UI", Font.BOLD, 10));
        h.setForeground(CYAN);
        JLabel t = new JLabel("<html><div style='width:320px; line-height:1.4'>" + escapeHtml(text) + "</div></html>");
        t.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        t.setForeground(new Color(190, 203, 224));
        box.add(h);
        box.add(Box.createVerticalStrut(6));
        box.add(t);
        box.setAlignmentX(Component.LEFT_ALIGNMENT);
        return box;
    }

    private void addFormRow(JPanel panel, int row, String label, Component input) {
        GridBagConstraints left = new GridBagConstraints();
        left.gridx = 0;
        left.gridy = row;
        left.weightx = 0;
        left.fill = GridBagConstraints.HORIZONTAL;
        left.anchor = GridBagConstraints.WEST;
        left.insets = new Insets(7, 0, 7, 12);
        JLabel l = fieldLabel(label);
        panel.add(l, left);

        GridBagConstraints right = new GridBagConstraints();
        right.gridx = 1;
        right.gridy = row;
        right.weightx = 1;
        right.fill = GridBagConstraints.HORIZONTAL;
        right.anchor = GridBagConstraints.CENTER;
        right.insets = new Insets(7, 0, 7, 0);
        if (input instanceof JSpinner) {
            JSpinner spinner = (JSpinner) input;
            spinner.setPreferredSize(new Dimension(120, 38));
            spinner.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            spinner.setBorder(BorderFactory.createLineBorder(BORDER));
            spinner.setForeground(TEXT);
            spinner.setBackground(INPUT_BG);
            if (spinner.getEditor() instanceof JSpinner.DefaultEditor) {
                JTextField editorField = ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField();
                editorField.setForeground(TEXT);
                editorField.setBackground(INPUT_BG);
                editorField.setCaretColor(CYAN);
                editorField.setBorder(new EmptyBorder(5, 8, 5, 8));
            }
        }
        panel.add(input, right);
    }

    private JLabel fieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 10));
        l.setForeground(MUTED);
        return l;
    }

    private JTextField createTextField(String value) {
        JTextField f = new JTextField(value);
        f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        f.setForeground(TEXT);
        f.setCaretColor(CYAN);
        f.setBackground(INPUT_BG);
        f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER, 1), new EmptyBorder(8, 10, 8, 10)));
        f.setPreferredSize(new Dimension(170, 38));
        return f;
    }

    private JTextArea createTextArea(int rows) {
        JTextArea area = new JTextArea(rows, 24);
        area.setFont(new Font("Consolas", Font.PLAIN, 12));
        area.setForeground(new Color(220, 232, 250));
        area.setBackground(INPUT_BG);
        area.setCaretColor(CYAN);
        area.setSelectionColor(new Color(50, 90, 150));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(new EmptyBorder(10, 11, 10, 11));
        area.setTabSize(4);
        DefaultCaret caret = (DefaultCaret) area.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        return area;
    }

    private JScrollPane createScroll(JTextArea area, int preferredHeight) {
        JScrollPane scroll = new JScrollPane(area);
        scroll.setPreferredSize(new Dimension(400, preferredHeight));
        scroll.setBorder(BorderFactory.createLineBorder(BORDER, 1));
        scroll.getViewport().setBackground(INPUT_BG);
        scroll.getVerticalScrollBar().setUnitIncrement(14);
        return scroll;
    }

    private JButton createButton(String text, Color background, Color foreground) {
        JButton b = new RoundedButton(text, background, foreground);
        b.setFont(new Font("Segoe UI", Font.BOLD, 11));
        b.setPreferredSize(new Dimension(150, 42));
        b.setFocusable(false);
        return b;
    }

    private JLabel createStatusLabel(String text, Color color) {
        JLabel label = new JLabel("●  " + text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 11));
        label.setForeground(color);
        label.setBorder(new EmptyBorder(0, 2, 0, 0));
        return label;
    }

    private void styleCounter(JLabel label, Color color) {
        label.setFont(new Font("Segoe UI", Font.BOLD, 10));
        label.setForeground(color);
        label.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(color.getRed(), color.getGreen(), color.getBlue(), 90), 1),
                new EmptyBorder(6, 9, 6, 9)));
    }

    private JComboBox<NetworkChoice> createNetworkCombo() {
        JComboBox<NetworkChoice> combo = new JComboBox<>();
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        combo.setForeground(TEXT);
        combo.setBackground(INPUT_BG);
        combo.setBorder(BorderFactory.createLineBorder(BORDER));
        combo.addItem(new NetworkChoice(null, "Tự động (theo hệ điều hành)"));
        for (NetworkInterface ni : getAvailableMulticastInterfaces()) {
            combo.addItem(new NetworkChoice(ni, ni.getDisplayName() + "  [" + ni.getName() + "]"));
        }
        combo.setRenderer((list, value, index, isSelected, cellHasFocus) -> {
            JLabel label = new JLabel(value == null ? "Tự động" : value.label);
            label.setOpaque(true);
            label.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            label.setBorder(new EmptyBorder(6, 7, 6, 7));
            label.setBackground(isSelected ? new Color(45, 68, 105) : INPUT_BG);
            label.setForeground(TEXT);
            return label;
        });
        return combo;
    }

    private List<NetworkInterface> getAvailableMulticastInterfaces() {
        List<NetworkInterface> result = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces != null && interfaces.hasMoreElements()) {
                NetworkInterface ni = interfaces.nextElement();
                try {
                    if (ni.isUp() && !ni.isLoopback() && ni.supportsMulticast()) {
                        result.add(ni);
                    }
                } catch (SocketException ignored) {
                    // Bo qua card mang khong doc duoc trang thai.
                }
            }
        } catch (SocketException | SecurityException ignored) {
            // Lua chon tu dong van hoat dong neu he dieu hanh cho phep.
        }
        return result;
    }

    private NetworkInterface selectedNetwork(JComboBox<NetworkChoice> combo) {
        Object selected = combo.getSelectedItem();
        if (selected instanceof NetworkChoice) {
            return ((NetworkChoice) selected).networkInterface;
        }
        return null;
    }

    private void wireEvents() {
        serverStartButton.addActionListener(e -> startServer());
        serverStopButton.addActionListener(e -> stopServer(true));
        sendButton.addActionListener(e -> sendMessage());
        clientStartButton.addActionListener(e -> startClient());
        clientStopButton.addActionListener(e -> stopClient(true));
    }

    private void startServer() {
        if (senderSocket != null && !senderSocket.isClosed()) {
            appendLog("SERVER", "Kênh phát đang hoạt động.");
            return;
        }
        if (serverStarting) return;

        final InetAddress group;
        final int port;
        final int ttl;
        final NetworkInterface nic = selectedNetwork(serverNetworkCombo);
        try {
            group = parseMulticastIPv4(serverGroupField.getText());
            port = parsePort(serverPortField.getText());
            ttl = ((Number) ttlSpinner.getValue()).intValue();
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
            return;
        }

        serverStarting = true;
        serverStartButton.setEnabled(false);
        serverStateLabel.setText("●  ĐANG MỞ KÊNH PHÁT...");
        serverStateLabel.setForeground(CYAN);
        appendLog("SERVER", "Đang mở kênh phát tới " + group.getHostAddress() + ":" + port + "...");

        Thread worker = new Thread(() -> {
            MulticastSocket socket = null;
            try {
                socket = new MulticastSocket();
                if (nic != null) socket.setNetworkInterface(nic);
                socket.setTimeToLive(ttl);
                senderSocket = socket;
                activeServerGroup = group;
                activeServerPort = port;
                final String nicName = nic == null ? "Tự động" : nic.getDisplayName();
                appendLog("SERVER", "Đã mở kênh phát | Group=" + group.getHostAddress() + " | Port=" + port + " | TTL=" + ttl + " | Card=" + nicName);
                SwingUtilities.invokeLater(() -> {
                    serverStarting = false;
                    serverStartButton.setEnabled(false);
                    serverStopButton.setEnabled(true);
                    sendButton.setEnabled(true);
                    serverStateLabel.setText("●  SERVER SẴN SÀNG");
                    serverStateLabel.setForeground(GREEN);
                    updateHeaderStatus();
                });
            } catch (Exception ex) {
                if (socket != null) socket.close();
                senderSocket = null;
                appendLog("LỖI SERVER", safeMessage(ex));
                SwingUtilities.invokeLater(() -> {
                    serverStarting = false;
                    serverStartButton.setEnabled(true);
                    serverStopButton.setEnabled(false);
                    sendButton.setEnabled(false);
                    serverStateLabel.setText("●  KHÔNG MỞ ĐƯỢC SERVER");
                    serverStateLabel.setForeground(RED);
                    updateHeaderStatus();
                    showError("Không thể mở kênh phát: " + safeMessage(ex));
                });
            }
        }, "Multicast-Server-Start");
        worker.setDaemon(true);
        worker.start();
    }

    private void stopServer(boolean writeLog) {
        MulticastSocket socket = senderSocket;
        senderSocket = null;
        if (socket != null) socket.close();
        serverStarting = false;
        if (serverStartButton != null) {
            serverStartButton.setEnabled(true);
            serverStopButton.setEnabled(false);
            sendButton.setEnabled(false);
            serverStateLabel.setText("●  SERVER ĐANG TẮT");
            serverStateLabel.setForeground(RED);
            updateHeaderStatus();
        }
        if (writeLog && socket != null) appendLog("SERVER", "Đã dừng kênh phát.");
    }

    private void sendMessage() {
        MulticastSocket socket = senderSocket;
        if (socket == null || socket.isClosed() || activeServerGroup == null) {
            showError("Hãy mở kênh phát trước khi gửi thông điệp.");
            return;
        }
        String message = messageArea.getText();
        if (message == null || message.trim().isEmpty()) {
            showError("Nội dung thông điệp đang trống.");
            messageArea.requestFocusInWindow();
            return;
        }
        byte[] data = message.getBytes(StandardCharsets.UTF_8);
        if (data.length > 60000) {
            showError("Thông điệp quá lớn. Hãy giữ nội dung dưới 60.000 byte để tránh vượt giới hạn UDP.");
            return;
        }
        final InetAddress group = activeServerGroup;
        final int port = activeServerPort;
        sendButton.setEnabled(false);
        Thread worker = new Thread(() -> {
            try {
                DatagramPacket packet = new DatagramPacket(data, data.length, group, port);
                socket.send(packet);
                long total = sentCount.incrementAndGet();
                appendLog("ĐÃ PHÁT", "Tới " + group.getHostAddress() + ":" + port + " | " + data.length + " byte | Nội dung: " + oneLine(message));
                SwingUtilities.invokeLater(() -> {
                    sentCountLabel.setText("ĐÃ PHÁT  " + total);
                    sendButton.setEnabled(senderSocket != null && !senderSocket.isClosed());
                    updateHeaderStatus();
                });
            } catch (Exception ex) {
                appendLog("LỖI GỬI", safeMessage(ex));
                SwingUtilities.invokeLater(() -> {
                    sendButton.setEnabled(senderSocket != null && !senderSocket.isClosed());
                    showError("Gửi thông điệp thất bại: " + safeMessage(ex));
                });
            }
        }, "Multicast-Send");
        worker.setDaemon(true);
        worker.start();
    }

    private void startClient() {
        if (clientSocket != null && !clientSocket.isClosed()) {
            appendLog("CLIENT", "Client đang nhận dữ liệu.");
            return;
        }
        final InetAddress group;
        final int port;
        final NetworkInterface nic = selectedNetwork(clientNetworkCombo);
        try {
            group = parseMulticastIPv4(clientGroupField.getText());
            port = parsePort(clientPortField.getText());
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
            return;
        }

        clientStartButton.setEnabled(false);
        clientStateLabel.setText("●  ĐANG THAM GIA GROUP...");
        clientStateLabel.setForeground(CYAN);
        appendLog("CLIENT", "Đang tham gia Group=" + group.getHostAddress() + ", Port=" + port + "...");

        Thread worker = new Thread(() -> {
            MulticastSocket socket = null;
            try {
                socket = new MulticastSocket(null);
                socket.setReuseAddress(true);
                socket.bind(new InetSocketAddress(port));
                if (nic != null) {
                    socket.setNetworkInterface(nic);
                    socket.joinGroup(new InetSocketAddress(group, port), nic);
                } else {
                    socket.joinGroup(group);
                }
                activeClientGroup = group;
                activeClientPort = port;
                activeClientNetwork = nic;
                clientSocket = socket;
                clientRunning = true;
                MulticastSocket activeSocket = socket;
                String nicName = nic == null ? "Tự động" : nic.getDisplayName();
                appendLog("CLIENT", "Đã tham gia group | Group=" + group.getHostAddress() + " | Port=" + port + " | Card=" + nicName);
                SwingUtilities.invokeLater(() -> {
                    clientStartButton.setEnabled(false);
                    clientStopButton.setEnabled(true);
                    clientStateLabel.setText("●  ĐANG NHẬN TIN");
                    clientStateLabel.setForeground(GREEN);
                    updateHeaderStatus();
                });
                receiveLoop(activeSocket);
            } catch (Exception ex) {
                clientRunning = false;
                if (socket != null) socket.close();
                if (clientSocket == socket) clientSocket = null;
                appendLog("LỖI CLIENT", safeMessage(ex));
                SwingUtilities.invokeLater(() -> {
                    clientStartButton.setEnabled(true);
                    clientStopButton.setEnabled(false);
                    clientStateLabel.setText("●  KHÔNG THAM GIA ĐƯỢC");
                    clientStateLabel.setForeground(RED);
                    updateHeaderStatus();
                    showError("Không thể tham gia nhóm multicast: " + safeMessage(ex)
                            + "\nHãy kiểm tra Group IP, Port và card mạng.");
                });
            }
        }, "Multicast-Client-Receiver");
        worker.setDaemon(true);
        worker.start();
    }

    private void receiveLoop(MulticastSocket socket) {
        byte[] buffer = new byte[65507];
        try {
            while (clientRunning && !socket.isClosed()) {
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                socket.receive(packet);
                String message = new String(packet.getData(), packet.getOffset(), packet.getLength(), StandardCharsets.UTF_8);
                long total = receivedCount.incrementAndGet();
                String line = "[" + timestamp() + "] " + packet.getAddress().getHostAddress() + ":" + packet.getPort() + "  →  " + message;
                SwingUtilities.invokeLater(() -> {
                    receivedArea.append(line + "\n\n");
                    receivedCountLabel.setText("ĐÃ NHẬN  " + total);
                    updateHeaderStatus();
                });
                appendLog("ĐÃ NHẬN", "Từ " + packet.getAddress().getHostAddress() + ":" + packet.getPort() + " | " + packet.getLength() + " byte | " + oneLine(message));
            }
        } catch (SocketException ex) {
            if (clientRunning && !socket.isClosed()) {
                appendLog("LỖI SOCKET CLIENT", safeMessage(ex));
            }
        } catch (Exception ex) {
            if (clientRunning) appendLog("LỖI NHẬN", safeMessage(ex));
        } finally {
            if (clientSocket == socket) {
                clientSocket = null;
                clientRunning = false;
                SwingUtilities.invokeLater(() -> {
                    clientStartButton.setEnabled(true);
                    clientStopButton.setEnabled(false);
                    clientStateLabel.setText("●  CLIENT ĐANG TẮT");
                    clientStateLabel.setForeground(RED);
                    updateHeaderStatus();
                });
            }
        }
    }

    private void stopClient(boolean writeLog) {
        MulticastSocket socket = clientSocket;
        clientRunning = false;
        clientSocket = null;
        if (socket != null) {
            try {
                InetAddress group = activeClientGroup;
                int port = activeClientPort;
                NetworkInterface nic = activeClientNetwork;
                if (group != null && !socket.isClosed()) {
                    if (nic != null) socket.leaveGroup(new InetSocketAddress(group, port), nic);
                    else socket.leaveGroup(group);
                }
            } catch (Exception ignored) {
                // Dong socket ben duoi van ket thuc vong lap nhan.
            }
            socket.close();
        }
        if (clientStartButton != null) {
            clientStartButton.setEnabled(true);
            clientStopButton.setEnabled(false);
            clientStateLabel.setText("●  CLIENT ĐANG TẮT");
            clientStateLabel.setForeground(RED);
            updateHeaderStatus();
        }
        if (writeLog && socket != null) appendLog("CLIENT", "Đã dừng nhận multicast.");
    }

    private InetAddress parseMulticastIPv4(String value) {
        String text = value == null ? "" : value.trim();
        String[] parts = text.split("\\.", -1);
        if (parts.length != 4) {
            throw new IllegalArgumentException("Group IP phải là địa chỉ IPv4 multicast, ví dụ 230.0.0.1 (dải 224.0.0.0–239.255.255.255).");
        }
        byte[] bytes = new byte[4];
        int first = -1;
        for (int i = 0; i < 4; i++) {
            if (parts[i].isEmpty() || !parts[i].matches("\\d{1,3}")) {
                throw new IllegalArgumentException("Địa chỉ IP không đúng định dạng IPv4.");
            }
            int part;
            try {
                part = Integer.parseInt(parts[i]);
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException("Địa chỉ IP không hợp lệ.");
            }
            if (part < 0 || part > 255) throw new IllegalArgumentException("Mỗi phần của IPv4 phải nằm trong khoảng 0–255.");
            if (i == 0) first = part;
            bytes[i] = (byte) part;
        }
        if (first < 224 || first > 239) {
            throw new IllegalArgumentException("IP " + text + " không phải multicast. Hãy dùng địa chỉ lớp D từ 224.0.0.0 đến 239.255.255.255.");
        }
        try {
            return InetAddress.getByAddress(bytes);
        } catch (Exception ex) {
            throw new IllegalArgumentException("Không thể chuyển đổi địa chỉ multicast.");
        }
    }

    private int parsePort(String value) {
        int port;
        try {
            port = Integer.parseInt(value.trim());
        } catch (Exception ex) {
            throw new IllegalArgumentException("Port phải là số nguyên từ 1 đến 65535.");
        }
        if (port < 1 || port > 65535) throw new IllegalArgumentException("Port phải nằm trong khoảng 1–65535.");
        return port;
    }

    private void appendLog(String tag, String message) {
        String line = "[" + timestamp() + "] [" + tag + "] " + message + "\n";
        SwingUtilities.invokeLater(() -> activityArea.append(line));
    }

    private String timestamp() {
        return new SimpleDateFormat("HH:mm:ss").format(new Date());
    }

    private String oneLine(String value) {
        return value == null ? "" : value.replace("\r", " ").replace("\n", " ⏎ ").trim();
    }

    private String safeMessage(Exception ex) {
        String message = ex.getMessage();
        return message == null || message.trim().isEmpty() ? ex.getClass().getSimpleName() : message;
    }

    private void showError(String message) {
        javax.swing.JOptionPane.showMessageDialog(this, message, "Multicast Studio", javax.swing.JOptionPane.WARNING_MESSAGE);
    }

    private void updateHeaderStatus() {
        boolean serverOn = senderSocket != null && !senderSocket.isClosed();
        boolean clientOn = clientSocket != null && !clientSocket.isClosed() && clientRunning;
        if (serverOn && clientOn) {
            headerStateLabel.setText("●  Server và Client đang hoạt động");
            headerStateLabel.setForeground(GREEN);
        } else if (serverOn) {
            headerStateLabel.setText("●  Server đang hoạt động");
            headerStateLabel.setForeground(CYAN);
        } else if (clientOn) {
            headerStateLabel.setText("●  Client đang nhận tin");
            headerStateLabel.setForeground(GREEN);
        } else {
            headerStateLabel.setText("●  Chưa có kết nối");
            headerStateLabel.setForeground(new Color(209, 221, 244));
        }
    }

    private static String escapeHtml(String text) {
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private void applyLookAndFeel() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
        }
        UIManager.put("TabbedPane.background", BG);
        UIManager.put("TabbedPane.foreground", TEXT);
        UIManager.put("TabbedPane.selected", CARD_ALT);
        UIManager.put("TabbedPane.contentAreaColor", BG);
        UIManager.put("TabbedPane.focus", BG);
        UIManager.put("ScrollBar.thumb", BORDER);
        UIManager.put("ScrollBar.track", INPUT_BG);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai5MulticastNangCap().setVisible(true));
    }

    private static class NetworkChoice {
        private final NetworkInterface networkInterface;
        private final String label;
        private NetworkChoice(NetworkInterface networkInterface, String label) {
            this.networkInterface = networkInterface;
            this.label = label;
        }
        @Override
        public String toString() { return label; }
    }

    private static class RoundedPanel extends JPanel {
        private final Color fill;
        private final Color outline;
        private final int arc;
        RoundedPanel(Color fill, Color outline, int arc) {
            this.fill = fill;
            this.outline = outline;
            this.arc = arc;
            setOpaque(false);
            setBorder(new EmptyBorder(19, 19, 19, 19));
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
            g2.setColor(outline);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private static class GradientPanel extends JPanel {
        private final Color first;
        private final Color second;
        GradientPanel(Color first, Color second) {
            this.first = first;
            this.second = second;
            setOpaque(false);
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setPaint(new GradientPaint(0, 0, first, getWidth(), getHeight(), second));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);
            g2.setColor(new Color(78, 113, 167, 90));
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 24, 24);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private static class RoundedButton extends JButton {
        private final Color base;
        private final Color foregroundColor;
        RoundedButton(String text, Color base, Color foregroundColor) {
            super(text);
            this.base = base;
            this.foregroundColor = foregroundColor;
            setForeground(foregroundColor);
            setBackground(base);
            setBorder(new EmptyBorder(11, 13, 11, 13));
            setContentAreaFilled(false);
            setOpaque(false);
            setFocusPainted(false);
            setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color paint = base;
            if (!isEnabled()) paint = new Color(base.getRed(), base.getGreen(), base.getBlue(), 100);
            else if (getModel().isPressed()) paint = base.darker();
            else if (getModel().isRollover()) paint = base.brighter();
            g2.setColor(paint);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            g2.dispose();
            setForeground(isEnabled() ? foregroundColor : new Color(foregroundColor.getRed(), foregroundColor.getGreen(), foregroundColor.getBlue(), 150));
            super.paintComponent(g);
        }
    }
}
