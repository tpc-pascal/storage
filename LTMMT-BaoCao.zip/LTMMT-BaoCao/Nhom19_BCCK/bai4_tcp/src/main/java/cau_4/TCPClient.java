package cau_4;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

/**
 * ỨNG DỤNG GUI — TCP CLIENT (Giao diện hiện đại)
 * - Kết nối / ngắt kết nối tới server
 * - Gửi tin nhắn, nhận log
 * - Status bar đổi màu theo trạng thái
 *
 * @author tpc-pascal
 */
public class TCPClient extends JFrame {

    // ===== BẢNG MÀU =====
    private static final Color PRIMARY   = new Color(0x2563EB);
    private static final Color SUCCESS   = new Color(0x16A34A);
    private static final Color DANGER    = new Color(0xDC2626);
    private static final Color WARNING   = new Color(0xD97706);
    private static final Color BG        = new Color(0xF8FAFC);
    private static final Color CARD_BG   = Color.WHITE;
    private static final Color TEXT_MUTED= new Color(0x64748B);
    private static final Color BORDER_C  = new Color(0xE2E8F0);

    // ===== FONT =====
    private static final Font FONT_TITLE  = new Font("Segoe UI", Font.BOLD, 18);
    private static final Font FONT_SUB    = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font FONT_LABEL  = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_INPUT  = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 13);
    private static final Font FONT_LOG    = new Font("JetBrains Mono", Font.PLAIN, 12);

    // ===== TRẠNG THÁI =====
    private static final String HOST = "localhost";
    private static final int PORT = 5000;

    private Socket socket;
    private PrintWriter out;
    private boolean connected = false;

    // ===== COMPONENTS =====
    private final JTextField txtHost = new JTextField(HOST, 15);
    private final JTextField txtPort = new JTextField(String.valueOf(PORT), 6);
    private final JTextField txtMsg  = new JTextField(30);
    private final JTextArea  log     = new JTextArea(14, 60);
    private final JLabel     lblStatus = new JLabel(" Chưa kết nối");
    private final JLabel     lblBadge  = new JLabel("● Offline");
    private JButton btnConnect, btnDisconnect, btnSend;

    public TCPClient() {
        super("TCP Client");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(880, 680);
        setMinimumSize(new Dimension(780, 600));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(BG);
        setContentPane(root);

        // ===== HEADER =====
        root.add(buildHeader(), BorderLayout.NORTH);

        // ===== BODY =====
        JPanel body = new JPanel(new BorderLayout(0, 12));
        body.setBackground(BG);
        body.setBorder(new EmptyBorder(16, 16, 16, 16));

        body.add(buildConnectCard(), BorderLayout.NORTH);
        body.add(buildChatCard(), BorderLayout.CENTER);

        root.add(body, BorderLayout.CENTER);

        // ===== STATUS BAR =====
        root.add(buildStatusBar(), BorderLayout.SOUTH);

        // Đóng kết nối khi thoát
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) { disconnect(); }
        });
    }

    // ============================================================
    // HEADER
    // ============================================================
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(PRIMARY);
        header.setBorder(new EmptyBorder(14, 20, 14, 20));

        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setOpaque(false);

        JLabel title = new JLabel("💬  TCP CLIENT");
        title.setFont(FONT_TITLE);
        title.setForeground(Color.WHITE);

        JLabel sub = new JLabel("Gửi tin nhắn tới server qua Socket TCP");
        sub.setFont(FONT_SUB);
        sub.setForeground(new Color(0xDBEAFE));

        left.add(title);
        left.add(Box.createVerticalStrut(2));
        left.add(sub);

        lblBadge.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblBadge.setForeground(Color.WHITE);
        lblBadge.setBorder(new EmptyBorder(8, 16, 8, 16));
        lblBadge.setOpaque(true);
        lblBadge.setBackground(new Color(0x64748B));
        lblBadge.setHorizontalAlignment(SwingConstants.CENTER);

        header.add(left, BorderLayout.WEST);
        header.add(lblBadge, BorderLayout.EAST);
        return header;
    }

    // ============================================================
    // CARD KẾT NỐI
    // ============================================================
    private JPanel buildConnectCard() {
        JPanel card = makeCard("Kết nối tới server", "Nhập host và port, bấm Kết nối");

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 4, 4, 4);
        g.anchor = GridBagConstraints.WEST;
        g.fill = GridBagConstraints.HORIZONTAL;

        // Host
        g.gridy = 0; g.gridx = 0; g.weightx = 0; g.gridwidth = 1;
        JLabel lblHost = new JLabel("Host:");
        lblHost.setFont(FONT_LABEL);
        lblHost.setPreferredSize(new Dimension(60, 24));
        form.add(lblHost, g);

        styleInput(txtHost);
        g.gridx = 1; g.weightx = 1; form.add(txtHost, g);

        // Port
        g.gridx = 2; g.weightx = 0;
        JLabel lblPort = new JLabel("Port:");
        lblPort.setFont(FONT_LABEL);
        lblPort.setBorder(new EmptyBorder(0, 12, 0, 0));
        lblPort.setPreferredSize(new Dimension(70, 24));
        form.add(lblPort, g);

        styleInput(txtPort);
        g.gridx = 3; g.weightx = 0; form.add(txtPort, g);

        // Nút
        btnConnect = btn("🔌 Kết nối", SUCCESS, e -> connect());
        btnDisconnect = btn("⛔ Ngắt", DANGER, e -> disconnect());
        btnDisconnect.setEnabled(false);

        g.gridx = 4; g.weightx = 0; g.insets = new Insets(4, 12, 4, 4); form.add(btnConnect, g);
        g.gridx = 5; g.insets = new Insets(4, 4, 4, 4); form.add(btnDisconnect, g);

        card.add(form, BorderLayout.CENTER);
        return card;
    }

    // ============================================================
    // CARD CHAT
    // ============================================================
    private JPanel buildChatCard() {
        JPanel card = makeCard("Tin nhắn", "Nhập nội dung và bấm Gửi");

        // Log
        log.setEditable(false);
        log.setFont(FONT_LOG);
        log.setBackground(new Color(0x0F172A));
        log.setForeground(new Color(0xE2E8F0));
        log.setCaretColor(Color.WHITE);
        log.setBorder(new EmptyBorder(10, 12, 10, 12));
        log.setText("Chào mừng! Nhập host/port và bấm Kết nối để bắt đầu.\n");

        JScrollPane sp = new JScrollPane(log);
        sp.setBorder(new LineBorder(BORDER_C, 1, true));
        sp.setPreferredSize(new Dimension(0, 300));

        // Input
        JPanel inputPanel = new JPanel(new BorderLayout(8, 0));
        inputPanel.setOpaque(false);
        inputPanel.setBorder(new EmptyBorder(10, 0, 0, 0));

        styleInput(txtMsg);
        txtMsg.setPreferredSize(new Dimension(0, 36));
        txtMsg.setEnabled(false);
        txtMsg.addActionListener(e -> send());

        btnSend = btn("📤 Gửi", PRIMARY, e -> send());
        btnSend.setPreferredSize(new Dimension(110, 36));
        btnSend.setEnabled(false);

        inputPanel.add(txtMsg, BorderLayout.CENTER);
        inputPanel.add(btnSend, BorderLayout.EAST);

        card.add(sp, BorderLayout.CENTER);
        card.add(inputPanel, BorderLayout.SOUTH);
        return card;
    }

    // ============================================================
    // STATUS BAR
    // ============================================================
    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(new Color(0xF1F5F9));
        bar.setBorder(new MatteBorder(1, 0, 0, 0, BORDER_C));

        lblStatus.setFont(FONT_SUB);
        lblStatus.setForeground(TEXT_MUTED);
        lblStatus.setBorder(new EmptyBorder(8, 16, 8, 16));

        JLabel lblHint = new JLabel("Java Swing · TCP Socket");
        lblHint.setFont(FONT_SUB);
        lblHint.setForeground(TEXT_MUTED);
        lblHint.setBorder(new EmptyBorder(8, 16, 8, 16));

        bar.add(lblStatus, BorderLayout.WEST);
        bar.add(lblHint, BorderLayout.EAST);
        return bar;
    }

    // ============================================================
    // HELPER: CARD BO TRÒN
    // ============================================================
    private JPanel makeCard(String title, String subtitle) {
        JPanel card = new JPanel(new BorderLayout(0, 12)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 15));
                g2.fillRoundRect(2, 3, getWidth() - 4, getHeight() - 4, 16, 16);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
                g2.setColor(BORDER_C);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(16, 18, 16, 18));

        JPanel head = new JPanel();
        head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
        head.setOpaque(false);

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTitle.setForeground(new Color(0x1E293B));

        JLabel lblSub = new JLabel(subtitle);
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblSub.setForeground(TEXT_MUTED);

        head.add(lblTitle);
        head.add(lblSub);
        card.add(head, BorderLayout.NORTH);
        return card;
    }

    // ============================================================
    // HELPER: NÚT BO TRÒN
    // ============================================================
    private JButton btn(String text, Color bg, ActionListener l) {
        JButton b = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                Color c = isEnabled() ? bg : new Color(0x94A3B8);
                if (getModel().isRollover() && isEnabled()) c = c.darker();
                if (getModel().isPressed() && isEnabled()) c = c.darker().darker();
                g2.setColor(c);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        b.setFont(FONT_BUTTON);
        b.setForeground(Color.WHITE);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(120, 34));
        b.addActionListener(l);
        return b;
    }

    // ============================================================
    // HELPER: STYLE INPUT
    // ============================================================
    private void styleInput(JTextField f) {
        f.setFont(FONT_INPUT);
        f.setPreferredSize(new Dimension(0, 32));
        f.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER_C, 1, true),
                new EmptyBorder(4, 10, 4, 10)));
    }

    // ============================================================
    // KẾT NỐI
    // ============================================================
    private void connect() {
        if (connected) return;
        String host = txtHost.getText().trim();
        int port;
        try {
            port = Integer.parseInt(txtPort.getText().trim());
        } catch (NumberFormatException e) {
            log("❌ Port không hợp lệ");
            status("Port không hợp lệ", DANGER);
            return;
        }

        try {
            socket = new Socket(host, port);
            out = new PrintWriter(socket.getOutputStream(), true);
            connected = true;

            log("✅ Đã kết nối tới " + host + ":" + port);
            status("Đã kết nối tới " + host + ":" + port, SUCCESS);
            updateBadge(true);

            btnConnect.setEnabled(false);
            btnDisconnect.setEnabled(true);
            txtMsg.setEnabled(true);
            btnSend.setEnabled(true);
            txtHost.setEnabled(false);
            txtPort.setEnabled(false);
            txtMsg.requestFocus();

        } catch (IOException ex) {
            log("❌ Không thể kết nối: " + ex.getMessage());
            status("Kết nối thất bại", DANGER);
        }
    }

    // ============================================================
    // NGẮT KẾT NỐI
    // ============================================================
    private void disconnect() {
        if (!connected) return;
        try {
            if (out != null) { out.println("exit"); out.flush(); }
            if (socket != null) socket.close();
        } catch (IOException ignored) {}
        connected = false;
        log("⛔ Đã ngắt kết nối.");
        status("Đã ngắt kết nối", WARNING);
        updateBadge(false);

        btnConnect.setEnabled(true);
        btnDisconnect.setEnabled(false);
        txtMsg.setEnabled(false);
        btnSend.setEnabled(false);
        txtHost.setEnabled(true);
        txtPort.setEnabled(true);
    }

    // ============================================================
    // GỬI
    // ============================================================
    private void send() {
        if (!connected || out == null) return;
        String msg = txtMsg.getText().trim();
        if (msg.isEmpty()) return;
        out.println(msg);
        log("➤ Bạn: " + msg);
        txtMsg.setText("");
        if (msg.equalsIgnoreCase("exit")) {
            disconnect();
        }
    }

    // ============================================================
    // CẬP NHẬT BADGE
    // ============================================================
    private void updateBadge(boolean online) {
        if (online) {
            lblBadge.setText("● Online");
            lblBadge.setBackground(SUCCESS);
        } else {
            lblBadge.setText("● Offline");
            lblBadge.setBackground(new Color(0x64748B));
        }
    }

    // ============================================================
    // LOG + STATUS
    // ============================================================
    private void log(String s) {
        log.append(s + "\n");
        log.setCaretPosition(log.getDocument().getLength());
    }

    private void status(String msg, Color c) {
        lblStatus.setText("  " + msg);
        lblStatus.setForeground(c);
    }

    // ============================================================
    // MAIN
    // ============================================================
    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
            UIManager.put("control", BG);
            UIManager.put("nimbusBase", PRIMARY);
            UIManager.put("nimbusFocus", PRIMARY);
            UIManager.put("text", new Color(0x1E293B));
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> new TCPClient().setVisible(true));
    }
}