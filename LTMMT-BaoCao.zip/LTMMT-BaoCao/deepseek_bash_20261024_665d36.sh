set -e
TMPVENV=$(mktemp -d)/venv
python3 -m venv "$TMPVENV"
"$TMPVENV/bin/pip" install --quiet python-docx
cat > /tmp/gen_ck.py << "PYEOF"
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()
s = doc.styles["Normal"]; s.font.name = "Times New Roman"; s.font.size = Pt(13)

def h1(t): doc.add_heading(t, level=1)
def h2(t): doc.add_heading(t, level=2)
def h3(t): doc.add_heading(t, level=3)
def p(t, style=None): doc.add_paragraph(t, style=style)
def code(t): doc.add_paragraph(t, style="Intense Quote")
def bullet(t): p(t, style="List Bullet")
def num(t): p(t, style="List Number")

title = doc.add_heading("LẬP TRÌNH MẠNG MÁY TÍNH", level=0)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.add_paragraph("")
doc.add_paragraph("BÁO CÁO THỰC HÀNH CUỐI KỲ").alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.add_paragraph("")
for k, v in [("Sinh viên thực hiện:", "[Họ tên – MSSV – Lớp]"),
             ("Giảng viên hướng dẫn:", "[Tên GV]"),
             ("Thời gian thực hiện:", "[Tháng/Năm]")]:
    par = doc.add_paragraph(); par.add_run(k + " ").bold = True; par.add_run(v)
doc.add_page_break()

h1("MỤC LỤC")
for item in [
    "1. Đặt vấn đề", "2. Mục tiêu báo cáo",
    "3. Chương 1: Xử lý tệp nhị phân và văn bản trong Java (GUI hiện đại)",
    "4. Chương 2: Scanner và PrintWriter trong xử lý nhập/xuất định dạng (GUI hiện đại)",
    "5. Chương 3: Đồng bộ hóa (Synchronization) trong Java",
    "6. Chương 4: Lập trình Socket TCP với Java",
    "7. Chương 5: Multicast trong Java và MulticastSocket",
    "8. Chương 6: Kỹ thuật RMI (Remote Method Invocation)",
    "9. Kết luận và hướng phát triển", "10. Tài liệu tham khảo",
    "11. Phụ lục: Câu hỏi ôn tập",
]: num(item)
doc.add_page_break()

# 1
h1("1. ĐẶT VẤN ĐỀ")
p("Trong lập trình ứng dụng thực tế, việc xử lý tệp tin, nhập/xuất dữ liệu, đồng bộ hóa đa luồng và giao tiếp mạng là những kỹ năng cốt lõi mà mọi lập trình viên Java cần nắm vững. Java cung cấp một hệ sinh thái thư viện mạnh mẽ (java.io, java.nio, java.net, java.rmi, java.util.concurrent...) cho phép xây dựng các ứng dụng từ đơn giản đến phức tạp.")
p("Báo cáo này trình bày 6 chủ đề thực hành trọng tâm. Điểm khác biệt so với bản trước: Chương 1 và Chương 2 không dừng ở mức demo dòng lệnh mà được nâng cấp thành **hai ứng dụng GUI riêng biệt** dùng Swing với giao diện hiện đại — card bo tròn, badge màu, header gradient, nút hover, status bar đổi màu theo trạng thái. Mỗi ứng dụng nằm trong một package riêng, chạy độc lập trên Apache NetBeans.")
p("Bố cục báo cáo gồm 6 chương tương ứng với 6 chủ đề, kết luận và phụ lục câu hỏi ôn tập. Mỗi chương được trình bày theo cấu trúc: Cơ sở lý thuyết → Phân tích → Demo/Ứng dụng → Kết quả thực nghiệm → Nhận xét → Ứng dụng thực tế.")

# 2
h1("2. MỤC TIÊU BÁO CÁO")
for m in [
    "Hiểu và vận dụng được cơ chế đọc/ghi tệp nhị phân và văn bản trong Java; xây dựng được **ứng dụng GUI hiện đại** chia/ghép tệp có kiểm tra toàn vẹn bằng MD5/SHA-256.",
    "Sử dụng thành thạo Scanner, PrintWriter để nhập/xuất dữ liệu có định dạng (CSV); xây dựng được **ứng dụng GUI hiện đại** quản lý nhân viên hoàn chỉnh.",
    "Nắm được cơ chế đồng bộ hóa trong đa luồng và hậu quả của race condition.",
    "Xây dựng được ứng dụng Client–Server qua Socket TCP.",
    "Hiểu và triển khai được Multicast UDP trong Java.",
    "Nắm được kiến trúc RMI và triển khai được lời gọi phương thức từ xa.",
]: bullet(m)
doc.add_page_break()

# ============ CHƯƠNG 1 (GUI HIỆN ĐẠI) ============
h1("CHƯƠNG 1: XỬ LÝ TỆP NHỊ PHÂN VÀ VĂN BẢN TRONG JAVA (GUI HIỆN ĐẠI)")
h2("1.1. Cơ sở lý thuyết")
h3("1.1.1. Khái niệm tệp nhị phân và văn bản")
p("Tệp nhị phân lưu trữ dữ liệu dưới dạng byte, không có mã hóa ký tự. Ví dụ: ảnh, PDF, âm thanh, video, file nén.")
p("Tệp văn bản lưu trữ dữ liệu dưới dạng ký tự, có mã hóa (UTF-8, ASCII...). Ví dụ: .txt, .csv, .json, .xml.")
h3("1.1.2. Phân loại luồng tệp")
t = doc.add_table(rows=1, cols=4); t.style = "Table Grid"
h = t.rows[0].cells
h[0].text="Loại"; h[1].text="Lớp cơ sở"; h[2].text="Đơn vị"; h[3].text="Ứng dụng"
for r in [
    ("Nhị phân (byte)", "InputStream / OutputStream", "byte (8-bit)", "Ảnh, PDF, âm thanh, video, file nén"),
    ("Văn bản (ký tự)", "Reader / Writer", "ký tự (16-bit)", "File .txt, .csv, .json, log"),
]:
    c = t.add_row().cells
    for i, v in enumerate(r): c[i].text = v
h3("1.1.3. Các lớp cụ thể thường dùng")
for b in [
    "FileInputStream / FileOutputStream — đọc/ghi byte thô.",
    "BufferedInputStream / BufferedOutputStream — thêm bộ đệm, tăng hiệu năng.",
    "DataInputStream / DataOutputStream — đọc/ghi kiểu nguyên thủy.",
    "FileReader / FileWriter — đọc/ghi ký tự.",
    "BufferedReader / BufferedWriter — bộ đệm ký tự, có readLine().",
]: bullet(b)
h3("1.1.4. Kiểm tra toàn vẹn bằng checksum")
p("Để kiểm tra hai tệp có giống hệt nhau, Java cung cấp lớp MessageDigest trong gói java.security, hỗ trợ các thuật toán băm như MD5, SHA-1, SHA-256. Checksum là 'dấu vân tay' của tệp: nếu hai tệp có cùng checksum, gần như chắc chắn nội dung giống hệt.")
h3("1.1.5. Giao diện GUI hiện đại với Swing")
p("Swing là bộ công cụ GUI có sẵn trong JDK, không cần thư viện ngoài. Để giao diện 'bắt mắt' hơn, ứng dụng sử dụng các kỹ thuật:")
for b in [
    "Nimbus Look and Feel — giao diện đẹp hơn Metal mặc định, có sẵn trong JDK.",
    "Custom painting — vẽ card bo tròn 16px với đổ bóng nhẹ bằng Graphics2D + RenderingHints.",
    "Badge số — vẽ vòng tròn màu xanh chứa số thứ tự card (1, 2, 3).",
    "Header gradient — dải màu xanh dương ở đầu cửa sổ với tiêu đề + phụ đề.",
    "Button hover — nút bo tròn 10px, đổi màu khi hover/pressed.",
    "Status bar — thanh trạng thái dưới cùng, đổi màu theo kết quả (xanh = thành công, đỏ = lỗi, cam = cảnh báo).",
    "Log monospace — vùng log nền tối kiểu terminal, chữ sáng, dễ đọc.",
]: bullet(b)
p("Bảng màu sử dụng: PRIMARY #2563EB (xanh dương), SUCCESS #16A34A (xanh lá), DANGER #DC2626 (đỏ), WARNING #D97706 (cam), BG #F8FAFC (nền sáng), CARD_BG #FFFFFF (nền card), TEXT_MUTED #64748B (chữ phụ).")

h2("1.2. Phân tích")
p("Việc chia nhỏ tệp nhị phân thành các đoạn có nhiều ứng dụng:")
for b in [
    "Truyền file qua mạng có giới hạn kích thước gói.",
    "Resume download (tải tiếp khi mất kết nối).",
    "Song song hóa việc tải file (nhiều phần cùng lúc).",
    "Backup và chia sẻ file P2P.",
]: bullet(b)
p("Khi chia nhỏ, cần chú ý đọc đúng số byte thực tế (read trả về), đặc biệt ở phần cuối file — phần cuối có thể ít hơn CHUNK_SIZE. Khi ghép, cần sắp xếp các phần theo đúng thứ tự (part0, part1, ...) trước khi ghi nối tiếp.")
p("Khi thiết kế GUI, cần tách biệt logic xử lý và giao diện: các thao tác nặng (chia/ghép/checksum) chạy trên luồng sự kiện (EDT) có thể gây treo giao diện nếu file lớn. Với file nhỏ (< 10MB), có thể chạy trực tiếp; với file lớn, nên dùng SwingWorker.")

h2("1.3. Ứng dụng GUI hiện đại: Chia tách – Ghép tệp nhị phân")
h3("1.3.1. Mục tiêu")
p("Xây dựng ứng dụng GUI `XuLyTep` (package `cau_1`) với giao diện hiện đại gồm:")
for b in [
    "Header xanh dương có tiêu đề '📁 XỬ LÝ TỆP NHỊ PHÂN' + phụ đề.",
    "3 card bo tròn xếp dọc: Chia tệp, Ghép tệp, Kiểm tra toàn vẹn — mỗi card có badge số + tiêu đề + phụ đề.",
    "Vùng log nền tối kiểu terminal hiển thị kết quả.",
    "Status bar đổi màu theo trạng thái (xanh = OK, đỏ = lỗi).",
    "Nút bo tròn có hover, mỗi nút một màu theo chức năng.",
]: bullet(b)
h3("1.3.2. Kiến trúc giao diện")
for b in [
    "Lớp XuLyTep extends JFrame — cửa sổ chính 920×720.",
    "Header: JPanel màu PRIMARY, chứa JLabel tiêu đề + phụ đề.",
    "Card 1 (Chia tệp): 3 field + nút '✂ Chia tệp' màu SUCCESS.",
    "Card 2 (Ghép tệp): 2 field + nút '🔗 Ghép tệp' màu SUCCESS.",
    "Card 3 (Kiểm tra): 2 field + nút '🔍 Kiểm tra' màu WARNING.",
    "Log panel: JTextArea nền tối #0F172A, font JetBrains Mono, có nút '🗑 Xóa log'.",
    "Status bar: JLabel đổi màu theo kết quả.",
    "Custom painting: card bo tròn 16px + đổ bóng, nút bo tròn 10px, badge vòng tròn.",
]: bullet(b)
h3("1.3.3. Mã nguồn chính — Custom card")
code("""private JPanel makeCard(String number, String title, String subtitle) {
    JPanel card = new JPanel(new BorderLayout(0, 10)) {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(0, 0, 0, 15));  // đổ bóng
            g2.fillRoundRect(2, 3, getWidth() - 4, getHeight() - 4, 16, 16);
            g2.setColor(CARD_BG);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
            g2.setColor(BORDER_C);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
            g2.dispose();
        }
    };
    card.setOpaque(false);
    card.setBorder(new EmptyBorder(16, 18, 16, 18));
    // ... thêm header badge + title
    return card;
}""")
h3("1.3.4. Mã nguồn chính — Custom button")
code("""private JButton btn(String text, Color bg, ActionListener l) {
    JButton b = new JButton(text) {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            Color c = getModel().isRollover() ? bg.darker() : bg;
            if (getModel().isPressed()) c = bg.darker().darker();
            g2.setColor(c);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
            g2.dispose();
            super.paintComponent(g);
        }
    };
    b.setForeground(Color.WHITE);
    b.setContentAreaFilled(false);
    b.setBorderPainted(false);
    b.setCursor(new Cursor(Cursor.HAND_CURSOR));
    b.addActionListener(l);
    return b;
}""")
h3("1.3.5. Mã nguồn chính — Logic chia tệp")
code("""private void chiaTep() {
    try {
        File in = new File(txtInput.getText().trim());
        if (!in.isFile()) { log("❌ LỖI: Tệp không tồn tại"); return; }
        int chunk = Integer.parseInt(txtChunk.getText().trim());
        File dir = new File(txtOutDir.getText().trim());
        if (!dir.exists()) dir.mkdirs();
        List<File> parts = new ArrayList<>();
        long total = 0;
        try (FileInputStream fis = new FileInputStream(in)) {
            byte[] buf = new byte[chunk];
            int idx = 0, r;
            while ((r = fis.read(buf)) != -1) {
                File p = new File(dir, in.getName() + ".part" + idx++);
                try (FileOutputStream fos = new FileOutputStream(p)) { fos.write(buf, 0, r); }
                parts.add(p); total += r;
            }
        }
        log("✅ Đã chia " + parts.size() + " phần, tổng " + total + " byte");
        log("🔐 MD5 tệp gốc: " + checksum(in, "MD5"));
        status("Chia thành công " + parts.size() + " phần", SUCCESS);
    } catch (Exception ex) { log("❌ LỖI: " + ex.getMessage()); }
}""")

h2("1.4. Kết quả thực nghiệm")
p("Kịch bản test trên GUI:")
num("Mở ứng dụng → cửa sổ hiện ra với header xanh dương, 3 card bo tròn, log nền tối.")
num("Card 1: chọn sample.jpg (500 byte), chunk = 100, thư mục parts → bấm '✂ Chia tệp' → log hiện '✅ Đã chia 5 phần, tổng 500 byte' + MD5, status bar chuyển xanh lá.")
num("Card 2: thư mục parts, tệp đầu ra merged_output.bin → bấm '🔗 Ghép tệp' → log hiện '✅ Đã ghép 5 phần, tổng 500 byte' + MD5.")
num("Card 3: chọn A = sample.jpg, B = merged_output.bin → bấm '🔍 Kiểm tra' → log hiện cả 3 tiêu chí OK + '🎉 HOÀN TOÀN GIỐNG NHAU', status bar xanh lá.")
num("Thử chọn tệp không tồn tại → log hiện '❌ LỖI: Tệp không tồn tại', status bar đỏ.")
p("Giao diện hiện đại giúp người dùng dễ nhìn, dễ thao tác hơn nhiều so với bản dòng lệnh: card có badge số, nút màu theo chức năng, log nền tối dễ đọc, status bar phản hồi trực quan.")

h2("1.5. Nhận xét")
p("Ứng dụng GUI hiện đại khắc phục hạn chế của bản dòng lệnh: thân thiện hơn, có hộp thoại chọn tệp, log hiển thị trực quan, màu sắc phân biệt chức năng. Việc dùng Nimbus L&F + custom painting giúp giao diện 'bắt mắt' mà không cần thư viện ngoài.")
p("Hạn chế: với file rất lớn, thao tác chia/ghép trên EDT có thể gây treo giao diện — hướng phát triển là dùng SwingWorker để chạy nền và cập nhật thanh tiến trình.")
p("Việc tách riêng package cau_1 giúp dự án rõ ràng, dễ bảo trì, đúng yêu cầu '2 câu — 2 file — 2 package phân biệt'.")

h2("1.6. Ứng dụng thực tế")
for b in [
    "Công cụ chia sẻ file qua mạng (FTP, HTTP range request).",
    "Resume download.",
    "Backup dữ liệu có kiểm tra toàn vẹn.",
    "Chia sẻ file P2P (BitTorrent chia file thành nhiều mảnh).",
    "Kiểm tra file tải về có bị hỏng không.",
]: bullet(b)
doc.add_page_break()

# ============ CHƯƠNG 2 (GUI HIỆN ĐẠI) ============
h1("CHƯƠNG 2: SCANNER VÀ PRINTWRITER TRONG XỬ LÝ NHẬP/XUẤT ĐỊNH DẠNG (GUI HIỆN ĐẠI)")
h2("2.1. Cơ sở lý thuyết")
h3("2.1.1. Scanner")
p("Scanner là lớp tiện ích đọc dữ liệu từ nhiều nguồn (System.in, file, chuỗi), hỗ trợ parse kiểu (nextInt, nextDouble, nextLine...).")
h3("2.1.2. PrintWriter")
p("PrintWriter là lớp ghi dữ liệu đã định dạng ra Writer, có print, println, printf tương tự System.out.")
h3("2.1.3. Định dạng CSV")
p("CSV (Comma-Separated Values): mỗi dòng là một bản ghi, các trường cách nhau bởi dấu phẩy. Nếu trường chứa dấu phẩy hoặc xuống dòng, cần bọc trong dấu ngoặc kép. Nếu trường chứa dấu ngoặc kép, nhân đôi nó.")
h3("2.1.4. UTF-8 BOM")
p("Excel trên Windows thường mặc định đọc CSV theo bảng mã ANSI. Để hiển thị đúng tiếng Việt, cần ghi thêm BOM (Byte Order Mark) ở đầu file: ký tự U+FEFF. Java có thể ghi BOM bằng cách ghi 0xFEFF trước nội dung.")
h3("2.1.5. Bảng JTable trong Swing")
p("JTable là thành phần hiển thị dữ liệu dạng bảng trong Swing. Dữ liệu được quản lý bởi TableModel (thường dùng DefaultTableModel). JTable hỗ trợ chọn dòng, sự kiện ListSelectionListener, và có thể kết hợp với JScrollPane để cuộn khi dữ liệu dài.")
h3("2.1.6. Giao diện GUI hiện đại")
p("Ứng dụng sử dụng các kỹ thuật làm đẹp tương tự Chương 1:")
for b in [
    "Header xanh dương với badge số nhân viên bên phải.",
    "2 card bo tròn: bảng bên trái, form bên phải.",
    "Bảng JTable header xám nhạt, dòng cao 32px, chọn dòng màu xanh nhạt, cột Lương căn phải.",
    "Form nhập liệu: mỗi field có label trên + input dưới, layout dọc.",
    "8 nút chia 2 cột × 4 hàng, mỗi nút một màu theo chức năng (thêm xanh lá, sửa xanh dương, xóa đỏ, làm mới cam, lưu CSV tím, nạp CSV xanh ngọc, thống kê hồng, báo cáo xám).",
    "Status bar đổi màu theo kết quả.",
]: bullet(b)

h2("2.2. Phân tích")
p("Ưu điểm của Scanner:")
for b in ["Dễ dùng, hỗ trợ nhiều kiểu dữ liệu.", "Có thể đọc từ nhiều nguồn."]: bullet(b)
p("Nhược điểm:")
for b in ["Chậm hơn BufferedReader khi đọc số lượng lớn.", "Không thread-safe."]: bullet(b)
p("Ưu điểm của PrintWriter:")
for b in ["Hỗ trợ định dạng (printf).", "Tự động flush nếu cần."]: bullet(b)
p("Khi làm việc với CSV, cần chú ý:")
for b in [
    "Escape trường chứa dấu phẩy, ngoặc kép, xuống dòng.",
    "Ghi UTF-8 có BOM để Excel hiển thị đúng tiếng Việt.",
    "Parse CSV đúng cách khi đọc lại (không dùng split đơn giản vì sẽ sai với trường có ngoặc kép).",
]: bullet(b)
p("Khi thiết kế GUI quản lý dữ liệu, cần tách biệt mô hình dữ liệu (List<NhanVien>) và giao diện (JTable). Khi dữ liệu thay đổi (thêm/sửa/xóa), cần refresh lại TableModel để bảng cập nhật.")

h2("2.3. Ứng dụng GUI hiện đại: Quản lý nhân viên với CSV")
h3("2.3.1. Mục tiêu")
p("Xây dựng ứng dụng GUI `DanhSachNhanVien` (package `cau_2`) với giao diện hiện đại gồm:")
for b in [
    "Header xanh dương có tiêu đề '👥 QUẢN LÝ NHÂN VIÊN' + badge số nhân viên bên phải.",
    "Card bảng (trái): JTable header xám nhạt, dòng cao 32px, chọn dòng xanh nhạt, cột Lương căn phải.",
    "Card form (phải): 4 field có label trên + input dưới, 8 nút chia 2 cột × 4 hàng.",
    "Status bar đổi màu theo kết quả.",
    "Dữ liệu tự nạp từ employee.csv khi khởi động.",
]: bullet(b)
h3("2.3.2. Kiến trúc giao diện")
for b in [
    "Lớp DanhSachNhanVien extends JFrame — cửa sổ chính 1000×720.",
    "Header: JPanel màu PRIMARY, badge lblCount bên phải.",
    "Card bảng: makeCard() bo tròn + JTable + JScrollPane.",
    "Card form: makeCard() + BoxLayout dọc 4 field + GridLayout 4×2 nút.",
    "Status bar: JLabel + hint 'Java Swing · CSV UTF-8'.",
]: bullet(b)
h3("2.3.3. Mã nguồn chính — Cấu hình bảng")
code("""table.setFont(FONT_TABLE);
table.setRowHeight(32);
table.setShowGrid(false);
table.setSelectionBackground(new Color(0xDBEAFE));
table.setFillsViewportHeight(true);

JTableHeader th = table.getTableHeader();
th.setFont(FONT_THEAD);
th.setBackground(new Color(0xF1F5F9));
th.setPreferredSize(new Dimension(0, 38));
th.setBorder(new MatteBorder(0, 0, 1, 0, BORDER_C));

// Căn phải cột Lương
DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
table.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);""")
h3("2.3.4. Mã nguồn chính — Grid nút 2 cột")
code("""JPanel grid = new JPanel(new GridLayout(4, 2, 8, 8));
grid.setOpaque(false);
grid.add(btn("➕ Thêm",       SUCCESS,  e -> them()));
grid.add(btn("✏ Sửa",        PRIMARY,  e -> sua()));
grid.add(btn("🗑 Xóa",        DANGER,   e -> xoa()));
grid.add(btn("🔄 Làm mới",   WARNING,  e -> lamMoi()));
grid.add(btn("💾 Lưu CSV",   new Color(0x7C3AED), e -> luuCSV()));
grid.add(btn("📂 Nạp CSV",   new Color(0x0891B2), e -> { ds.clear(); loadCSV(); refresh(); }));
grid.add(btn("📊 Thống kê",  new Color(0xDB2777), e -> thongKe()));
grid.add(btn("📄 Báo cáo",   new Color(0x475569), e -> baoCao()));""")
h3("2.3.5. Mã nguồn chính — Ghi CSV đúng chuẩn")
code("""private void luuCSV() {
    try (Writer w = new OutputStreamWriter(new FileOutputStream(CSV), StandardCharsets.UTF_8)) {
        w.write(0xFEFF);  // BOM cho Excel
        try (PrintWriter pw = new PrintWriter(w)) {
            pw.println(HEADER);
            for (NhanVien nv : ds) {
                pw.printf("%s,%s,%s,%s%n",
                        escape(nv.id), escape(nv.ten), escape(nv.phong), nv.luong);
            }
        }
        status("✅ Đã lưu " + ds.size() + " nhân viên vào " + CSV, SUCCESS);
    } catch (IOException ex) { status("⚠ " + ex.getMessage(), DANGER); }
}""")
h3("2.3.6. Mã nguồn chính — Refresh bảng + badge")
code("""private void refresh() {
    model.setRowCount(0);
    for (NhanVien nv : ds)
        model.addRow(new Object[]{nv.id, nv.ten, nv.phong, MONEY.format(nv.luong)});
    lblCount.setText(ds.size() + " nhân viên");  // cập nhật badge header
}""")

h2("2.4. Kết quả thực nghiệm")
p("Kịch bản test trên GUI:")
num("Mở ứng dụng → cửa sổ hiện ra với header xanh dương, badge '0 nhân viên', bảng trống, form bên phải.")
num("Nhập NV01, Nguyễn Văn A, Kế toán, 15000000 → bấm '➕ Thêm' → bảng xuất hiện dòng mới, badge '1 nhân viên', status bar xanh lá.")
num("Nhập NV02, Trần Thị B, IT, 20000000 → bấm Thêm → badge '2 nhân viên'.")
num("Nhập NV03, Lê Văn C, IT, 18000000 → bấm Thêm → badge '3 nhân viên'.")
num("Click dòng NV01 trong bảng → form tự điền, ô ID bị khóa, status bar 'Đang chọn: NV01'.")
num("Sửa lương NV01 thành 16000000 → bấm '✏ Sửa' → bảng cập nhật.")
num("Bấm '📊 Thống kê' → JOptionPane hiện tổng 3, TB 18.000.000, cao nhất 20.000.000, thấp nhất 16.000.000; IT: 2 người.")
num("Bấm '💾 Lưu CSV' → status '✅ Đã lưu 3 nhân viên vào employee.csv', badge giữ nguyên.")
num("Bấm '📄 Báo cáo' → tạo file baocao_nhanvien.txt.")
num("Đóng ứng dụng → mở lại → badge '3 nhân viên', bảng tự nạp từ employee.csv.")
p("File employee.csv mở trong Excel hiển thị đúng 4 cột, tiếng Việt không lỗi font (nhờ BOM).")

h2("2.5. Nhận xét")
p("Ứng dụng GUI hiện đại khắc phục hạn chế của bản dòng lệnh: thao tác trực quan trên bảng, form nhập liệu rõ ràng, có xác nhận trước khi xóa, thống kê hiển thị trong hộp thoại, badge header cập nhật số nhân viên realtime. Việc dùng JTable + card bo tròn + màu sắc theo chức năng giúp giao diện 'bắt mắt' và dễ dùng.")
p("Hạn chế: chưa có tìm kiếm realtime, chưa sắp xếp bằng click cột. Hướng phát triển: thêm TableRowSorter cho JTable, thêm ô tìm kiếm, thêm biểu đồ lương.")

h2("2.6. Ứng dụng thực tế")
for b in [
    "Quản lý nhân viên, sinh viên, khách hàng.",
    "Xuất báo cáo lương, điểm, doanh thu.",
    "Nhập liệu hàng loạt từ Excel/Google Sheets.",
    "Trao đổi dữ liệu giữa các hệ thống (import/export CSV).",
]: bullet(b)
doc.add_page_break()

# ============ CHƯƠNG 3 ============
h1("CHƯƠNG 3: ĐỒNG BỘ HÓA (SYNCHRONIZATION) TRONG JAVA")
h2("3.1. Cơ sở lý thuyết")
h3("3.1.1. Race condition")
p("Khi nhiều thread cùng truy cập và thay đổi tài nguyên chia sẻ mà không đồng bộ, xảy ra race condition — kết quả phụ thuộc vào thứ tự thực thi không xác định của các thread.")
h3("3.1.2. Mutual exclusion")
p("Java cung cấp từ khóa synchronized để đảm bảo mutual exclusion: tại một thời điểm chỉ một thread được vào vùng critical section.")
h3("3.1.3. Các cấp độ đồng bộ")
for b in [
    "Phương thức synchronized: khóa trên this (instance method) hoặc trên class (static method).",
    "Khối synchronized(obj): khóa trên đối tượng cụ thể, linh hoạt hơn.",
    "ReentrantLock: khóa tường minh, hỗ trợ tryLock, lockInterruptibly.",
    "AtomicInteger, AtomicLong: biến nguyên tử, không cần khóa cho phép toán đơn giản.",
]: bullet(b)
h2("3.2. Phân tích")
p("Phép tickets-- gồm 3 bước: đọc giá trị, giảm, ghi lại. Hai thread có thể cùng đọc tickets = 1, cùng thấy > 0, cùng giảm → bán 2 vé dù chỉ còn 1. synchronized đảm bảo chỉ một thread vào vùng critical tại một thời điểm, ngăn race condition.")
h2("3.3. Demo: Bán vé (shared counter) có và không synchronized")
h3("3.3.1. Mục tiêu")
p("Mô phỏng 3 thread cùng bán 100 vé. So sánh kết quả khi không đồng bộ và có đồng bộ.")
h3("3.3.2. Mã nguồn")
code("""class TicketCounter {
    private int tickets = 100;
    public void sellUnsynchronized(String name) {
        if (tickets > 0) {
            try { Thread.sleep(1); } catch (InterruptedException e) {}
            tickets--;
        }
    }
    public synchronized void sellSynchronized(String name) {
        if (tickets > 0) {
            try { Thread.sleep(1); } catch (InterruptedException e) {}
            tickets--;
        }
    }
}""")
h2("3.4. Kết quả thực nghiệm")
t = doc.add_table(rows=1, cols=3); t.style = "Table Grid"
h = t.rows[0].cells
h[0].text="Trường hợp"; h[1].text="Số vé còn lại"; h[2].text="Nhận xét"
for r in [
    ("Không synchronized", "Thường âm (-37, -12...) hoặc khác 0", "Race condition: nhiều thread cùng đọc tickets > 0 trước khi giảm → bán quá số vé"),
    ("Có synchronized", "Luôn = 0", "Đồng bộ hoạt động đúng, không bán quá"),
]:
    c = t.add_row().cells
    for i, v in enumerate(r): c[i].text = v
h2("3.5. Nhận xét")
p("Đồng bộ hóa là bắt buộc khi có shared mutable state. Tuy nhiên lạm dụng synchronized có thể gây deadlock hoặc giảm hiệu năng; nên cân nhắc AtomicInteger cho phép toán đơn giản, hoặc ConcurrentHashMap cho collection.")
h2("3.6. Ứng dụng thực tế")
for b in ["Quản lý tài khoản ngân hàng.", "Đặt vé/đặt hàng.", "Bộ đếm chia sẻ.", "Hàng đợi sự kiện."]: bullet(b)
doc.add_page_break()

# ============ CHƯƠNG 4 ============
h1("CHƯƠNG 4: LẬP TRÌNH SOCKET TCP VỚI JAVA")
h2("4.1. Cơ sở lý thuyết")
h3("4.1.1. Socket")
p("Socket là điểm cuối (endpoint) của kết nối mạng, được xác định bởi cặp (IP, port). TCP là giao thức hướng kết nối, tin cậy, đảm bảo thứ tự và toàn vẹn dữ liệu.")
h3("4.1.2. Mô hình Client–Server qua TCP")
num("Server tạo ServerSocket(port) và gọi accept() — block chờ client.")
num("Client tạo Socket(host, port) — kết nối tới server.")
num("Hai bên trao đổi qua InputStream/OutputStream của socket.")
num("Đóng kết nối bằng close().")
h2("4.2. Phân tích")
p("Ưu điểm của Socket TCP:")
for b in ["Tin cậy, đảm bảo thứ tự.", "Dễ dùng, tích hợp sẵn trong JDK."]: bullet(b)
p("Nhược điểm:")
for b in ["Chậm hơn UDP.", "Cần xử lý IOException, đóng tài nguyên.", "Server đơn luồng chỉ phục vụ 1 client — cần ExecutorService cho đa client."]: bullet(b)
h2("4.3. Demo: Client gửi chuỗi → Server ghi log")
h3("4.3.1. Mục tiêu")
p("Client nhập văn bản từ bàn phím, gửi qua TCP tới server; server ghi từng dòng vào server_log.txt.")
h3("4.3.2. Mã nguồn")
code("""// TCPServer.java
try (ServerSocket server = new ServerSocket(5000);
     PrintWriter log = new PrintWriter(new FileWriter("server_log.txt", true))) {
    System.out.println("Server đang chờ kết nối ở port 5000...");
    try (Socket client = server.accept();
         BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))) {
        String line;
        while ((line = in.readLine()) != null) {
            System.out.println("Nhận: " + line);
            log.println(line); log.flush();
            if (line.equalsIgnoreCase("exit")) break;
        }
    }
}

// TCPClient.java
try (Socket socket = new Socket("localhost", 5000);
     PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
     BufferedReader kb = new BufferedReader(new InputStreamReader(System.in))) {
    String line;
    while ((line = kb.readLine()) != null) {
        out.println(line);
        if (line.equalsIgnoreCase("exit")) break;
    }
}""")
h2("4.4. Kết quả thực nghiệm")
for b in [
    "Chạy TCPServer → console: Server đang chờ kết nối ở port 5000...",
    "Chạy TCPClient, nhập: Xin chào server / Đây là dòng thứ hai / exit",
    "File server_log.txt chứa đúng nội dung đã gửi.",
    "Console server in: Nhận: Xin chào server / Nhận: Đây là dòng thứ hai",
]: bullet(b)
h2("4.5. Nhận xét")
p("Socket TCP phù hợp cho ứng dụng cần truyền dữ liệu tin cậy (chat, file transfer, HTTP). Cần xử lý IOException, đóng tài nguyên đúng cách, và có thể dùng ExecutorService để phục vụ nhiều client đồng thời.")
h2("4.6. Ứng dụng thực tế")
for b in ["Chat server/client.", "Truyền file.", "HTTP server đơn giản.", "Điều khiển từ xa."]: bullet(b)
doc.add_page_break()

# ============ CHƯƠNG 5 ============
h1("CHƯƠNG 5: MULTICAST TRONG JAVA VÀ MULTICASTSOCKET")
h2("5.1. Cơ sở lý thuyết")
h3("5.1.1. Multicast")
p("Multicast là cơ chế truyền một gói tin tới một nhóm địa chỉ (multicast group), thay vì unicast (1–1) hay broadcast (1–tất cả trong subnet). Multicast tiết kiệm băng thông khi cần gửi cùng dữ liệu cho nhiều receiver.")
h3("5.1.2. Địa chỉ và giao thức")
for b in [
    "Địa chỉ multicast IPv4: 224.0.0.0 – 239.255.255.255 (thường dùng 230.0.0.1).",
    "Giao thức nền: UDP (không đảm bảo tin cậy).",
    "Java: lớp MulticastSocket, phương thức joinGroup(InetAddress), leaveGroup(...).",
    "Gửi: DatagramPacket(buf, len, group, port) + socket.send(packet).",
    "Nhận: socket.receive(packet) sau khi đã joinGroup.",
]: bullet(b)
h2("5.2. Phân tích")
p("Ưu điểm multicast:")
for b in ["Tiết kiệm băng thông (gửi 1 lần, nhiều client nhận).", "Phù hợp streaming, cập nhật trạng thái đồng loạt."]: bullet(b)
p("Nhược điểm:")
for b in ["Không đảm bảo tin cậy (UDP).", "Có thể bị chặn bởi firewall.", "Không hoạt động qua Internet (chỉ trong LAN hoặc mạng hỗ trợ multicast)."]: bullet(b)
h2("5.3. Demo: 1 server phát, nhiều client nhận")
h3("5.3.1. Mục tiêu")
p("Server gửi 5 thông điệp multicast tới group 230.0.0.1:4446; tất cả client trong group đều nhận và hiển thị.")
h3("5.3.2. Mã nguồn")
code("""// MulticastServer.java
InetAddress group = InetAddress.getByName("230.0.0.1");
try (MulticastSocket socket = new MulticastSocket()) {
    for (int i = 1; i <= 5; i++) {
        String msg = "Thông điệp multicast #" + i;
        byte[] buf = msg.getBytes();
        socket.send(new DatagramPacket(buf, buf.length, group, 4446));
        System.out.println("Đã gửi: " + msg);
        Thread.sleep(1000);
    }
}

// MulticastClient.java
InetAddress group = InetAddress.getByName("230.0.0.1");
try (MulticastSocket socket = new MulticastSocket(4446)) {
    socket.joinGroup(group);
    byte[] buf = new byte[1024];
    for (int i = 0; i < 5; i++) {
        DatagramPacket packet = new DatagramPacket(buf, buf.length);
        socket.receive(packet);
        System.out.println("Nhận: " + new String(packet.getData(), 0, packet.getLength()));
    }
    socket.leaveGroup(group);
}""")
h2("5.4. Kết quả thực nghiệm")
p("Chạy MulticastServer → gửi 5 thông điệp. Chạy 3 instance MulticastClient → cả 3 đều in đủ 5 thông điệp giống nhau → multicast hoạt động đúng.")
h2("5.5. Nhận xét")
p("Multicast phù hợp cho streaming, cập nhật trạng thái đồng loạt (stock ticker, game lobby). Lưu ý multicast có thể bị chặn bởi firewall hoặc không hoạt động qua Internet. Cần đặt TTL phù hợp nếu muốn gói đi xa hơn subnet (socket.setTimeToLive(1)).")
h2("5.6. Ứng dụng thực tế")
for b in ["Streaming video/audio.", "Cập nhật trạng thái đồng loạt (stock ticker, game lobby).", "Phân phối phần mềm trong LAN.", "Video conference."]: bullet(b)
doc.add_page_break()

# ============ CHƯƠNG 6 ============
h1("CHƯƠNG 6: KỸ THUẬT RMI (REMOTE METHOD INVOCATION)")
h2("6.1. Cơ sở lý thuyết")
h3("6.1.1. Khái niệm RMI")
p("RMI cho phép một chương trình Java gọi phương thức của đối tượng nằm ở JVM khác (khác máy hoặc khác process) như thể gọi local. RMI che giấu chi tiết marshalling/unmarshalling và truyền tải mạng.")
h3("6.1.2. Kiến trúc 3 thành phần")
p("Stub (phía client): proxy của remote object, chuyển lời gọi thành dữ liệu mạng, gửi tới server, nhận kết quả.")
p("Skeleton (phía server): nhận dữ liệu, unmarshal, gọi phương thức thực, marshal kết quả trả về (từ Java 2 tích hợp vào RMI runtime).")
p("Registry: dịch vụ danh bạ ánh xạ tên → tham chiếu remote object. Server đăng ký bằng rebind; client tra cứu bằng lookup.")
h3("6.1.3. Yêu cầu")
for b in [
    "Interface remote phải kế thừa java.rmi.Remote.",
    "Mỗi phương thức phải khai báo throws RemoteException.",
    "Implementation kế thừa UnicastRemoteObject (hoặc export thủ công).",
    "Tham số/giá trị trả về phải Serializable.",
]: bullet(b)
h2("6.2. Phân tích")
p("Ưu điểm RMI:")
for b in ["Đơn giản hóa lập trình phân tán trong Java.", "Che giấu chi tiết mạng, marshalling.", "Tích hợp sẵn trong JDK."]: bullet(b)
p("Nhược điểm:")
for b in ["Gắn chặt với Java.", "Cần mở port 1099 trên firewall nếu chạy khác máy."]: bullet(b)
h2("6.3. Demo: Client gọi sayHello() từ Server")
h3("6.3.1. Mục tiêu")
p("Xây dựng RMI server đăng ký HelloService tại port 1099; client tra cứu và gọi sayHello(), nhận chuỗi trả về; server log Server đã được gọi từ xa.")
h3("6.3.2. Cấu trúc 4 file")
p("Hello.java (interface), HelloImpl.java (implementation), RMIServer.java, RMIClient.java.")
h3("6.3.3. Mã nguồn")
code("""// Hello.java
public interface Hello extends Remote {
    String sayHello() throws RemoteException;
}

// HelloImpl.java
public class HelloImpl extends UnicastRemoteObject implements Hello {
    public HelloImpl() throws RemoteException { super(); }
    public String sayHello() throws RemoteException {
        System.out.println("Server đã được gọi từ xa");
        return "Hello từ RMI Server!";
    }
}

// RMIServer.java
Registry registry = LocateRegistry.createRegistry(1099);
registry.rebind("HelloService", new HelloImpl());
System.out.println("RMI Server đã sẵn sàng tại port 1099");

// RMIClient.java
Registry registry = LocateRegistry.getRegistry("localhost", 1099);
Hello hello = (Hello) registry.lookup("HelloService");
System.out.println("Kết quả từ server: " + hello.sayHello());""")
h2("6.4. Kết quả thực nghiệm")
for b in [
    "Chạy RMIServer → console: RMI Server đã sẵn sàng tại port 1099, tên HelloService.",
    "Chạy RMIClient → console client: Kết quả từ server: Hello từ RMI Server!",
    "Console server đồng thời in: Server đã được gọi từ xa → lời gọi từ xa hoạt động.",
]: bullet(b)
h2("6.5. Nhận xét")
p("RMI đơn giản hóa lập trình phân tán trong Java nhưng gắn chặt với Java. Trên JDK 17+ không cần chạy rmic — stub được sinh động. Cần mở port 1099 trên firewall nếu chạy khác máy. RMI là nền tảng để hiểu các công nghệ cao hơn như EJB, Spring Remoting.")
h2("6.6. Ứng dụng thực tế")
for b in ["Hệ thống phân tán trong doanh nghiệp.", "Gọi dịch vụ từ xa trong ứng dụng Java.", "Nền tảng học EJB, Spring Remoting."]: bullet(b)
doc.add_page_break()

# KẾT LUẬN
h1("KẾT LUẬN VÀ HƯỚNG PHÁT TRIỂN")
h2("Kết luận")
p("Qua 6 chủ đề thực hành, báo cáo đã trình bày và minh họa được:")
for b in [
    "Xử lý tệp nhị phân/văn bản — ứng dụng GUI `XuLyTep` (package cau_1) với giao diện hiện đại: card bo tròn, badge số, header xanh dương, log nền tối, status bar đổi màu.",
    "Scanner/PrintWriter — ứng dụng GUI `DanhSachNhanVien` (package cau_2) với bảng JTable header xám, form 2 cột, 8 nút màu theo chức năng, badge số nhân viên realtime, CSV chuẩn UTF-8 có BOM.",
    "Đồng bộ hóa — chứng minh race condition khi không synchronized và kết quả đúng khi có đồng bộ.",
    "Socket TCP — client-server gửi chuỗi, server ghi log đầy đủ.",
    "Multicast — một server phát, nhiều client cùng nhận thông điệp.",
    "RMI — client gọi phương thức từ xa sayHello(), server log xác nhận.",
]: bullet(b)
p("Hai ứng dụng GUI ở Chương 1 và Chương 2 được tách thành **2 package riêng biệt** (`cau_1`, `cau_2`), **2 file riêng biệt**, chạy độc lập trên Apache NetBeans. Cả hai dùng Swing thuần + Nimbus L&F + custom painting — nhẹ, không cần thư viện ngoài, khởi động nhanh, giao diện 'bắt mắt' và hiện đại.")
h2("Hướng phát triển")
for b in [
    "Ứng dụng 1: thêm SwingWorker để chạy nền khi chia/ghép file lớn, hiển thị thanh tiến trình.",
    "Ứng dụng 2: thêm TableRowSorter cho JTable, ô tìm kiếm realtime, biểu đồ lương.",
    "Demo 3: so sánh thêm ReentrantLock và AtomicInteger về hiệu năng.",
    "Demo 4: nâng cấp server dùng thread pool (ExecutorService) phục vụ nhiều client đồng thời.",
    "Demo 5: thêm giao diện hiển thị thông điệp multicast realtime.",
    "Demo 6: kết hợp RMI với SSL/TLS để bảo mật lời gọi từ xa.",
]: bullet(b)

h1("TÀI LIỆU THAM KHẢO")
for i, ref in enumerate([
    "Oracle. Java SE Documentation – Java I/O, Networking, RMI. https://docs.oracle.com/javase/",
    "Herbert Schildt. Java: The Complete Reference, 12th Edition. McGraw-Hill, 2021.",
    "Cay S. Horstmann. Core Java Volume II — Advanced Features, 11th Edition. Pearson, 2019.",
    "Apache NetBeans Documentation. https://netbeans.apache.org/",
    "Baeldung. Java Networking Tutorials, Java RMI Guide. https://www.baeldung.com/",
], 1):
    p(f"[{i}] {ref}")

h1("PHỤ LỤC: CÂU HỎI ÔN TẬP")
h2("Chương 1")
for q in [
    "Phân biệt tệp nhị phân và tệp văn bản.",
    "Tại sao cần đọc đúng số byte thực tế khi chia tệp?",
    "Làm sao kiểm tra tính toàn vẹn sau khi ghép?",
    "Ưu điểm của GUI hiện đại (card bo tròn, badge, màu sắc) so với GUI cơ bản?",
    "Custom painting trong Swing hoạt động như thế nào?",
]: bullet(q)
h2("Chương 2")
for q in [
    "Scanner và BufferedReader khác nhau thế nào?",
    "Tại sao cần bọc ngoặc kép trường văn bản trong CSV?",
    "Làm sao ghi UTF-8 có BOM?",
    "JTable quản lý dữ liệu như thế nào?",
    "Làm sao cập nhật badge số nhân viên realtime?",
]: bullet(q)
h2("Chương 3")
for q in [
    "Race condition là gì? Cho ví dụ.",
    "synchronized hoạt động như thế nào?",
    "Khi nào nên dùng AtomicInteger thay vì synchronized?",
]: bullet(q)
h2("Chương 4")
for q in [
    "Mô tả quy trình Client-Server qua TCP.",
    "Làm sao server phục vụ nhiều client đồng thời?",
    "Tại sao cần đóng socket sau khi dùng?",
]: bullet(q)
h2("Chương 5")
for q in [
    "Multicast khác unicast và broadcast thế nào?",
    "Tại sao multicast dùng UDP thay vì TCP?",
    "Làm sao giới hạn multicast trong subnet?",
]: bullet(q)
h2("Chương 6")
for q in [
    "RMI là gì? Kiến trúc 3 thành phần gồm những gì?",
    "Yêu cầu để một interface trở thành remote interface?",
    "Registry trong RMI có vai trò gì?",
]: bullet(q)

doc.save("2-CK-Tra-Loi.docx")
print("Da tao: 2-CK-Tra-Loi.docx")
PYEOF
"$TMPVENV/bin/python" /tmp/gen_ck.py
rm -f /tmp/gen_ck.py
rm -rf "$(dirname "$TMPVENV")"
ls -la 2-CK-Tra-Loi.docx